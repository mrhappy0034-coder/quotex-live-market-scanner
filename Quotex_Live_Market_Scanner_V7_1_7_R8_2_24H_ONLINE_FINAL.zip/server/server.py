from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from collections import defaultdict, deque
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import os, json, threading, time, re, math, logging, tempfile, uuid, sys

HOST = os.environ.get('HOST', '0.0.0.0')
PORT = int(os.environ.get('PORT', '8765'))
BASE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(BASE, 'settings.json')
LOG_FILE = os.path.join(BASE, 'scanner.log')
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger('quotex_scanner')

# Validation logger is analysis-only: it records scanner signals/results and never
# places trades or controls the Quotex account.
try:
    _validation_dir = os.path.normpath(os.path.join(BASE, '..', 'validation'))
    if _validation_dir not in sys.path: sys.path.insert(0, _validation_dir)
    from live_validator import LiveValidator
    validator = LiveValidator(_validation_dir)
except Exception:
    validator = None
    log.exception('Validation logger unavailable')
lock = threading.Lock()
ticks = defaultdict(lambda: deque(maxlen=100000))
candles = defaultdict(lambda: deque(maxlen=10000))
# Historical OHLC candles captured from the authorized browser feed. These are
# kept separately from live ticks so startup history can seed the chart/SR engine.
historical_candles = defaultdict(dict)
last_quote, last_update = {}, {}
last_frame_time = 0.0
last_accepted = 0
last_error = ''
raw_frames = 0
http_history_frames = 0
raw_pairs = defaultdict(int)

# Optional V4 Pro features. NORMAL mode never changes the original V4 core signal logic.
settings = {'mode':'normal','ai_mode':False,'filter_5m':False,'filter_macd':False,'filter_rsi':False,'filter_pattern':False,'filter_volatility':False,'strict_score':False,'smart_confluence':False,'alerts':True,'signal_1m':True,'signal_2m':True,'signal_5m':True,'signal_10m':True,'confirmation_70':False,'structure_analysis':True,'filter_structure':False,'structure_1m':True,'structure_2m':True,'structure_5m':True,'structure_10m':True,'history_1m':False,'history_2m':False,'history_5m':False,'history_10m':False,'structure_history_1m':False,'structure_history_2m':False,'structure_history_5m':False,'structure_history_10m':False,'strong_signal_filter':False,'mtf_confluence':False,'signal_quality_guard':False,'enabled_pairs':[],'pair_filter_enabled':False}

def _load_settings():
    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            saved=json.load(f)
        if isinstance(saved, dict):
            for k in settings:
                if k in saved:
                    if k in ('enabled_pairs',):
                        if isinstance(saved[k], list): settings[k]=[str(x).strip() for x in saved[k] if valid_pair(str(x).strip())]
                    elif k == 'pair_filter_enabled':
                        settings[k]=bool(saved[k])
                    elif k == 'mode':
                        settings[k]=saved[k] if saved[k] in ('normal','full') else settings[k]
                    else:
                        settings[k]=bool(saved[k])
        log.info('Settings loaded from %s', SETTINGS_FILE)
    except FileNotFoundError:
        pass
    except Exception:
        log.exception('Failed to load settings')

def _save_settings():
    tmp=SETTINGS_FILE+'.tmp'
    try:
        data=dict(settings)
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, SETTINGS_FILE)
        return True
    except Exception:
        log.exception('Failed to save settings')
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except OSError: pass
        return False
candle_dirty = defaultdict(bool)
last_completed_1m = defaultdict(lambda: None)
last_completed_2m = defaultdict(lambda: None)
last_completed_5m = defaultdict(lambda: None)
last_completed_10m = defaultdict(lambda: None)
signal_history = deque(maxlen=5000)
bfss_history = deque(maxlen=5000)
last_bfss_bar = defaultdict(lambda: 0)
structure_history = deque(maxlen=5000)
last_structure_bar = defaultdict(lambda: None)
last_candle_seen = defaultdict(lambda: None)
last_bar_seen_5m = defaultdict(lambda: None)
last_structure_bar_2m = defaultdict(lambda: None)
last_structure_bar_5m = defaultdict(lambda: None)
last_structure_bar_10m = defaultdict(lambda: None)
last_signal_state = defaultdict(dict)
selected_chart_pair = None

def norm_ts(v):
    try:
        x=float(v)
    except Exception:
        return time.time()
    # Feed timestamps may arrive in seconds, milliseconds, microseconds or
    # centiseconds. Normalize exactly once.
    if x > 1e14:
        x /= 1_000_000.0
    elif x > 1e11:
        x /= 1_000.0
    elif x > 1e10:
        x /= 100.0
    if x < 1e9 or x > 2208988800:
        return time.time()
    return x

def market_type(pair): return 'OTC' if '_otc' in pair.lower() else 'LIVE'

def fmt_time(ts):
    """Format an internal timestamp in UTC."""
    try:
        return datetime.fromtimestamp(norm_ts(ts), timezone.utc).strftime('%H:%M:%S UTC')
    except Exception:
        return '--:--:-- UTC'


def fmt_market_time(ts):
    """Format market timestamps in India time, matching UTC+05:30 display."""
    try:
        return datetime.fromtimestamp(norm_ts(ts), timezone.utc).astimezone(ZoneInfo('Asia/Kolkata')).strftime('%H:%M:%S IST')
    except Exception:
        return '--:--:-- IST'


# Quotex asset symbols are normally six currency/asset letters, optionally
# followed by _otc. Reject internal numeric IDs and other metadata that can
# appear in Socket.IO packets.
PAIR_RE = re.compile(r'^[A-Za-z][A-Za-z0-9]{2,14}(?:_otc)?$', re.I)

def valid_pair(pair):
    p = str(pair).strip()
    if not PAIR_RE.fullmatch(p):
        return False
    return p.lower().endswith('_otc') or p.upper() == p or p.isalpha()

_load_settings()

def valid_quote(pair, ts, price):
    if not valid_pair(pair):
        return False
    try:
        t = float(ts); v = float(price)
    except Exception:
        return False
    # Ignore impossible timestamps and non-positive quote values.
    if t < 1577836800 or t > 2208988800:
        return False
    if v <= 0:
        return False
    return True

def parse_obj(obj):
    out=[]
    # Quote records may be nested several levels deep.
    if isinstance(obj, list):
        if len(obj) >= 3 and not isinstance(obj[0], (list, dict)):
            try:
                pair=str(obj[0]).strip()
                # Accept both common quote orders: [pair,timestamp,price]
                # and [pair,price,timestamp]. Detect the timestamp by its
                # epoch-sized magnitude instead of assuming field order.
                a=float(obj[1]); b=float(obj[2])
                if a >= 1e9 or a >= 1e10:
                    ts, price = norm_ts(a), b
                elif b >= 1e9:
                    ts, price = norm_ts(b), a
                else:
                    ts, price = norm_ts(a), b
                if valid_quote(pair, ts, price):
                    out.append((pair, ts, price)); return out
            except Exception:
                pass
        for item in obj:
            out.extend(parse_obj(item))
    elif isinstance(obj, dict):
        # Be liberal with common quote field names.
        pair=obj.get('pair') or obj.get('symbol') or obj.get('asset') or obj.get('name')
        ts=obj.get('timestamp') or obj.get('time') or obj.get('ts')
        price=obj.get('price') or obj.get('quote') or obj.get('value')
        if pair is not None and ts is not None and price is not None:
            try:
                pair_s = str(pair).strip(); ts_n = norm_ts(ts); price_n = float(price)
                if valid_quote(pair_s, ts_n, price_n):
                    out.append((pair_s, ts_n, price_n))
            except Exception: pass
        for v in obj.values():
            if isinstance(v,(list,dict)): out.extend(parse_obj(v))
    return out

def parse_text(s):
    s=s.strip()
    if not s:
        return []
    # Engine.IO/Socket.IO message wrappers often look like:
    # 4[["EURJPY_otc",timestamp,price,flag]]
    # 451-["quotes/stream",{"_placeholder":true,"num":0}]
    # 451-[...]
    candidates=[s]
    if s.startswith('451-'):
        candidates.append(s[4:])
    if s.startswith('45'):
        # Try after the Socket.IO packet type digits + optional attachment count.
        for cut in (2,3,4,5):
            if len(s)>cut: candidates.append(s[cut:])
    if s.startswith('4') and len(s)>1:
        candidates.append(s[1:])

    for c in candidates:
        try:
            obj=json.loads(c)
            got=parse_obj(obj)
            if got: return got
        except Exception:
            log.debug('Ignored malformed text frame', exc_info=True)
    return []

def _is_num(v):
    try:
        float(v); return True
    except Exception:
        return False


def _ohlc_from_mapping(obj, pair_hint=None):
    """Extract one OHLC candle from a dict when the feed exposes named fields."""
    if not isinstance(obj, dict):
        return None
    pair = (obj.get('pair') or obj.get('symbol') or obj.get('asset') or
            obj.get('asset_id') or obj.get('instrument') or obj.get('instrument_id') or
            obj.get('ticker') or obj.get('name') or pair_hint)
    ts = (obj.get('timestamp') or obj.get('time') or obj.get('ts') or
          obj.get('from') or obj.get('at') or obj.get('start') or obj.get('open_time'))
    o = obj.get('open') if 'open' in obj else obj.get('o')
    h = obj.get('high') if 'high' in obj else obj.get('h')
    l = obj.get('low') if 'low' in obj else obj.get('l')
    c = obj.get('close') if 'close' in obj else obj.get('c')
    if pair is None or ts is None or None in (o,h,l,c):
        return None
    try:
        pair=str(pair).strip(); ts=norm_ts(ts); o,h,l,c=map(float,(o,h,l,c))
    except Exception:
        return None
    if not valid_pair(pair) or ts < 1577836800 or ts > 2208988800:
        return None
    if min(o,h,l,c) <= 0 or h < max(o,c) or l > min(o,c):
        return None
    return pair, int(ts//60)*60, (int(ts//60)*60, o, h, l, c)


def _ohlc_from_array(arr, pair_hint=None):
    """Best-effort OHLC extraction from common feed array shapes.

    Supported forms include [time,o,h,l,c], [time,o,c,h,l], and
    [pair,time,o,h,l,c]. The last form is common when a candle row carries its
    own asset symbol.
    """
    if not isinstance(arr, (list,tuple)):
        return None
    if len(arr) >= 6 and isinstance(arr[0], str) and _is_num(arr[1]):
        pair_hint=str(arr[0]).strip(); values=arr[1:6]
    elif len(arr) >= 5 and all(_is_num(x) for x in arr[:5]):
        values=arr[:5]
    else:
        return None
    try:
        nums_all=list(map(float,values))
        # Candle rows are normally [time,o,h,l,c], but some feeds use
        # [o,h,l,c,time]. Detect the epoch-sized field so history is not
        # discarded simply because the provider changed field order.
        ti=next((i for i,x in enumerate(nums_all) if x >= 1e9), None)
        if ti is None:
            return None
        ts=norm_ts(nums_all[ti])
        nums=[x for i,x in enumerate(nums_all) if i!=ti][:4]
    except Exception:
        return None
    if ts < 1577836800 or ts > 2208988800 or not pair_hint or not valid_pair(pair_hint):
        return None
    # Prefer the conventional OHLC order. If invalid, try Quotex-style O,C,H,L.
    # Quotex commonly uses [timestamp, open, close, high, low].
    # Keep the conventional [timestamp, open, high, low, close] fallback too.
    candidates=[
        (nums[0],nums[2],nums[3],nums[1]),  # [ts,o,c,h,l] -> OHLC
        (nums[0],nums[1],nums[2],nums[3]),  # [ts,o,h,l,c]
    ]
    for o,h,l,c in candidates:
        if min(o,h,l,c)>0 and h>=max(o,c) and l<=min(o,c):
            b=int(ts//60)*60
            return str(pair_hint).strip(), b, (b,o,h,l,c)
    return None


def parse_candle_history(obj, pair_hint=None):
    """Recursively find historical OHLC candles in browser/WebSocket payloads.

    The parser is intentionally conservative: a candle is accepted only when
    its pair can be identified and OHLC bounds are internally consistent.
    """
    out=[]
    if isinstance(obj, dict):
        local_pair=(obj.get('pair') or obj.get('symbol') or obj.get('asset') or
                    obj.get('asset_id') or obj.get('instrument') or obj.get('instrument_id') or
                    obj.get('ticker') or obj.get('name') or pair_hint)
        one=_ohlc_from_mapping(obj, local_pair)
        if one: out.append(one)
        # Common containers: candles, history, data, bars, quotes, series.
        for k,v in obj.items():
            if isinstance(v,(list,dict)):
                out.extend(parse_candle_history(v, str(local_pair).strip() if local_pair else pair_hint))
    elif isinstance(obj, list):
        one=_ohlc_from_array(obj, pair_hint)
        if one: out.append(one)
        for v in obj:
            if isinstance(v,(list,dict)):
                out.extend(parse_candle_history(v, pair_hint))
    return out


def parse_candle_payload(data):
    """Decode authoritative OHLC history from WS, fetch/XHR, or nested JSON.

    Quotex history responses have appeared in several wrappers, including
    Socket.IO 42[...], binary JSON, {asset,candles:[...]}, and {data:[...]}
    containers. Candle rows are commonly [timestamp, open, close, high, low].
    """
    objs=[]
    seen=set()
    def add_obj(x, depth=0):
        if depth>5 or x is None: return
        if isinstance(x,(dict,list)):
            try:
                k=id(x)
                if k in seen: return
                seen.add(k)
            except Exception: pass
            objs.append(x)
        elif isinstance(x,str) and depth<5:
            t=x.strip()
            if not t or len(t)>4*1024*1024: return
            candidates=[t]
            if t.startswith('42') or t.startswith('451-'):
                candidates += [t[2:] if t.startswith('42') else t[4:]]
            if t.startswith('4') and len(t)>1: candidates.append(t[1:])
            for cut in range(1,6):
                if len(t)>cut and t[cut:cut+1] in ('[','{'): candidates.append(t[cut:])
            for c in candidates:
                try: add_obj(json.loads(c),depth+1)
                except Exception: pass
            try:
                raw=bytes.fromhex(''.join(t.split()))
                if raw[:1] in (b'\x04',b'4'): raw=raw[1:]
                add_obj(raw.decode('utf-8',errors='ignore'),depth+1)
            except Exception: pass
    add_obj(data)
    found=[]
    for obj in objs:
        found.extend(parse_candle_history(obj))
    d={}
    for pair,b,c in found:
        d[(pair,b)]=(pair,b,c)
    return list(d.values())

def parse_payload(data):
    if isinstance(data,list):
        return parse_obj(data)
    if not isinstance(data,str):
        return []
    s=data.strip()
    if not s:
        return []

    got=parse_text(s)
    if got: return got

    # Binary messages are forwarded by the extension as hexadecimal.
    try:
        raw=bytes.fromhex(''.join(s.split()))
        # Engine.IO binary packet marker(s).
        for prefix in (b'\x04', b'4'):
            if raw.startswith(prefix):
                raw=raw[1:]
        try:
            text=raw.decode('utf-8')
            got=parse_text(text)
            if got: return got
        except Exception:
            pass
        # Sometimes the first byte is a binary/socket.io marker followed by JSON.
        l=raw.find(b'[[')
        r=raw.rfind(b']]')
        if l >= 0 and r > l:
            got=parse_obj(json.loads(raw[l:r+2].decode('utf-8')))
            if got: return got
    except Exception:
        pass
    return []

def ema(vals,n):
    if not vals:return None
    k=2/(n+1); e=vals[0]
    for x in vals[1:]: e=x*k+e*(1-k)
    return e

def rsi(vals,n=14):
    if len(vals)<n+1:return None
    g=[]; l=[]
    for a,b in zip(vals[-n-1:-1],vals[-n:]):
        d=b-a; g.append(max(d,0)); l.append(max(-d,0))
    ag=sum(g)/n; al=sum(l)/n
    return 100.0 if al==0 else 100-(100/(1+ag/al))

def atr(cs,n=14):
    if len(cs)<2:return None
    tr=[]
    for i in range(1,len(cs)):
        h,l,c=cs[i][2],cs[i][3],cs[i][4]; pc=cs[i-1][4]
        tr.append(max(h-l,abs(h-pc),abs(l-pc)))
    return sum(tr[-n:])/min(n,len(tr)) if tr else None

def build_candles(pair):
    """Build a deterministic 1-minute stream.

    HARD SYNC RULES:
    1) Closed minutes come from the browser's authoritative OHLC history when
       available. Tick reconstruction is only a fallback for missing minutes.
    2) The current minute is NEVER taken from historical OHLC. It is rebuilt
       from live ticks/last_quote so the forming candle cannot freeze.
    3) History newer than the live bucket is ignored; this prevents a delayed
       history snapshot from becoming the chart's "current" candle.
    4) Every minute bucket exists at most once.
    """
    if not candle_dirty[pair] and candles[pair]:
        return

    now=time.time()
    lq=last_quote.get(pair)
    live_bucket=None
    if lq:
        try:
            live_bucket=int(norm_ts(lq[0])//60)*60
        except Exception:
            live_bucket=None

    # Reconstruct buckets from the retained quote stream.
    groups={}
    for raw_ts,p in list(ticks[pair]):
        try:
            ts=norm_ts(raw_ts); price=float(p)
        except Exception:
            continue
        if ts < 1e9 or price <= 0:
            continue
        b=int(ts//60)*60
        if live_bucket is not None and b > live_bucket:
            continue
        groups.setdefault(b,[]).append((ts,price))

    tick_map={}
    for b,pts in groups.items():
        pts.sort(key=lambda x:x[0])
        prices=[x[1] for x in pts]
        tick_map[b]=(b,prices[0],max(prices),min(prices),prices[-1])

    # R8.2: intentionally ignore browser-provided previous OHLC history.
    # Candles are built only from live ticks received after this server starts.
    # This prevents stale/wrong historical candles from contaminating the
    # current chart, SR engine, or signal calculations.

    # If there is no current tick group yet, seed ONLY the current candle from
    # the latest quote. Do not borrow O/H/L from a historical snapshot.
    if live_bucket is not None and lq:
        try:
            qts,qprice=norm_ts(lq[0]),float(lq[1])
            qb=int(qts//60)*60
            if qprice > 0 and qb == live_bucket:
                # Prefer the actual live tick group (it has the true current
                # open/high/low). Otherwise use the previous completed close
                # as a conservative live-candle open.
                existing=tick_map.get(qb)
                if existing:
                    tick_map[qb]=(qb,existing[1],max(existing[2],qprice),
                                  min(existing[3],qprice),qprice)
                else:
                    prev_close=None
                    prev_keys=[k for k in tick_map if k < qb]
                    if prev_keys:
                        prev_close=tick_map[max(prev_keys)][4]
                    op=float(prev_close if prev_close is not None else qprice)
                    tick_map[qb]=(qb,op,max(op,qprice),min(op,qprice),qprice)
        except Exception:
            pass

    # When the live feed is available, never let stale/future history decide
    # which candle is last. Keep all retained candles up to the live bucket.
    ordered=[tick_map[k] for k in sorted(tick_map)
             if live_bucket is None or k <= live_bucket]
    candles[pair]=deque(ordered[-10000:],maxlen=10000)
    candle_dirty[pair]=False


def original_v4_from_candles(cs, price=None):
    """Original V4-compatible core signal calculation from 1-minute candles.
    Kept deterministic so NORMAL mode and timeframe history never depend on
    optional FULL-analysis functions.
    """
    if not cs:
        return {'signal':'WAIT','score':0,'volatility':'LOW'}
    prices=[c[4] for c in cs]
    price=float(price if price is not None else prices[-1])
    if len(prices)<3:
        return {'signal':'WAIT','score':0,'volatility':'LOW'}
    e9,e21=ema(prices,9),ema(prices,21)
    rv=rsi(prices,14)
    av=atr(cs,14)
    vp=(av/price*100) if av and price else 0
    vol='LOW' if vp<0.03 else 'NORMAL' if vp<0.12 else 'HIGH'
    score=0
    if e9 is not None and e21 is not None: score += 30 if e9>e21 else -30
    if rv is not None:
        if rv>55: score += 20
        elif rv<45: score -= 20
    if len(prices)>=4: score += 20 if prices[-1]>prices[-4] else -20
    dirs=[1 if c[4]>c[1] else -1 if c[4]<c[1] else 0 for c in cs[-5:]]
    if sum(dirs)>=3: score += 20
    elif sum(dirs)<=-3: score -= 20
    score=max(-100,min(100,score))
    sig='CALL' if score>=50 else 'PUT' if score<=-50 else 'WAIT'
    return {'signal':sig,'score':score,'volatility':vol}

def analyze(pair):
    build_candles(pair); cs=list(candles[pair]); prices=[c[4] for c in cs]
    price=last_quote[pair][1]
    if len(prices)<3: return {'signal':'WAIT','score':0,'volatility':'LOW','rsi':None,'candles':len(cs)}
    e9,e21=ema(prices,9),ema(prices,21); rv=rsi(prices,14); av=atr(cs,14)
    vp=(av/price*100) if av and price else 0
    vol='LOW' if vp<0.03 else 'NORMAL' if vp<0.12 else 'HIGH'
    score=0
    if e9 and e21: score += 30 if e9>e21 else -30
    if rv is not None:
        if rv>55: score+=20
        elif rv<45: score-=20
    if len(prices)>=4: score += 20 if prices[-1]>prices[-4] else -20
    dirs=[1 if c[4]>c[1] else -1 if c[4]<c[1] else 0 for c in cs[-5:]]
    if sum(dirs)>=3: score+=20
    elif sum(dirs)<=-3: score-=20
    sig='CALL' if score>=50 else 'PUT' if score<=-50 else 'WAIT'
    return {'signal':sig,'score':max(-100,min(100,score)),'volatility':vol,'rsi':round(rv,2) if rv is not None else None,'candles':len(cs)}


def ema_series(vals, n, allow_short=False):
    # Standard EMA when enough samples exist; in FULL mode we allow a seeded
    # short-history EMA so the dashboard can show the live indicator while the
    # feed is building. This is marked as limited by the caller.
    if not vals: return None
    if len(vals) < n:
        if not allow_short: return None
        k=2/(n+1); e=vals[0]
        for x in vals[1:]: e=x*k+e*(1-k)
        return e
    k=2/(n+1); e=sum(vals[:n])/n
    for x in vals[n:]: e=x*k+e*(1-k)
    return e

def macd_line(vals, allow_short=False):
    a,b=ema_series(vals,12,allow_short),ema_series(vals,26,allow_short)
    return None if a is None or b is None else a-b

def rsi_flexible(vals,n=14):
    # RSI using all available changes when the feed has fewer than n+1 candles.
    # Once enough history exists this is the normal Wilder-style simple average
    # used by this project.
    if len(vals)<2: return None
    period=min(n,len(vals)-1)
    g=[]; l=[]
    for a,b in zip(vals[-period-1:-1],vals[-period:]):
        d=b-a; g.append(max(d,0)); l.append(max(-d,0))
    ag=sum(g)/period; al=sum(l)/period
    return 100.0 if al==0 else 100-(100/(1+ag/al))

def resample_5m(cs):
    groups={}
    for c in cs:
        b=(c[0]//300)*300
        groups.setdefault(b,[]).append(c)
    out=[]
    for b,g in sorted(groups.items()):
        out.append((b,g[0][1],max(x[2] for x in g),min(x[3] for x in g),g[-1][4]))
    return out

def resample_minutes(cs, minutes):
    step=minutes*60; groups={}
    for c in cs:
        b=(c[0]//step)*step
        groups.setdefault(b,[]).append(c)
    out=[]
    for b,g in sorted(groups.items()):
        out.append((b,g[0][1],max(x[2] for x in g),min(x[3] for x in g),g[-1][4]))
    return out

def candle_pattern(c):
    if not c: return 'NONE'
    o,h,l,cl=c[1],c[2],c[3],c[4]
    body=abs(cl-o); rng=max(h-l,1e-12)
    upper=h-max(o,cl); lower=min(o,cl)-l
    if body/rng < .18 and lower > body*2 and upper < body*1.2: return 'HAMMER'
    if body/rng < .18 and upper > body*2 and lower < body*1.2: return 'SHOOTING_STAR'
    return 'BULLISH' if cl>o else 'BEARISH' if cl<o else 'DOJI'


def structure_analysis(pair, cs=None):
    """Automatic completed-candle structure engine.

    Levels are built only from *previous completed candles*.  The current/forming
    candle is never used to invent a level.  The engine tracks the nearest
    support/resistance zones, breakout, post-breakout retest and rejection
    reversal.  A signal is emitted only when the completed candle confirms the
    structure event.
    """
    if cs is None:
        build_candles(pair); cs=list(candles[pair])
    if len(cs) < 10:
        return {'support':None,'resistance':None,'structure':'BUILDING','signal':'WAIT','confidence':0,
                'reason':'Need more previous candles for structure','zones':[],'event':'BUILDING'}

    now=time.time()
    # Keep only completed candles for level formation and confirmation.
    completed=[c for c in cs if c[0]+60 <= now]
    if len(completed) < 10:
        completed=cs[:-1] if len(cs)>1 else cs
    if len(completed) < 10:
        return {'support':None,'resistance':None,'structure':'BUILDING','signal':'WAIT','confidence':0,
                'reason':'Waiting for completed candle history','zones':[],'event':'BUILDING'}

    price=completed[-1][4]
    av=atr(completed,14) or max(abs(price)*0.0005,1e-12)
    tol=max(av*0.45, abs(price)*0.00020)

    # Confirmed swing points; latest two candles are not used as pivots.
    highs=[]; lows=[]
    for i in range(2,len(completed)-2):
        h=completed[i][2]; l=completed[i][3]
        if h>=max(completed[i-2][2],completed[i-1][2],completed[i+1][2],completed[i+2][2]): highs.append((completed[i][0],h))
        if l<=min(completed[i-2][3],completed[i-1][3],completed[i+1][3],completed[i+2][3]): lows.append((completed[i][0],l))

    def cluster(vals):
        zones=[]
        for ts,v in vals[-40:]:
            hit=None
            for z in zones:
                if abs(v-z['level'])<=tol:
                    z['level']=(z['level']*z['touches']+v)/(z['touches']+1)
                    z['touches']+=1; z['last_ts']=ts; hit=z; break
            if hit is None:
                zones.append({'level':float(v),'touches':1,'last_ts':ts})
        for z in zones:
            z['strength']=min(100,40+z['touches']*12)
        return zones

    rz=cluster(highs); sz=cluster(lows)
    # All automatically detected zones are returned to the chart.
    zones=[{'type':'S','level':round(z['level'],8),'touches':z['touches'],'strength':z['strength']} for z in sz]
    zones += [{'type':'R','level':round(z['level'],8),'touches':z['touches'],'strength':z['strength']} for z in rz]

    below=[z for z in sz if z['level']<=price+tol*1.5]
    above=[z for z in rz if z['level']>=price-tol*1.5]
    support=max(below,key=lambda z:(z['touches'],-abs(price-z['level']))) if below else None
    resistance=min(above,key=lambda z:(abs(price-z['level']),-z['touches'])) if above else None

    prev=completed[-2]; cur=completed[-1]
    body=abs(cur[4]-cur[1]); rng=max(cur[2]-cur[3],1e-12)
    bullish=cur[4]>cur[1]; bearish=cur[4]<cur[1]
    upper=cur[2]-max(cur[1],cur[4]); lower=min(cur[1],cur[4])-cur[3]
    structure='RANGE'; sig='WAIT'; conf=0; reason='No confirmed structure'; event='NONE'

    # Breakout uses the level that existed BEFORE the confirming candle.
    if resistance:
        r=resistance['level']
        if prev[4] <= r+tol and cur[4] > r+tol and bullish and body/rng>=0.45:
            structure='BREAKOUT_UP'; sig='CALL'; event='BREAKOUT_UP'
            conf=min(99,72+resistance['touches']*4+(10 if body/rng>=0.65 else 0))
            reason='Previous resistance broken by confirmed bullish candle'
        # Retest: current completed candle comes back to broken resistance,
        # but closes above it. Look back up to 3 candles for the breakout.
        else:
            for k in range(2,5):
                if len(completed)<=k: break
                b=completed[-k]
                if b[4] > r+tol and prev[3] <= r+tol and cur[4] > r and bullish and lower>=body*0.45:
                    structure='RETEST_UP'; sig='CALL'; event='BREAKOUT_RETEST_UP'
                    conf=min(99,78+resistance['touches']*4)
                    reason='Resistance breakout confirmed, then retest held above the level'
                    break
        if structure=='RANGE' and abs(price-r)<=tol*1.15 and bearish and upper>=body*0.8:
            structure='RESISTANCE_REVERSAL'; sig='PUT'; event='REVERSAL_DOWN'
            conf=min(99,74+resistance['touches']*4)
            reason='Previous resistance rejected price with bearish confirmation'

    if support and structure=='RANGE':
        r=support['level']
        if prev[4] >= r-tol and cur[4] < r-tol and bearish and body/rng>=0.45:
            structure='BREAKOUT_DOWN'; sig='PUT'; event='BREAKOUT_DOWN'
            conf=min(99,72+support['touches']*4+(10 if body/rng>=0.65 else 0))
            reason='Previous support broken by confirmed bearish candle'
        else:
            for k in range(2,5):
                if len(completed)<=k: break
                b=completed[-k]
                if b[4] < r-tol and prev[2] >= r-tol and cur[4] < r and bearish and upper>=body*0.45:
                    structure='RETEST_DOWN'; sig='PUT'; event='BREAKOUT_RETEST_DOWN'
                    conf=min(99,78+support['touches']*4)
                    reason='Support breakdown confirmed, then retest failed below the level'
                    break
        if structure=='RANGE' and abs(price-r)<=tol*1.15 and bullish and lower>=body*1.0:
            structure='SUPPORT_REVERSAL'; sig='CALL'; event='REVERSAL_UP'
            conf=min(99,74+support['touches']*4)
            reason='Previous support rejected price with bullish confirmation'

    if structure=='RANGE':
        if support and abs(price-support['level'])<=tol*1.5: reason='At automatic support zone — waiting for reversal or confirmed breakdown'
        elif resistance and abs(price-resistance['level'])<=tol*1.5: reason='At automatic resistance zone — waiting for reversal or confirmed breakout'

    return {'support':round(support['level'],8) if support else None,
            'resistance':round(resistance['level'],8) if resistance else None,
            'support_touches':support['touches'] if support else 0,
            'resistance_touches':resistance['touches'] if resistance else 0,
            'structure':structure,'signal':sig,'confidence':int(conf),'reason':reason,
            'event':event,'zones':zones}



def smart_sr_analysis(pair, base_cs=None):
    """Chart-only Smart MTF Support/Resistance zone engine.

    Uses confirmed pivots from 1M/5M/15M/1H/4H, merges nearby levels,
    adapts zone width to ATR, counts recent reactions/rejections and assigns
    a compact 0-100 strength score.  It never uses the forming candle to
    create a pivot, so the chart does not look ahead.
    """
    if base_cs is None:
        build_candles(pair); base_cs=list(candles[pair])
    now=time.time()
    completed=[c for c in base_cs if c[0]+60 <= now]
    if len(completed) < 12 and len(base_cs) > 1:
        completed=base_cs[:-1]
    if len(completed) < 8:
        return {'zones':[], 'summary':{'supports':0,'resistances':0,'strongest':0,'timeframes':[]}}

    tf_specs=[(1,2),(5,2),(15,2),(60,2),(240,2)]
    candidates=[]
    for minutes,left_right in tf_specs:
        if minutes==1:
            tfc=list(completed)
        else:
            tfc=resample_minutes(completed,minutes)
        if len(tfc) < left_right*2+3:
            continue
        at=atr(tfc,14) or 0.0
        # ATR in the source timeframe, with a small price-relative floor.
        px=tfc[-1][4]
        width=min(max(at*0.35, abs(px)*0.00012, 1e-12), abs(px)*0.0018)
        # Keep only recent confirmed pivots; higher TFs naturally contribute fewer.
        highs=[]; lows=[]
        for i in range(left_right,len(tfc)-left_right):
            c=tfc[i]
            if c[2] >= max(x[2] for x in tfc[i-left_right:i+left_right+1] if x is not c):
                highs.append((c[0],c[2]))
            if c[3] <= min(x[3] for x in tfc[i-left_right:i+left_right+1] if x is not c):
                lows.append((c[0],c[3]))
        tf_label={1:'1M',5:'5M',15:'15M',60:'1H',240:'4H'}[minutes]
        for ts,v in highs[-10:]:
            candidates.append({'type':'R','level':float(v),'width':width,'tf':tf_label,'ts':ts})
        for ts,v in lows[-10:]:
            candidates.append({'type':'S','level':float(v),'width':width,'tf':tf_label,'ts':ts})

    if not candidates:
        return {'zones':[], 'summary':{'supports':0,'resistances':0,'strongest':0,'timeframes':[]}}

    # Cluster same-direction levels in sorted price order.  The cluster span is
    # capped so nearby pivots cannot chain into a huge artificial zone.
    merged=[]
    for typ in ('S','R'):
        typed=sorted([x for x in candidates if x['type']==typ],key=lambda x:x['level'])
        clusters=[]
        for cand in typed:
            if not clusters:
                clusters.append([cand]); continue
            g=clusters[-1]
            levels=[x['level'] for x in g]
            widths=[x['width'] for x in g]
            center=sum(levels)/len(levels)
            maxw=max(max(widths),cand['width'])
            span=max(max(levels+[cand['level']])-min(levels+[cand['level']]),0)
            if abs(cand['level']-center) <= maxw*1.25 and span <= maxw*2.5:
                g.append(cand)
            else:
                clusters.append([cand])
        for g in clusters:
            levels=[x['level'] for x in g]; widths=[x['width'] for x in g]
            center=sum(levels)/len(levels); width=max(widths)
            half=min(width*1.5, max(width, (max(levels)-min(levels))/2 + width))
            merged.append({'type':typ,'level':center,'low':center-half,'high':center+half,
                           'width':width,'timeframes':sorted({x['tf'] for x in g},key=lambda x:['1M','5M','15M','1H','4H'].index(x)),
                           'pivots':[(x['ts'],x['level'],x['tf']) for x in g]})

    recent=completed[-180:]
    price=completed[-1][4]
    out=[]
    for z in merged:
        low,high=z['low'],z['high']
        touches=0; rejections=0
        first_touch=None; last_touch=None
        for i,c in enumerate(recent):
            o,h,l,cl=c[1],c[2],c[3],c[4]
            intersects=h>=low and l<=high
            if not intersects: continue
            touches+=1; last_touch=c[0]
            if first_touch is None: first_touch=c[0]
            rng=max(h-l,1e-12); body=abs(cl-o)
            if z['type']=='S':
                # Wick enters support and close recovers above it.
                if cl>high and (min(o,cl)-l) >= max(body*0.35,rng*0.18): rejections+=1
            else:
                if cl<low and (h-max(o,cl)) >= max(body*0.35,rng*0.18): rejections+=1

        # Break/retest state from completed candles only.
        status='FRESH'
        broken_idx=None
        if z['type']=='R':
            for i,c in enumerate(recent):
                if c[4] > high:
                    broken_idx=i
            if broken_idx is not None:
                status='BROKEN'
                for c in recent[broken_idx+1:]:
                    if c[3] <= high and c[4] > high:
                        status='RETEST'; break
        else:
            for i,c in enumerate(recent):
                if c[4] < low:
                    broken_idx=i
            if broken_idx is not None:
                status='BROKEN'
                for c in recent[broken_idx+1:]:
                    if c[2] >= low and c[4] < low:
                        status='RETEST'; break
        if status=='FRESH' and touches>1: status='TESTED'
        if status=='TESTED' and rejections==0 and touches>=5: status='WEAK'

        # Score: unique TF confluence + pivots + reactions + recency + rejection.
        tf_bonus=min(32, len(set(z['timeframes']))*10)
        pivot_bonus=min(18, len(z['pivots'])*5)
        reaction_bonus=min(20, touches*2.5)
        reject_bonus=min(18, rejections*4.5)
        recency_bonus=0
        if last_touch:
            age=max(0, now-last_touch)
            recency_bonus=max(0, 12*(1-min(age/(60*240),1)))
        distance_pct=abs(price-z['level'])/max(abs(price),1e-12)*100
        distance_penalty=min(18,distance_pct*8)
        status_bonus={'FRESH':6,'TESTED':8,'RETEST':12,'BROKEN':2,'WEAK':0}.get(status,4)
        strength=int(max(1,min(100,round(10+tf_bonus+pivot_bonus+reaction_bonus+reject_bonus+recency_bonus+status_bonus-distance_penalty))))
        # Human-readable zone identification: strength tells HOW strong the zone is;
        # zone_kind tells WHAT KIND of zone it is.  The label is deterministic and
        # based only on confirmed historical reactions/pivots (no forming-candle lookahead).
        conf=len(set(z['timeframes']))
        if status=='RETEST':
            zone_kind='RETEST '+('SUPPORT' if z['type']=='S' else 'RESISTANCE')
            kind_code='RETEST'
        elif conf>=3:
            zone_kind='MTF '+('SUPPORT' if z['type']=='S' else 'RESISTANCE')
            kind_code='MTF'
        elif rejections>=2:
            zone_kind='STRONG REJECTION'
            kind_code='REJECTION'
        elif z['type']=='S' and rejections>=1:
            zone_kind='DEMAND / SUPPORT'
            kind_code='DEMAND'
        elif z['type']=='R' and rejections>=1:
            zone_kind='SUPPLY / RESISTANCE'
            kind_code='SUPPLY'
        elif status=='FRESH':
            zone_kind='FRESH '+('SUPPORT' if z['type']=='S' else 'RESISTANCE')
            kind_code='FRESH'
        elif status=='TESTED':
            zone_kind='TESTED '+('SUPPORT' if z['type']=='S' else 'RESISTANCE')
            kind_code='TESTED'
        else:
            zone_kind=('SUPPORT' if z['type']=='S' else 'RESISTANCE')
            kind_code='BASE'
        rating='EXTREME' if strength>=91 else 'VERY STRONG' if strength>=76 else 'STRONG' if strength>=56 else 'MODERATE' if strength>=31 else 'WEAK'
        side='SUPPORT' if z['type']=='S' else 'RESISTANCE'
        zone_id=f"{z['type']}-{len(out)+1:02d}"
        # V6.7 intelligence layer: separate zone QUALITY from raw strength.
        # Quality rewards clean reactions, MTF agreement and freshness, while
        # penalizing repeated tests and broken zones.  This remains historical
        # only and never inspects the forming candle.
        freshness=max(0.0, min(1.0, recency_bonus/12.0))
        clean_reaction=min(1.0, rejections/max(1,touches))
        touch_quality=1.0 if 1 <= touches <= 4 else max(0.35, 1.0-(touches-4)*0.10)
        mtf_quality=min(1.0, conf/5.0)
        status_quality={'FRESH':1.0,'RETEST':0.95,'TESTED':0.78,'WEAK':0.40,'BROKEN':0.20}.get(status,0.60)
        raw_quality=(0.30*mtf_quality + 0.25*clean_reaction + 0.15*freshness + 0.15*touch_quality + 0.15*status_quality)
        quality_score=int(max(1,min(100,round(raw_quality*100))))
        quality='A+' if quality_score>=90 else 'A' if quality_score>=78 else 'B' if quality_score>=62 else 'C' if quality_score>=45 else 'D'
        if distance_pct<=0.15: distance_class='AT ZONE'
        elif distance_pct<=0.40: distance_class='NEAR'
        elif distance_pct<=1.00: distance_class='MID'
        else: distance_class='FAR'
        reasons=[]
        if conf>=2: reasons.append(f'{conf} TF confluence')
        if touches: reasons.append(f'{touches} touches')
        if rejections: reasons.append(f'{rejections} rejection'+('s' if rejections!=1 else ''))
        if status in ('FRESH','RETEST'): reasons.append(status)
        out.append({'type':z['type'],'side':side,'zone_id':zone_id,'zone_kind':zone_kind,'kind_code':kind_code,
                    'rating':rating,'label':f'{zone_id} · {zone_kind} · {rating}',
                    'level':round(z['level'],8),'low':round(low,8),'high':round(high,8),
                    'width':round(z['width'],8),'touches':touches,'rejections':rejections,
                    'pivot_count':len(z['pivots']),'timeframes':z['timeframes'],'confluence':conf,
                    'strength':strength,'status':status,'distance_pct':round(distance_pct,3),
                    'distance_class':distance_class,'quality_score':quality_score,'quality':quality,
                    'last_touch':last_touch,'reason':' · '.join(reasons)})

    # Zone conflict: if the strongest support and resistance are too close,
    # flag the area as tight/low-clearance instead of pretending both are clean.
    s_sorted=sorted([z for z in out if z['type']=='S'],key=lambda x:x['distance_pct'])
    r_sorted=sorted([z for z in out if z['type']=='R'],key=lambda x:x['distance_pct'])
    nearest_s=s_sorted[0] if s_sorted else None; nearest_r=r_sorted[0] if r_sorted else None
    conflict=None
    if nearest_s and nearest_r:
        clearance_pct=abs(nearest_r['level']-nearest_s['level'])/max(abs(price),1e-12)*100
        if clearance_pct<=0.35:
            conflict={'type':'TIGHT_S_R','clearance_pct':round(clearance_pct,3),'support_id':nearest_s['zone_id'],'resistance_id':nearest_r['zone_id'],'message':'TIGHT S/R AREA · LOW CLEARANCE'}
        elif clearance_pct<=0.70:
            conflict={'type':'CLOSE_S_R','clearance_pct':round(clearance_pct,3),'support_id':nearest_s['zone_id'],'resistance_id':nearest_r['zone_id'],'message':'CLOSE S/R AREA'}

    # Stable ranking: strongest/quality first, then proximity. IDs remain tied
    # to the current analytical snapshot so the engine never invents history.
    for z in out:
        z['rank_score']=int(round(z['strength']*0.60 + z['quality_score']*0.30 + max(0,10-min(z['distance_pct'],10))))
    ranked=sorted(out,key=lambda z:(-z['rank_score'],z['distance_pct']))
    for i,z in enumerate(ranked,1): z['rank']=i

    # Keep the chart readable: nearest/strongest zones around price, but do not
    # hide a strong HTF zone simply because it is a little farther away.
    supports=sorted([z for z in out if z['type']=='S'],key=lambda z:(0 if z['high']<=price else 1,-z['strength'],z['distance_pct']))
    resistances=sorted([z for z in out if z['type']=='R'],key=lambda z:(0 if z['low']>=price else 1,-z['strength'],z['distance_pct']))
    def pick(arr):
        near=[z for z in arr if z['distance_pct']<=3.0]
        chosen=sorted(near,key=lambda z:(-z['strength'],z['distance_pct']))[:8]
        for z in arr:
            if z not in chosen and len(chosen)<10 and z['strength']>=70:
                chosen.append(z)
        return sorted(chosen,key=lambda z:z['distance_pct'])[:10]
    selected=pick(supports)+pick(resistances)
    selected=sorted(selected,key=lambda z:z['distance_pct'])
    strongest=max((z['strength'] for z in selected),default=0)
    selected_ids={z['zone_id'] for z in selected}
    selected_ranked=sorted([z for z in ranked if z['zone_id'] in selected_ids],key=lambda z:z['rank'])
    top_support=max((z for z in selected if z['type']=='S'),key=lambda z:z['rank_score'],default=None)
    top_resistance=max((z for z in selected if z['type']=='R'),key=lambda z:z['rank_score'],default=None)
    return {'zones':selected_ranked,
            'summary':{'supports':sum(z['type']=='S' for z in selected_ranked),
                       'resistances':sum(z['type']=='R' for z in selected_ranked),
                       'strongest':strongest,
                       'top_support':top_support['zone_id'] if top_support else None,
                       'top_support_strength':top_support['strength'] if top_support else 0,
                       'top_resistance':top_resistance['zone_id'] if top_resistance else None,
                       'top_resistance_strength':top_resistance['strength'] if top_resistance else 0,
                       'conflict':conflict,
                       'timeframes':sorted({tf for z in selected_ranked for tf in z['timeframes']},key=lambda x:['1M','5M','15M','1H','4H'].index(x))}}


def zone_reaction_engine(pair, base_cs, smart):
    """Live descriptive reaction layer built from confirmed candles only.
    It labels recent zone interactions and simple market-structure events without
    changing the scanner signal logic or creating synthetic candles."""
    now=time.time()
    cs=[c for c in (base_cs or []) if c[0]+60 <= now]
    if len(cs)>80 and len(cs): cs=cs[-120:]
    zones=list((smart or {}).get('zones',[]))
    events=[]
    for z in zones:
        low,high=z.get('low'),z.get('high')
        if low is None or high is None or not cs: continue
        recent=cs[-8:]
        last_event=None
        for i,c in enumerate(recent):
            o,h,l,cl=c[1],c[2],c[3],c[4]
            hit=h>=low and l<=high
            if not hit: continue
            if z.get('type')=='S':
                if cl>high and (min(o,cl)-l) >= max(abs(cl-o)*0.30,(h-l)*0.15):
                    last_event=('REJECTION',c[0])
                elif cl<low:
                    last_event=('BREAKOUT',c[0])
            else:
                if cl<low and (h-max(o,cl)) >= max(abs(cl-o)*0.30,(h-l)*0.15):
                    last_event=('REJECTION',c[0])
                elif cl>high:
                    last_event=('BREAKOUT',c[0])
        if last_event:
            events.append({'zone_id':z.get('zone_id'),'type':last_event[0],'side':z.get('side'),
                           'strength':z.get('strength',0),'time':last_event[1]})
    # Simple confirmed swing sequence for BOS / CHoCH context.
    swings=[]
    if len(cs)>=9:
        for i in range(2,len(cs)-2):
            h=cs[i][2]; l=cs[i][3]
            if h>=max(cs[j][2] for j in range(i-2,i)) and h>=max(cs[j][2] for j in range(i+1,i+3)):
                swings.append(('H',cs[i][0],h))
            if l<=min(cs[j][3] for j in range(i-2,i)) and l<=min(cs[j][3] for j in range(i+1,i+3)):
                swings.append(('L',cs[i][0],l))
    highs=[x for x in swings if x[0]=='H'][-3:]
    lows=[x for x in swings if x[0]=='L'][-3:]
    structure_event='NONE'; structure_detail='Waiting for confirmed swing structure'
    if len(highs)>=2 and len(lows)>=2:
        hh=highs[-1][2]>highs[-2][2]; hl=lows[-1][2]>lows[-2][2]
        lh=highs[-1][2]<highs[-2][2]; ll=lows[-1][2]<lows[-2][2]
        if hh and hl: structure_event='BULLISH STRUCTURE'; structure_detail='Higher High + Higher Low'
        elif lh and ll: structure_event='BEARISH STRUCTURE'; structure_detail='Lower High + Lower Low'
        elif hh and ll: structure_event='CHoCH'; structure_detail='Conflicting swing direction — possible transition'
        else: structure_event='RANGE STRUCTURE'; structure_detail='Mixed / overlapping confirmed swings'
        last_close=cs[-1][4]
        if highs[-1][2] < last_close: structure_event='BOS UP'; structure_detail='Close above latest confirmed swing high'
        elif lows[-1][2] > last_close: structure_event='BOS DOWN'; structure_detail='Close below latest confirmed swing low'
    # Zone nearest to live price, using current quote when available.
    price=last_quote.get(pair,(None,cs[-1][4] if cs else None))[1]
    nearest=min(zones,key=lambda z:abs(price-z['level']) if price is not None else 1e99,default=None)
    active_event=None
    if events:
        active_event=sorted(events,key=lambda e:(-e.get('strength',0),-e.get('time',0)))[0]
    return {'nearest_zone_id':nearest.get('zone_id') if nearest else None,
            'nearest_zone_kind':nearest.get('zone_kind') if nearest else None,
            'nearest_zone_strength':nearest.get('strength') if nearest else 0,
            'nearest_zone_distance':nearest.get('distance_pct') if nearest else None,
            'active_reaction':active_event,
            'recent_reactions':events[-8:],
            'structure_event':structure_event,
            'structure_detail':structure_detail}

def full_analysis(pair, base):
    """FULL mode: calculate every indicator independently from completed data.

    NORMAL mode never calls this function.  Short feeds no longer blank every
    indicator: EMA/MACD/RSI/pattern are shown from available completed candles,
    while 5M/1H values explicitly remain BUILDING until enough time has elapsed.
    """
    raw_cs=list(candles[pair]); cs=raw_cs[:-1] if len(raw_cs)>1 else raw_cs
    prices=[c[4] for c in cs]
    st=structure_analysis(pair, cs) if settings.get('structure_analysis',True) else {'support':None,'resistance':None,'structure':'OFF','signal':'WAIT','confidence':0,'reason':'Structure analysis OFF','zones':[]}
    if len(prices)<2:
        base.update({'confidence':0,'ema':'BUILDING','macd':None,'trend5m':'BUILDING',
                     'trend_1h':'BUILDING','pattern':'NONE','quality':'BUILDING',
                     'reason':f'FULL ANALYSIS: waiting for completed candles ({len(prices)})'})
        return base

    e9=ema_series(prices,9,allow_short=True)
    e21=ema_series(prices,21,allow_short=True)
    ml=macd_line(prices,allow_short=True)
    rv=rsi_flexible(prices,14)

    raw_c5=resample_5m(cs); c5=raw_c5[:-1] if len(raw_c5)>1 else raw_c5
    p5=[c[4] for c in c5]
    e5a=ema_series(p5,3,allow_short=True)
    e5b=ema_series(p5,6,allow_short=True)
    trend5='BULLISH' if e5a is not None and e5b is not None and e5a>e5b else 'BEARISH' if e5a is not None and e5b is not None else 'BUILDING'

    # Prefer real completed hourly bars. If fewer than two exist, use a rolling
    # one-hour tick comparison when the captured feed spans a full hour.
    h=[]; hg={}
    for c in cs:
        b=(c[0]//3600)*3600; hg.setdefault(b,[]).append(c)
    for b,g in sorted(hg.items()):
        h.append((b,g[0][1],max(x[2] for x in g),min(x[3] for x in g),g[-1][4]))
    hp=[x[4] for x in h]
    if len(hp)>=2:
        trend1h='BULLISH' if hp[-1]>hp[-2] else 'BEARISH' if hp[-1]<hp[-2] else 'FLAT'
    else:
        now=time.time(); recent=[(t,p) for t,p in list(ticks[pair]) if now-t<=3600]
        if recent and now-min(t for t,_ in recent)>=3300:
            first=recent[0][1]; last=recent[-1][1]
            trend1h='BULLISH' if last>first else 'BEARISH' if last<first else 'FLAT'
        else:
            span=int(now-min(t for t,_ in recent)) if recent else 0
            trend1h=f'BUILDING ({min(60,span//60)}/60m)'

    pat=candle_pattern(cs[-1])
    sig=base.get('signal','WAIT')
    reasons=[]
    ema_dir='BULLISH' if e9>e21 else 'BEARISH' if e9<e21 else 'FLAT'
    limited=len(prices)<26

    if sig not in ('CALL','PUT'):
        base.update({'confidence':0,'ema':ema_dir,'macd':round(ml,8) if ml is not None else None,
                     'trend5m':trend5,'trend_1h':trend1h,'pattern':pat,
                     'quality':'BUILDING' if limited else 'READY',
                     'reason':'Original V4 core is WAIT | FULL indicators calculated'})
        return base

    want='BULLISH' if sig=='CALL' else 'BEARISH'
    checks=[]; passed=0
    def gate(name, ok, available=True):
        nonlocal passed
        if available:
            checks.append((name,bool(ok)))
            if ok: passed+=1

    if settings.get('filter_5m'):
        gate('5M confirmation', trend5==want, trend5 in ('BULLISH','BEARISH'))
    if settings.get('filter_macd'):
        gate('MACD', (ml>0 if sig=='CALL' else ml<0), ml is not None)
    if settings.get('filter_rsi'):
        gate('RSI', ((50<=rv<=70) if sig=='CALL' else (30<=rv<=50)), rv is not None)
    if settings.get('filter_pattern'):
        good=('HAMMER','BULLISH') if sig=='CALL' else ('SHOOTING_STAR','BEARISH')
        gate('Candle pattern', pat in good, pat!='NONE')
    if settings.get('filter_volatility'):
        av=atr(cs,14); price=prices[-1]; vp=(av/price*100) if av and price else 0
        gate('Volatility', av is not None and vp>=0.01, av is not None)
    if settings.get('strict_score'):
        gate('Strict score', abs(float(base.get('score') or 0))>=70, True)
    if settings.get('smart_confluence'):
        hdir=trend1h if trend1h in ('BULLISH','BEARISH') else None
        tdir=trend5 if trend5 in ('BULLISH','BEARISH') else None
        gate('1H trend + 5M confirmation', hdir==want and tdir==want, hdir is not None and tdir is not None)
    if settings.get('filter_structure'):
        gate('Structure', st.get('signal')==sig, st.get('structure') not in ('BUILDING','OFF'))

    total=len(checks)
    ok=(passed==total) if total else True
    if not ok:
        sig_out='WAIT'
        reason='FULL FILTER BLOCK: '+', '.join(n for n,v in checks if not v)
    else:
        sig_out=sig
        reason='FULL ANALYSIS '+(' | '.join(n for n,v in checks if v) if checks else 'no optional filters')
    conf=round((passed/total)*100) if total else min(99,abs(float(base.get('score') or 0)))
    if limited: reason += f' | indicator history {len(prices)}/26 (building)'
    base.update({'signal':sig_out,'confidence':conf,'ema':ema_dir,
                 'macd':round(ml,8) if ml is not None else None,
                 'trend5m':trend5,'trend_1h':trend1h,'pattern':pat,
                 'structure':st.get('structure'),'structure_signal':st.get('signal'),'support':st.get('support'),'resistance':st.get('resistance'),
                 'structure_confidence':st.get('confidence',0),'structure_reason':st.get('reason',''),
                 'quality':'BUILDING' if limited else 'READY','reason':reason})
    return base


def make_1m_signal(pair):
    cs=list(candles[pair]);
    if len(cs)<3: return {'signal':'WAIT','score':0,'confidence':0,'reason':'Need more 1M candle history'}
    a=original_v4_from_candles(cs, last_quote[pair][1])
    return confirmation_allowed({'signal':a['signal'],'score':a['score'],'confidence':min(99,abs(a['score'])),'reason':'Original V4 core'})

def make_2m_signal(pair):
    return _timeframe_signal(pair,2)

def _timeframe_signal(pair, minutes):
    build_candles(pair)
    cs=resample_minutes(list(candles[pair]), minutes)
    # Exclude the currently forming higher-timeframe candle.
    completed=cs[:-1] if len(cs)>1 else []
    if len(completed)<3:
        return {'signal':'WAIT','score':0,'confidence':0,'reason':f'{minutes}M building — need completed candles'}
    prices=[c[4] for c in completed]
    e3=ema(prices,3); e6=ema(prices,6); score=0
    if e3 is not None and e6 is not None: score += 40 if e3>e6 else -40
    if len(prices)>=3: score += 30 if prices[-1]>prices[-3] else -30
    dirs=[1 if c[4]>c[1] else -1 if c[4]<c[1] else 0 for c in completed[-3:]]
    if sum(dirs)>=2: score += 30
    elif sum(dirs)<=-2: score -= 30
    score=max(-100,min(100,score))
    sig='CALL' if score>=60 else 'PUT' if score<=-60 else 'WAIT'
    return confirmation_allowed({'signal':sig,'score':score,'confidence':min(99,abs(score)),'reason':f'{minutes}M completed-candle signal'})

def make_5m_signal(pair):
    return _timeframe_signal(pair,5)

def make_10m_signal(pair):
    return _timeframe_signal(pair,10)

def make_hour_trend(pair):
    # 1H trend is calculated from completed hourly structure.  The previous
    # version required 3 full hourly candles, which made the UI show UNKNOWN
    # for most sessions.  We now use 3+ completed hours when available, and
    # a deterministic completed-hour / rolling-60m fallback while building.
    build_candles(pair)
    cs=list(candles[pair])
    if len(cs) < 2:
        return 'BUILDING'
    groups={}
    for c in cs:
        b=(c[0]//3600)*3600
        groups.setdefault(b,[]).append(c)
    h=[]
    for b,g in sorted(groups.items()):
        h.append((b,g[0][1],max(x[2] for x in g),min(x[3] for x in g),g[-1][4]))
    # Ignore the currently forming hour for trend direction.
    completed=h[:-1] if len(h)>1 else []
    if len(completed)>=3:
        prices=[x[4] for x in completed]
        e3=ema(prices,3); e8=ema(prices,8)
        if e3 is not None and e8 is not None:
            if e3 > e8: return 'BULLISH'
            if e3 < e8: return 'BEARISH'
        # Higher-high / higher-low vs lower-high / lower-low fallback.
        a,b=completed[-2],completed[-1]
        if b[4]>a[4] and b[2]>=a[2] and b[3]>=a[3]: return 'BULLISH'
        if b[4]<a[4] and b[2]<=a[2] and b[3]<=a[3]: return 'BEARISH'
        return 'SIDEWAYS'
    if completed:
        c=completed[-1]
        body=c[4]-c[1]; rng=max(c[2]-c[3],1e-12)
        if abs(body)/rng < 0.12: return 'SIDEWAYS'
        return 'BULLISH' if body>0 else 'BEARISH'
    # If no hour has closed yet, use a rolling 55-60 minute comparison.
    now=time.time()
    recent=[(t,p) for t,p in list(ticks[pair]) if now-t<=3600]
    if len(recent)>=2:
        first,last=recent[0][1],recent[-1][1]
        move=last-first
        threshold=max(abs(first)*0.00005, 1e-12)
        if move>threshold: return 'BULLISH'
        if move<-threshold: return 'BEARISH'
        return 'SIDEWAYS'
    return 'BUILDING'

def smart_confluence(pair, one, five, hour):
    # Optional full-analysis layer. Original V4 remains untouched in NORMAL mode.
    sig=one['signal']
    if sig not in ('CALL','PUT'): return 'WAIT',0,'1M is WAIT'
    want='BULLISH' if sig=='CALL' else 'BEARISH'
    score=abs(one['score'])
    if five['signal']==sig: score += 25
    else: return 'WAIT',score,'5M confirmation not aligned'
    if hour==want: score += 15
    elif hour!='UNKNOWN': return 'WAIT',score,'1H trend not aligned'
    return sig,min(100,score),'1H trend + 5M confirmation + original V4'

def signal_quality_guard(pair, signal, base, one, two, five, ten, st, smart, reaction, mstate):
    """Optional live quality guard. OFF preserves the existing signal engine.

    This is a risk/quality gate, not a new signal generator. It scores the
    already-generated signal using completed-candle S/R context, timeframe
    agreement and market conflict. The raw V4 signal remains available as
    raw_signal so users can compare guarded vs unguarded behavior.
    """
    sig=str(signal or 'WAIT').upper()
    if sig not in ('CALL','PUT'):
        return {'enabled':bool(settings.get('signal_quality_guard',False)),'pass':True,'score':0,'reason':'No directional signal to guard'}
    score=float(base.get('confidence') or abs(float(base.get('score') or 0)))
    reasons=[]
    # Core signal quality: retain the original score, but require a reasonably
    # directional setup when the optional guard is enabled.
    if abs(float(base.get('score') or 0)) >= 70:
        score += 8; reasons.append('core score strong')
    elif abs(float(base.get('score') or 0)) >= 60:
        score += 3; reasons.append('core score acceptable')
    else:
        reasons.append('core score weak')

    dirs=[str(x.get('signal','WAIT')).upper() for x in (one,two,five,ten)]
    matching=sum(1 for x in dirs if x==sig)
    if matching>=3:
        score += 14; reasons.append(f'{matching}/4 TF aligned')
    elif matching>=2:
        score += 8; reasons.append(f'{matching}/4 TF aligned')
    else:
        score -= 8; reasons.append(f'only {matching}/4 TF aligned')

    conflict=(smart or {}).get('summary',{}).get('conflict')
    if conflict and conflict.get('type')=='TIGHT_S_R':
        score -= 25; reasons.append('tight S/R conflict')
    elif conflict:
        score -= 8; reasons.append('close S/R conflict')

    zones=list((smart or {}).get('zones',[]))
    active=None
    if zones:
        want='SUPPORT' if sig=='CALL' else 'RESISTANCE'
        candidates=[z for z in zones if z.get('side')==want and z.get('distance_pct') is not None and float(z.get('distance_pct') or 999)<=0.60]
        if candidates:
            active=max(candidates,key=lambda z:float(z.get('rank_score',0) or 0))
            score += 12 if active.get('status') in ('RETEST','FRESH') else 7
            score += 5 if float(active.get('quality_score',0) or 0)>=62 else 0
            reasons.append(f"{active.get('zone_kind',want)} nearby")
        else:
            opposite='RESISTANCE' if sig=='CALL' else 'SUPPORT'
            opp=[z for z in zones if z.get('side')==opposite and z.get('distance_pct') is not None and float(z.get('distance_pct') or 999)<=0.35]
            if opp:
                score -= 15; reasons.append(f'{opposite} too close')
            else:
                reasons.append('no strong directional zone nearby')
    else:
        reasons.append('S/R history building')

    rx=(reaction or {}).get('nearest_zone_kind')
    if rx and any(k in str(rx).upper() for k in ('RETEST','REJECTION')):
        score += 5; reasons.append('recent zone reaction')

    vol=str((mstate or {}).get('volatility') or '').upper()
    if vol in ('EXTREME','HIGH'):
        score -= 5; reasons.append('high volatility caution')

    final=max(0,min(100,round(score)))
    passed=final>=70 and not (conflict and conflict.get('type')=='TIGHT_S_R')
    return {'enabled':True,'pass':passed,'score':final,'reason':' · '.join(reasons),'zone_id':active.get('zone_id') if active else None}


def confirmation_allowed(result):
    # Optional global confirmation gate. OFF preserves the existing signal engine.
    if not settings.get('confirmation_70', False):
        return result
    r=dict(result)
    sig=r.get('signal')
    conf=float(r.get('confidence') or 0)
    if sig in ('CALL','PUT') and conf < 70:
        r['signal']='WAIT'
        r['reason']=(r.get('reason') or '') + (' | 70%+ confirmation required')
    return r


# Accuracy reporting layer — derived directly from live signal history.

def performance_summary():
    rows=list(signal_history)
    def band(v):
        try:
            x=float(v or 0)
        except Exception:
            x=0
        if x>=90: return '90-100%'
        if x>=80: return '80-89%'
        if x>=70: return '70-79%'
        return '<70%'
    def group(key):
        out={}
        for r in rows:
            g=(band(r.get('confidence')) if key=='__confband__' else r.get(key,'UNKNOWN'))
            d=out.setdefault(g,{'signals':0,'wins':0,'losses':0,'pending':0})
            d['signals']+=1
            if r.get('status')=='WIN': d['wins']+=1
            elif r.get('status')=='LOSS': d['losses']+=1
            else: d['pending']+=1
        for d in out.values():
            n=d['wins']+d['losses']
            d['win_rate']=round(d['wins']/n*100,1) if n else 0
        return out
    return {'total':len(rows),'timeframe':group('tf'),'pair':group('pair'),'confirmation':group('__confband__'),'recent':rows[:100]}


def structure_performance_summary():
    """Accuracy/backtest reporting for S/R structure signals only."""
    rows=list(structure_history)
    def band(v):
        try: x=float(v or 0)
        except Exception: x=0
        if x>=90: return '90-100%'
        if x>=80: return '80-89%'
        if x>=70: return '70-79%'
        return '<70%'
    def group(key):
        out={}
        for r in rows:
            g=band(r.get('confidence')) if key=='__confband__' else r.get(key,'UNKNOWN')
            d=out.setdefault(g,{'signals':0,'wins':0,'losses':0,'draws':0,'pending':0})
            d['signals']+=1
            if r.get('status')=='WIN': d['wins']+=1
            elif r.get('status')=='LOSS': d['losses']+=1
            elif r.get('status')=='DRAW': d['draws']+=1
            else: d['pending']+=1
        for d in out.values():
            n=d['wins']+d['losses']
            d['win_rate']=round(d['wins']/n*100,1) if n else 0
        return out
    done=[r for r in rows if r.get('status') in ('WIN','LOSS','DRAW')]
    wins=sum(r.get('status')=='WIN' for r in done)
    losses=sum(r.get('status')=='LOSS' for r in done)
    return {'total':len(rows),'completed':len(done),'wins':wins,'losses':losses,
            'draws':sum(r.get('status')=='DRAW' for r in done),
            'pending':sum(r.get('status')=='PENDING' for r in rows),
            'win_rate':round(wins/(wins+losses)*100,1) if wins+losses else 0,
            'timeframe':group('tf'),'pair':group('pair'),
            'confirmation':group('__confband__'),'event':group('event'),
            'recent':rows[:100]}

def validation_file_summary():
    """Persistent validation summary from completed_signals.csv.

    This survives server restarts and is reporting-only. It never controls a
    Quotex account or places orders.
    """
    path=None
    if validator is not None:
        path=getattr(validator,'completed_path',None)
    if not path or not os.path.exists(path):
        return {'available':False,'rows':0,'wins':0,'losses':0,'draws':0,'win_rate':0,'timeframe':{}}
    rows=[]
    try:
        import csv
        with open(path,newline='',encoding='utf-8-sig') as f:
            for r in csv.DictReader(f):
                result=str(r.get('result','')).upper().strip()
                if result not in ('WIN','LOSS','DRAW'): continue
                rows.append(r)
    except Exception:
        log.exception('Persistent validation summary failed')
        return {'available':False,'rows':0,'wins':0,'losses':0,'draws':0,'win_rate':0,'timeframe':{}}
    def st(items):
        w=sum(str(x.get('result','')).upper()=='WIN' for x in items)
        l=sum(str(x.get('result','')).upper()=='LOSS' for x in items)
        d=sum(str(x.get('result','')).upper()=='DRAW' for x in items)
        return {'trades':len(items),'wins':w,'losses':l,'draws':d,'win_rate':round(w/(w+l)*100,1) if w+l else 0}
    by={}
    for tf in sorted({str(r.get('timeframe') or 'UNKNOWN') for r in rows}):
        by[tf]=st([r for r in rows if str(r.get('timeframe') or 'UNKNOWN')==tf])
    x=st(rows)
    return {'available':True,'path':str(path),'rows':len(rows),'wins':x['wins'],'losses':x['losses'],'draws':x['draws'],'win_rate':x['win_rate'],'timeframe':by}


def pair_enabled(pair):
    if not settings.get('pair_filter_enabled',False): return True
    return pair in (settings.get('enabled_pairs') or [])

def timeframe_enabled(tf):
    if tf=='1M': return bool(settings.get('signal_1m',True))
    if tf=='2M': return bool(settings.get('signal_2m',True))
    if tf=='5M': return bool(settings.get('signal_5m',True))
    if tf=='10M': return bool(settings.get('signal_10m',True))
    return True

def directional(signal, entry, exit_price):
    """Resolve a directional CALL/PUT result from entry vs target close.
    Equal prices are treated as DRAW so history never crashes or invents a win/loss.
    """
    try:
        e=float(entry); x=float(exit_price)
    except Exception:
        return 'DRAW'
    if signal=='CALL':
        return 'WIN' if x>e else 'LOSS' if x<e else 'DRAW'
    if signal=='PUT':
        return 'WIN' if x<e else 'LOSS' if x>e else 'DRAW'
    return 'DRAW'


def _log_completed(h, pair, tf, exit_price, outcome):
    if not validator: return
    try:
        validator.complete(signal_id=h.get('signal_id'),timestamp=h.get('time'),pair=pair,signal=h.get('signal'),timeframe=tf,entry=h.get('entry'),confirmation=h.get('confidence'),score=h.get('score'),structure=h.get('structure',''),event=h.get('event',''),reason=h.get('reason',''),expiry_time=h.get('expiry_time'),expiry_price=exit_price,result=outcome,result_time=h.get('result_time'),resolution='TARGET_CANDLE_CLOSE',move=h.get('move'))
    except Exception:
        log.exception('Failed to record completed validation signal')

def _resolve_for_bar(pair, tf, target_bar, exit_price, result_ts):
    for h in list(signal_history):
        if h.get('status')=='PENDING' and h.get('tf')==tf and h.get('pair')==pair and h.get('target_bar')==target_bar:
            outcome=directional(h['signal'], h['entry'], exit_price)
            h.update({'status':outcome,'exit':exit_price,'move':round(float(exit_price)-float(h['entry']),8),'result_time':fmt_market_time(result_ts),
                      'result_epoch':result_ts,'resolution':'TARGET_CANDLE_CLOSE'})
            _log_completed(h,pair,tf,exit_price,outcome)

def _append_signal(tf, pair, signal, entry, signal_bar, target_bar, score=0, confidence=0, expiry_bar=None):
    if signal not in ('CALL','PUT') or not settings.get('signal_'+tf.lower(), True): return
    if settings.get('confirmation_70', False) and float(confidence or 0) < 70: return
    if any(h.get('pair')==pair and h.get('tf')==tf and h.get('signal_bar')==signal_bar for h in signal_history): return
    expiry_bar = target_bar if expiry_bar is None else expiry_bar
    signal_id=f"{pair}|{tf}|{int(signal_bar)}|{uuid.uuid4().hex[:8]}"
    row={'signal_id':signal_id,'tf':tf,'pair':pair,'signal':signal,'entry':entry,'signal_bar':signal_bar,
        'target_bar':target_bar,'status':'PENDING','exit':None,'result_time':None,
        'signal_epoch':signal_bar,'entry_epoch':signal_bar,'expiry_epoch':expiry_bar,
        'time':fmt_market_time(signal_bar),'entry_time':fmt_market_time(signal_bar),
        'expiry_time':fmt_market_time(expiry_bar),'score':score,'confidence':confidence,
        'trend':'','pattern':'','sr_condition':'','ema':'','rsi':'','macd':'','structure':'','event':'','reason':'','resolution':'PENDING_TARGET_CLOSE'}
    signal_history.appendleft(row)
    if validator:
        try:
            validator.record(signal_id=signal_id,timestamp=row['time'],pair=pair,signal=signal,timeframe=tf,entry=entry,confirmation=confidence,score=score,expiry_time=row['expiry_time'])
        except Exception: log.exception('Failed to record validation signal')

def _tf_score(hist):
    """Simple deterministic completed-candle direction score for higher TFs."""
    prices=[c[4] for c in hist]
    score=0
    e3,e6=ema(prices,3),ema(prices,6)
    if e3 is not None and e6 is not None:
        score += 40 if e3>e6 else -40
    if len(prices)>=3:
        score += 30 if prices[-1]>prices[-3] else -30
    dirs=[1 if c[4]>c[1] else -1 if c[4]<c[1] else 0 for c in hist[-3:]]
    if sum(dirs)>=2: score += 30
    elif sum(dirs)<=-2: score -= 30
    sig='CALL' if score>=60 else 'PUT' if score<=-60 else 'WAIT'
    return sig,score,min(99,abs(score))

def backfill_history_signals(pair):
    """Disabled in R8.2: no previous/history candles are backfilled."""
    return

# Legacy implementation intentionally removed from the live path.

"""
    if not pair_enabled(pair): return
    build_candles(pair)
    cs=sorted(list(candles[pair]), key=lambda c:c[0])
    if len(cs)<4: return

    def has_signal(hist, tf, bar):
        return any(h.get('pair')==pair and h.get('tf')==tf and
                   h.get('signal_bar')==bar for h in signal_history)

    # 1M walk-forward backfill. The current/latest candle is treated as forming.
    if settings.get('signal_1m',True):
        for i in range(3, max(3, len(cs)-1)):
            target=cs[i]
            if has_signal(cs[:i], '1M', target[0]):
                continue
            base=original_v4_from_candles(cs[:i], cs[i-1][4])
            _append_signal('1M',pair,base['signal'],target[1],target[0],target[0],
                           base['score'],min(99,abs(base['score'])),expiry_bar=target[0]+60)
            _resolve_for_bar(pair,'1M',target[0],target[4],target[0]+60)

    # Higher timeframes: only completed target groups are backfilled.
    for tf,minutes in (('2M',2),('5M',5),('10M',10)):
        if not settings.get('signal_'+tf.lower(),True):
            continue
        grouped=resample_minutes(cs,minutes)
        if len(grouped)<4: continue
        for i in range(2, len(grouped)-1):
            target=grouped[i]
            if has_signal(grouped[:i], tf, target[0]):
                continue
            hist=grouped[:i]
            sig,score,conf=_tf_score(hist)
            _append_signal(tf,pair,sig,target[1],target[0],target[0],score,conf,
                           expiry_bar=target[0]+minutes*60)
            _resolve_for_bar(pair,tf,target[0],target[4],target[0]+minutes*60)

    # Historical S/R structure markers for 1M/5M/10M.
    for tf,minutes in (('1M',1),('2M',2),('5M',5),('10M',10)):
        if not _structure_tf_enabled(tf):
            continue
        grouped=resample_minutes(cs,minutes)
        if len(grouped)<5: continue
        for i in range(4, len(grouped)-1):
            target=grouped[i]
            if any(h.get('pair')==pair and h.get('tf')==tf and
                   h.get('signal_bar')==target[0] for h in structure_history):
                continue
            st=structure_analysis(pair, grouped[:i])
            if st.get('signal') not in ('CALL','PUT'):
                continue
            _append_structure_signal(pair,tf,st,target[0],target[1],minutes*60)
            _resolve_structure_for_bar(pair,tf,target[0],target[4],target[0]+minutes*60)

"""

def update_history(pair):
    if not pair_enabled(pair): return
    build_candles(pair)
    cs=list(candles[pair])
    if len(cs)<4: return

    # A signal is generated at the FIRST TICK of the next target candle.
    # The entry price is that target candle's open. The result is resolved
    # immediately when that target candle closes, with exact epoch timestamps.
    def process_tf(tf, minutes, marker):
        if not settings.get('signal_'+tf.lower(), True):
            return
        grouped=resample_minutes(cs,minutes)
        if len(grouped)<3:
            return
        newest=grouped[-1]
        if marker[pair] == newest[0]:
            return
        marker[pair]=newest[0]
        completed=grouped[-2]
        target=newest
        # Resolve the trade whose target candle just closed.
        _resolve_for_bar(pair,tf,completed[0],completed[4],newest[0]+minutes*60)
        hist=grouped[:-1]
        sig,score,conf=_tf_score(hist)
        # Entry is the current target candle open, signal/trade time is its start.
        _append_signal(tf,pair,sig,target[1],target[0],target[0],score,conf, expiry_bar=target[0]+minutes*60)

    # 1M keeps the original V4 core for signal generation, but uses the
    # exact next-candle entry and expiry timestamps.
    if settings.get('signal_1m',True):
        newest=cs[-1]
        if last_completed_1m[pair] != newest[0]:
            last_completed_1m[pair]=newest[0]
            completed=cs[-2]
            _resolve_for_bar(pair,'1M',completed[0],completed[4],newest[0]+60)
            base=original_v4_from_candles(cs[:-1], completed[4])
            _append_signal('1M',pair,base['signal'],newest[1],newest[0],newest[0],base['score'],min(99,abs(base['score'])), expiry_bar=newest[0]+60)

    process_tf('2M',2,last_completed_2m)
    process_tf('5M',5,last_completed_5m)
    process_tf('10M',10,last_completed_10m)

def _resolve_structure_for_bar(pair, tf, target_bar, exit_price, result_ts):
    for h in list(structure_history):
        if h.get('status')=='PENDING' and h.get('pair')==pair and h.get('tf')==tf and h.get('target_bar')==target_bar:
            outcome=directional(h['signal'], h['entry'], exit_price)
            h.update({'status':outcome,'exit':exit_price,'move':round(float(exit_price)-float(h['entry']),8),'result_time':fmt_market_time(result_ts),
                      'result_epoch':result_ts,'resolution':'TARGET_CANDLE_CLOSE'})
            _log_completed(h,pair,tf,exit_price,outcome)

def _append_structure_signal(pair, tf, st, entry_bar, entry_price, duration):
    sig=st.get('signal')
    conf=float(st.get('confidence') or 0)
    if sig not in ('CALL','PUT') or not settings.get('structure_analysis',True):
        return
    if not settings.get('structure_'+tf.lower(), True):
        return
    if settings.get('confirmation_70', False) and conf < 70:
        return
    if any(h.get('pair')==pair and h.get('tf')==tf and h.get('signal_bar')==entry_bar for h in structure_history):
        return
    target_bar=entry_bar
    signal_id=f"SR|{pair}|{tf}|{int(entry_bar)}|{uuid.uuid4().hex[:8]}"
    structure_history.appendleft({
        'source':'STRUCTURE','signal_id':signal_id,'tf':tf,'pair':pair,'signal':sig,'entry':entry_price,
        'signal_bar':entry_bar,'target_bar':entry_bar,'status':'PENDING','exit':None,
        'result_time':None,'signal_epoch':entry_bar,'entry_epoch':entry_bar,
        'expiry_epoch':entry_bar+duration,'time':fmt_market_time(entry_bar),
        'entry_time':fmt_market_time(entry_bar),'expiry_time':fmt_market_time(entry_bar+duration),
        'score':int(st.get('confidence') or 0),'confidence':int(conf),
        'structure':st.get('structure','--'),'event':st.get('event','NONE'),
        'reason':st.get('reason',''),'resolution':'PENDING_TARGET_CLOSE','zone_id':st.get('zone_id') or st.get('active_zone_id'),'entry_rule':'TARGET_CANDLE_OPEN'})
    if validator:
        try:
            validator.record(signal_id=signal_id,timestamp=fmt_market_time(entry_bar),pair=pair,signal=sig,timeframe=tf,entry=entry_price,confirmation=conf,score=st.get('confidence',0),pattern=st.get('structure',''),sr_condition=st.get('structure',''),structure=st.get('structure',''),event=st.get('event',''),reason=st.get('reason',''),expiry_time=fmt_market_time(entry_bar+duration))
        except Exception: log.exception('Failed to record S/R validation signal')


def _structure_tf_enabled(tf):
    return bool(settings.get('structure_'+tf.lower(), True)) and bool(settings.get('structure_analysis',True))

def _update_structure_tf(pair, tf, minutes, marker):
    if not pair_enabled(pair) or not _structure_tf_enabled(tf):
        return
    cs=list(candles.get(pair,()))
    if not cs:
        return
    grouped=resample_minutes(cs, minutes)
    if len(grouped)<4:
        return
    newest=grouped[-1]
    bar=newest[0]
    if marker[pair] == bar:
        return
    marker[pair]=bar
    completed=grouped[-2]
    # Resolve the signal whose target candle has just completed.
    _resolve_structure_for_bar(pair, tf, completed[0], completed[4], bar+minutes*60)
    # Analyse only candles completed before the new target candle.
    st=structure_analysis(pair, grouped[:-1])
    if st.get('signal') in ('CALL','PUT'):
        _append_structure_signal(pair, tf, st, bar, newest[1], minutes*60)


def update_structure_history(pair, st=None):
    # Structure signals are now independent for 1M / 5M / 10M.
    _update_structure_tf(pair, '1M', 1, last_structure_bar)
    _update_structure_tf(pair, '2M', 2, last_structure_bar_2m)
    _update_structure_tf(pair, '5M', 5, last_structure_bar_5m)
    # Reuse a dedicated marker for 10M to avoid cross-timeframe collisions.
    _update_structure_tf(pair, '10M', 10, last_structure_bar_10m)


def structure_history_stats():
    """Accurate live counters for S/R structure history.
    Counts are derived from the actual history rows, with WIN/LOSS/DRAW
    completed results and PENDING kept separate. Win rate uses only WIN+LOSS.
    """
    def clean_status(h):
        return str(h.get('status','PENDING') or 'PENDING').upper().strip()
    def stats(tf):
        rows=[h for h in structure_history if str(h.get('tf','')).upper()==tf]
        wins=sum(clean_status(h)=='WIN' for h in rows)
        losses=sum(clean_status(h)=='LOSS' for h in rows)
        draws=sum(clean_status(h)=='DRAW' for h in rows)
        pending=sum(clean_status(h)=='PENDING' for h in rows)
        completed=wins+losses+draws
        decided=wins+losses
        return {'total':len(rows),'completed':completed,'wins':wins,'losses':losses,
                'draws':draws,'pending':pending,
                'win_rate':round(wins/decided*100,1) if decided else 0,
                'enabled':_structure_tf_enabled(tf)}
    all_rows=list(structure_history)
    wins=sum(clean_status(h)=='WIN' for h in all_rows)
    losses=sum(clean_status(h)=='LOSS' for h in all_rows)
    draws=sum(clean_status(h)=='DRAW' for h in all_rows)
    pending=sum(clean_status(h)=='PENDING' for h in all_rows)
    decided=wins+losses
    return {'1M':stats('1M'),'2M':stats('2M'),'5M':stats('5M'),'10M':stats('10M'),
            'total':len(all_rows),'completed':wins+losses+draws,'wins':wins,'losses':losses,
            'draws':draws,'pending':pending,
            'win_rate':round(wins/decided*100,1) if decided else 0,
            'enabled':bool(settings.get('structure_analysis',True))}

def history_stats():
    def stats(tf):
        if not timeframe_enabled(tf):
            return {'total':0,'wins':0,'losses':0,'draws':0,'pending':0,'win_rate':0,'enabled':False}
        done=[h for h in signal_history if h.get('tf')==tf and h.get('status') in ('WIN','LOSS','DRAW')]
        wins=sum(h['status']=='WIN' for h in done); losses=sum(h['status']=='LOSS' for h in done); draws=sum(h['status']=='DRAW' for h in done)
        return {'total':len(done),'wins':wins,'losses':losses,'draws':draws,'pending':sum(h.get('status')=='PENDING' and h.get('tf')==tf for h in signal_history),'win_rate':round(wins/(wins+losses)*100,1) if wins+losses else 0,'enabled':True}
    return {'1M':stats('1M'),'2M':stats('2M'),'5M':stats('5M'),'10M':stats('10M')}

def market_state(pair, base_cs=None, smart=None):
    """Live market-state summary built only from captured candles/ticks.
    This is an analytical overlay; it does not execute or place trades.
    """
    if base_cs is None:
        build_candles(pair); base_cs=list(candles[pair])
    now=time.time()
    cs=sorted(base_cs,key=lambda c:c[0])
    completed=[c for c in cs if c[0]+60<=now]
    work=completed if len(completed)>=3 else cs[:-1] if len(cs)>1 else cs
    if not work:
        return {'state':'WAIT','trend':'WAIT','momentum':'WAIT','volatility':'WAIT','support':None,'resistance':None,'zone_status':'NONE','zone_strength':0,'reason':'Waiting for candle data'}
    closes=[c[4] for c in work]
    price=cs[-1][4] if cs else closes[-1]
    e20=ema_series(closes,20,allow_short=True) if closes else None
    e50=ema_series(closes,50,allow_short=True) if closes else None
    rv=rsi_flexible(closes,14) if closes else None
    ml=macd_line(closes,allow_short=True) if closes else None
    av=atr(work,14) or 0.0
    pct_vol=(av/max(abs(price),1e-12))*100
    if e20 is not None and e50 is not None:
        trend='BULLISH' if price>e20 and e20>e50 else 'BEARISH' if price<e20 and e20<e50 else 'MIXED'
    else: trend='BUILDING'
    if rv is None: momentum='BUILDING'
    elif rv>=60 and ml is not None and ml>=0: momentum='BULLISH'
    elif rv<=40 and ml is not None and ml<=0: momentum='BEARISH'
    else: momentum='NEUTRAL'
    if pct_vol>=0.20: volatility='HIGH'
    elif pct_vol>=0.08: volatility='MEDIUM'
    else: volatility='LOW'
    state='BULLISH' if trend=='BULLISH' and momentum=='BULLISH' else 'BEARISH' if trend=='BEARISH' and momentum=='BEARISH' else 'RANGE' if trend=='MIXED' else 'NEUTRAL'
    if smart is None: smart=smart_sr_analysis(pair,cs)
    zones=smart.get('zones',[]) if smart else []
    supports=[z for z in zones if z.get('type')=='S']
    resistances=[z for z in zones if z.get('type')=='R']
    support=min(supports,key=lambda z:abs(price-z.get('level',price)),default=None)
    resistance=min(resistances,key=lambda z:abs(price-z.get('level',price)),default=None)
    near=[z for z in zones if z.get('low',z.get('level',0))<=price<=z.get('high',z.get('level',0))]
    active=max(near,key=lambda z:z.get('strength',0),default=None)
    if active is None:
        near2=sorted(zones,key=lambda z:z.get('distance_pct',999))
        active=near2[0] if near2 and near2[0].get('distance_pct',999)<=0.35 else None
    zone_status=active.get('status','NONE') if active else 'NONE'
    zone_strength=int(active.get('strength',0) or 0) if active else 0
    zone_type=('SUPPORT' if active and active.get('type')=='S' else 'RESISTANCE' if active else 'NONE')
    reason=f'{trend} trend · {momentum} momentum · {volatility} volatility'
    return {'state':state,'trend':trend,'momentum':momentum,'volatility':volatility,
            'rsi':round(rv,1) if rv is not None else None,'macd':round(ml,8) if ml is not None else None,
            'ema20':round(e20,8) if e20 is not None else None,'ema50':round(e50,8) if e50 is not None else None,
            'atr_pct':round(pct_vol,3),'support':support.get('level') if support else None,
            'resistance':resistance.get('level') if resistance else None,
            'zone_type':zone_type,'zone_status':zone_status,'zone_strength':zone_strength,
            'zone_timeframes':active.get('timeframes',[]) if active else [],'reason':reason}

def setup_confirmation_engine(pair, one=None, two=None, five=None, ten=None, st=None, smart=None, mstate=None, reaction=None, structure_by_tf=None):
    """Explainable multi-factor setup confirmation overlay.
    Analysis only: combines existing scanner outputs, market state, S/R and
    confirmed-candle reaction/structure context. It never executes trades and
    never creates synthetic candles.
    """
    one=one or {}; two=two or {}; five=five or {}; ten=ten or {}
    st=st or {}; smart=smart or {}; mstate=mstate or {}; reaction=reaction or {}; structure_by_tf=structure_by_tf or {}
    call=0.0; put=0.0; confirmations=[]; risks=[]
    def add_signal(v, weight, label):
        nonlocal call, put
        sig=str((v or {}).get('signal','WAIT')).upper()
        if sig=='CALL': call += weight; confirmations.append(f'{label} CALL')
        elif sig=='PUT': put += weight; confirmations.append(f'{label} PUT')
        else: risks.append(f'{label} not directional')
    add_signal(one,22,'1M')
    add_signal(two,12,'2M')
    add_signal(five,18,'5M')
    add_signal(ten,12,'10M')
    # Independent S/R structure timeframe confluence. These are evidence
    # signals only; they do not fabricate a directional signal when disabled.
    sr_dir=[]
    for _tf in ('1M','2M','5M','10M'):
        _sv=str((structure_by_tf.get(_tf) or {}).get('signal','WAIT')).upper()
        if _sv in ('CALL','PUT'):
            sr_dir.append((_tf,_sv))
            if _sv=='CALL': call += 4; confirmations.append(f'S/R {_tf} CALL')
            else: put += 4; confirmations.append(f'S/R {_tf} PUT')
    normal_dir=[]
    for _tf,_v in (('1M',one),('2M',two),('5M',five),('10M',ten)):
        _sv=str((_v or {}).get('signal','WAIT')).upper()
        if _sv in ('CALL','PUT'):
            normal_dir.append((_tf,_sv))
    trend=str(mstate.get('trend','')).upper(); momentum=str(mstate.get('momentum','')).upper()
    if trend=='BULLISH': call+=10; confirmations.append('Market trend bullish')
    elif trend=='BEARISH': put+=10; confirmations.append('Market trend bearish')
    else: risks.append('Market trend mixed')
    if momentum=='BULLISH': call+=8; confirmations.append('Momentum bullish')
    elif momentum=='BEARISH': put+=8; confirmations.append('Momentum bearish')
    else: risks.append('Momentum neutral')

    struct_sig=str(st.get('signal','WAIT')).upper()
    struct_conf=float(st.get('confidence',0) or 0)
    if struct_sig=='CALL': call += min(10, struct_conf/10); confirmations.append(f'Structure CALL {round(struct_conf)}%')
    elif struct_sig=='PUT': put += min(10, struct_conf/10); confirmations.append(f'Structure PUT {round(struct_conf)}%')
    else: risks.append('No confirmed directional structure')

    zones=smart.get('zones',[]) if smart else []
    active=None
    if reaction.get('active_reaction'):
        aid=reaction['active_reaction'].get('zone_id')
        active=next((z for z in zones if z.get('zone_id')==aid),None)
    if active is None:
        near=[z for z in zones if z.get('distance_pct',999)<=0.40]
        active=max(near,key=lambda z:(z.get('strength',0),z.get('quality_score',0)),default=None)
    if active:
        zstrength=float(active.get('strength',0) or 0); q=float(active.get('quality_score',0) or 0)
        ztype=str(active.get('type','')); zstatus=str(active.get('status',''))
        zname=active.get('zone_kind') or ('SUPPORT' if ztype=='S' else 'RESISTANCE')
        if zstrength>=76: confirmations.append(f'{zname} {round(zstrength)}/100')
        else: risks.append(f'Zone strength only {round(zstrength)}/100')
        if q>=78: confirmations.append(f'Zone quality {round(q)}/100')
        if zstatus=='BROKEN': risks.append('Active zone is broken')
        elif zstatus=='RETEST': confirmations.append('Zone retest')
        elif zstatus=='FRESH': confirmations.append('Fresh zone')
        ar=(reaction.get('active_reaction') or {}).get('type','')
        if ar=='REJECTION':
            if ztype=='S': call+=10; confirmations.append('Support rejection')
            elif ztype=='R': put+=10; confirmations.append('Resistance rejection')
        elif ar=='BREAKOUT':
            if ztype=='R': call+=7; confirmations.append('Resistance breakout')
            elif ztype=='S': put+=7; confirmations.append('Support breakout')
        else:
            risks.append('No fresh zone reaction')
    else:
        risks.append('No active strong S/R zone nearby')

    conflict=(smart.get('summary') or {}).get('conflict') if smart else None
    if conflict:
        risks.append(conflict.get('message','S/R clearance conflict'))

    # Structure/reaction context can override a weak raw directional stack only
    # by reducing confidence, never by fabricating a signal.
    event=str(reaction.get('structure_event','NONE')).upper()
    if event=='BOS UP': call+=6; confirmations.append('Confirmed BOS UP')
    elif event=='BOS DOWN': put+=6; confirmations.append('Confirmed BOS DOWN')
    elif event=='CHOCH': risks.append('CHoCH / transition context')

    total=call+put
    if total<=0:
        bias='WAIT'; confidence=0
    else:
        lead=max(call,put); gap=abs(call-put)
        confidence=int(round(min(99, (lead/total)*100 * min(1.0, 0.65 + gap/max(total,1)*0.35))))
        bias='CALL BIAS' if call>put and confidence>=60 else 'PUT BIAS' if put>call and confidence>=60 else 'WAIT'
    quality='A+' if confidence>=85 and len(confirmations)>=6 and not conflict else 'A' if confidence>=75 and len(confirmations)>=4 else 'B' if confidence>=65 else 'C' if confidence>=55 else 'WAIT'
    if conflict and quality in ('A+','A'): quality='B'
    return {
        'pair':pair,'bias':bias,'quality':quality,'confidence':confidence,
        'call_score':round(call,1),'put_score':round(put,1),'score_gap':round(abs(call-put),1),
        'active_zone_id':active.get('zone_id') if active else None,
        'active_zone_type':active.get('zone_kind') if active else 'NONE',
        'active_zone_strength':int(active.get('strength',0) or 0) if active else 0,
        'active_zone_quality':int(active.get('quality_score',0) or 0) if active else 0,
        'active_zone_status':active.get('status','NONE') if active else 'NONE',
        'reaction':(reaction.get('active_reaction') or {}).get('type','NONE'),
        'structure':event or 'NONE','confirmations':confirmations[:12],'risks':risks[:8],
        'mtf_confluence_count':len(normal_dir),
        'mtf_call_count':sum(1 for _,x in normal_dir if x=='CALL'),
        'mtf_put_count':sum(1 for _,x in normal_dir if x=='PUT'),
        'sr_confluence_count':len(sr_dir),
        'sr_call_count':sum(1 for _,x in sr_dir if x=='CALL'),
        'sr_put_count':sum(1 for _,x in sr_dir if x=='PUT'),
        'reason':' · '.join(confirmations[:6]) if confirmations else 'Waiting for confluence',
        'risk_reason':' · '.join(risks[:4]) if risks else 'No major conflict detected'
    }

def bfss_style_analysis(pair, cs, state, setup, reaction):
    """BFSS-style public-material-inspired overlay.
    This is NOT proprietary BFSS code and does not claim to reproduce their
    private bot. It combines the publicly described themes: trend, momentum,
    candle/price action, S/R reaction, confirmation and entry timing.
    Analysis only; no execution.
    """
    ordered=sorted(cs,key=lambda c:c[0])
    completed=ordered[:-1] if len(ordered)>1 else ordered
    score_call=0; score_put=0; confirmations=[]; risks=[]
    trend=str(state.get('trend','MIXED')).upper()
    momentum=str(state.get('momentum','NEUTRAL')).upper()
    if trend=='BULLISH': score_call+=25; confirmations.append('Trend bullish')
    elif trend=='BEARISH': score_put+=25; confirmations.append('Trend bearish')
    else: risks.append('Trend mixed')
    if momentum=='BULLISH': score_call+=20; confirmations.append('Momentum bullish')
    elif momentum=='BEARISH': score_put+=20; confirmations.append('Momentum bearish')
    else: risks.append('Momentum neutral')
    if completed:
        c=completed[-1]; o,h,l,cl=c[1],c[2],c[3],c[4]
        rng=max(h-l,1e-12); body=abs(cl-o); upper=h-max(o,cl); lower=min(o,cl)-l
        if cl>o and body/rng>=0.60: score_call+=20; confirmations.append('Strong bullish candle')
        elif cl<o and body/rng>=0.60: score_put+=20; confirmations.append('Strong bearish candle')
        if lower/rng>=0.45 and cl>o: score_call+=12; confirmations.append('Bullish rejection')
        if upper/rng>=0.45 and cl<o: score_put+=12; confirmations.append('Bearish rejection')
        if len(completed)>=2:
            prev=completed[-2]
            if cl>o and cl>=prev[2] and o<=prev[3]: score_call+=8; confirmations.append('Bullish engulf/expansion')
            if cl<o and cl<=prev[3] and o>=prev[2]: score_put+=8; confirmations.append('Bearish engulf/expansion')
    reaction = reaction if isinstance(reaction, dict) else {}
    active_reaction = reaction.get('active_reaction')
    active_reaction = active_reaction if isinstance(active_reaction, dict) else {}
    ar=str(active_reaction.get('type','')).upper()
    if ar=='REJECTION':
        ztype=str(active_reaction.get('zone_type','')).upper()
        if 'SUPPORT' in ztype: score_call+=15; confirmations.append('Support rejection')
        elif 'RESISTANCE' in ztype: score_put+=15; confirmations.append('Resistance rejection')
    elif ar=='BREAKOUT': confirmations.append('Confirmed zone breakout')
    else: risks.append('No fresh S/R reaction')
    mtf=int(setup.get('mtf_confluence_count',0) or 0)
    if mtf>=2: confirmations.append(f'MTF agreement {mtf}/4')
    else: risks.append('MTF agreement below 2')
    call=max(0,min(100,score_call)); put=max(0,min(100,score_put))
    lead=max(call,put); total=call+put
    confidence=round((lead/max(total,1))*100) if lead else 0
    bias='CALL' if call>put and confidence>=68 else 'PUT' if put>call and confidence>=68 else 'WAIT'
    quality='A+' if confidence>=85 and len(confirmations)>=4 else 'A' if confidence>=75 and len(confirmations)>=3 else 'B' if confidence>=68 else 'WAIT'
    current=ordered[-1] if ordered else None
    return {'signal':bias,'call_score':call,'put_score':put,'confidence':confidence,
            'quality':quality,'confirmations':confirmations[:8],'risks':risks[:6],
            'current_candle_complete':bool(current and current[0]+60<=time.time()),
            'reason':' · '.join(confirmations[:5]) if confirmations else 'Waiting for BFSS-style confirmation',
            'disclaimer':'BFSS-style public-material-inspired analysis; not proprietary BFSS source/code.'}


def update_bfss_history(pair, bfss, cs):
    """Track BFSS-style signals for UI statistics only.
    Entry = first tick/open of the target 1M candle. Result = target candle close.
    This is a price-move outcome, not a broker payout calculation.
    """
    if not cs or not isinstance(bfss, dict):
        return
    ordered=sorted(cs,key=lambda c:c[0])
    if len(ordered)<3:
        return
    newest=ordered[-1]
    bar=int(newest[0])
    if last_bfss_bar[pair] == bar:
        return
    last_bfss_bar[pair]=bar
    # Resolve the previous BFSS target candle at its close.
    for h in list(bfss_history):
        if h.get('status')=='PENDING' and h.get('pair')==pair and h.get('target_bar')==bar-60:
            exit_price=float(newest[4])
            outcome=directional(h['signal'], h['entry'], exit_price)
            entry=float(h['entry'])
            move_pct=((exit_price-entry)/entry*100.0) if entry else 0.0
            if h['signal']=='PUT': move_pct=-move_pct
            h.update({'status':outcome,'exit':exit_price,'move':round(exit_price-entry,8),
                      'move_pct':round(move_pct,3),'result_time':fmt_market_time(bar),
                      'result_epoch':bar,'resolution':'TARGET_CANDLE_CLOSE'})
    sig=str(bfss.get('signal','WAIT')).upper()
    if sig not in ('CALL','PUT'):
        return
    # Signal is evaluated from the last completed candle and enters the new live candle.
    if any(h.get('pair')==pair and h.get('signal_bar')==bar for h in bfss_history):
        return
    entry=float(newest[1])
    confidence=int(bfss.get('confidence',0) or 0)
    quality=str(bfss.get('quality','WAIT'))
    signal_id=f"BFSS|{pair}|1M|{bar}|{uuid.uuid4().hex[:8]}"
    bfss_history.appendleft({
        'source':'BFSS_STYLE','signal_id':signal_id,'tf':'1M','pair':pair,'signal':sig,
        'entry':entry,'signal_bar':bar,'target_bar':bar,'status':'PENDING','exit':None,
        'result_time':None,'signal_epoch':bar,'entry_epoch':bar,'expiry_epoch':bar+60,
        'time':fmt_market_time(bar),'entry_time':fmt_market_time(bar),'expiry_time':fmt_market_time(bar+60),
        'score':confidence,'confidence':confidence,'quality':quality,
        'reason':bfss.get('reason',''),'resolution':'PENDING_TARGET_CLOSE','move_pct':None
    })

def bfss_history_stats():
    rows=list(bfss_history)
    done=[h for h in rows if h.get('status') in ('WIN','LOSS','DRAW')]
    wins=sum(h.get('status')=='WIN' for h in done)
    losses=sum(h.get('status')=='LOSS' for h in done)
    draws=sum(h.get('status')=='DRAW' for h in done)
    pending=sum(h.get('status')=='PENDING' for h in rows)
    decided=wins+losses
    avg_move=round(sum(float(h.get('move_pct') or 0) for h in done)/len(done),3) if done else 0.0
    return {'total':len(done),'wins':wins,'losses':losses,'draws':draws,'pending':pending,
            'win_rate':round(wins/decided*100,1) if decided else 0,'avg_move_pct':avg_move}


def bfss_backtest_report(pair_filter=None, limit_per_pair=1000):
    """Deterministic BFSS-style historical replay using locally captured candles.
    Separate from NORMAL/SR history. No broker execution or payout assumptions.
    Each signal is evaluated on the next completed candle in the selected base
    1-minute data. This is an analysis/backtest report only.
    """
    pairs=[pair_filter] if pair_filter else sorted(candles.keys(), key=str.lower)
    trades=[]
    for pair in pairs:
        cs=sorted(list(candles.get(pair, [])), key=lambda c:c[0])
        if len(cs)<25: continue
        cs=cs[-(limit_per_pair+25):]
        for i in range(20, len(cs)-1):
            prefix=cs[:i+1]
            try:
                st=structure_analysis(pair,prefix) if settings.get('structure_analysis',True) else {'zones':[],'structure':'OFF','signal':'WAIT','support':None,'resistance':None}
                smart=smart_sr_analysis(pair,prefix)
                state=market_state(pair,prefix,smart)
                reaction=zone_reaction_engine(pair,prefix,smart)
                chart_st={}
                for _tf in ('1M','2M','5M','10M'):
                    mins=int(_tf[:-1]); g=resample_minutes(prefix,mins)
                    if len(g)>=4: chart_st[_tf]=structure_analysis(pair,g[:-1] if len(g)>1 else g)
                    else: chart_st[_tf]={'signal':'WAIT','confidence':0,'structure':'BUILDING'}
                setup=setup_confirmation_engine(pair,st=st,smart=smart,mstate=state,reaction=reaction,structure_by_tf=chart_st)
                b=bfss_style_analysis(pair,prefix,state,setup,reaction)
            except Exception:
                continue
            sig=str(b.get('signal','WAIT')).upper()
            if sig not in ('CALL','PUT'): continue
            entry=float(cs[i][4])
            exitp=float(cs[i+1][4])
            outcome=directional(sig,entry,exitp)
            move=((exitp-entry)/entry*100.0) if entry else 0.0
            if sig=='PUT': move=-move
            trades.append({'pair':pair,'tf':'1M','signal':sig,'signal_bar':int(cs[i][0]),
                           'entry':entry,'exit':exitp,'status':outcome,'move_pct':round(move,3),
                           'confidence':int(b.get('confidence',0) or 0),'quality':b.get('quality','WAIT')})
    wins=sum(x['status']=='WIN' for x in trades); losses=sum(x['status']=='LOSS' for x in trades); draws=sum(x['status']=='DRAW' for x in trades)
    decided=wins+losses
    calls=[x for x in trades if x['signal']=='CALL']; puts=[x for x in trades if x['signal']=='PUT']
    def side_stats(rows):
        w=sum(x['status']=='WIN' for x in rows); l=sum(x['status']=='LOSS' for x in rows); d=sum(x['status']=='DRAW' for x in rows); dec=w+l
        return {'trades':len(rows),'wins':w,'losses':l,'draws':d,'accuracy':round(w/dec*100,1) if dec else 0}
    return {'available':True,'source':'Captured Quotex candles · deterministic BFSS-style replay',
            'disclaimer':'Public-material-inspired BFSS-style analysis; not proprietary BFSS source/code. Price-move outcome only.',
            'total':{'trades':len(trades),'wins':wins,'losses':losses,'draws':draws,'accuracy':round(wins/decided*100,1) if decided else 0,
                     'avg_move_pct':round(sum(x['move_pct'] for x in trades)/len(trades),3) if trades else 0},
            'call':side_stats(calls),'put':side_stats(puts),
            'by_timeframe':{'1M':side_stats(trades)},
            'trades':trades[-200:]}

def chart_payload(pair):
    # Keep the live/forming minute candle in the payload. The chart renderer
    # treats every 60-second bucket as exactly one candle, so a new candle
    # starts immediately after the previous bucket closes.
    build_candles(pair)
    cs=list(candles[pair])[-10000:]
    cs=sorted(cs, key=lambda c:c[0])
    st=structure_analysis(pair, cs) if settings.get('structure_analysis',True) else {'zones':[],'structure':'OFF','signal':'WAIT','support':None,'resistance':None}
    smart=smart_sr_analysis(pair, cs)
    state=market_state(pair, cs, smart)
    reaction=zone_reaction_engine(pair, cs, smart)
    chart_st_by_tf={}
    for _tf in ('1M','2M','5M','10M'):
        _mins=int(_tf[:-1]); _g=resample_minutes(cs,_mins)
        if not settings.get('structure_'+_tf.lower(), True):
            chart_st_by_tf[_tf]={'signal':'OFF','confidence':0,'structure':'OFF'}
        elif len(_g)>=4:
            chart_st_by_tf[_tf]=structure_analysis(pair,_g[:-1] if len(_g)>1 else _g)
        else:
            chart_st_by_tf[_tf]={'signal':'WAIT','confidence':0,'structure':'BUILDING'}
    setup=setup_confirmation_engine(pair, st=st, smart=smart, mstate=state, reaction=reaction, structure_by_tf=chart_st_by_tf)
    bfss=bfss_style_analysis(pair, cs, state, setup, reaction)
    update_bfss_history(pair, bfss, cs)
    now=time.time()
    candle_ts=[c[0] for c in cs]
    missing=[]
    for a,b in zip(candle_ts,candle_ts[1:]):
        if b-a>60:
            missing.extend(range(a+60,b,60))
            if len(missing)>60:
                missing=missing[:60]; break
    # Chart markers are anchored to the TARGET candle start. This means the
    # arrow is drawn on the candle that starts immediately after the confirmed
    # setup candle; it never backfills a marker into a candle that was not known
    # at signal time.
    marker_rows=[]
    for h in list(signal_history):
        if h.get('pair') != pair or h.get('signal') not in ('CALL','PUT'):
            continue
        marker_rows.append({
            't': int(h.get('signal_bar') or h.get('entry_epoch') or 0),
            'signal': h.get('signal'),
            'tf': h.get('tf','1M'),
            'score': h.get('score',0),
            'confidence': h.get('confidence',0),
            'status': h.get('status','PENDING'),
            'entry': h.get('entry'),
            'reason': h.get('reason',''),
            'result': h.get('status','PENDING'),
            'exit': h.get('exit'),
            'result_time': h.get('result_time'),
            'source': 'NORMAL'
        })
    for h in list(structure_history):
        if h.get('pair') != pair or h.get('signal') not in ('CALL','PUT'):
            continue
        marker_rows.append({
            't': int(h.get('signal_bar') or h.get('entry_epoch') or 0),
            'signal': h.get('signal'),
            'tf': h.get('tf','1M'),
            'score': h.get('confidence',0),
            'confidence': h.get('confidence',0),
            'status': h.get('status','PENDING'),
            'entry': h.get('entry'),
            'reason': h.get('reason',''),
            'structure': h.get('structure',''),
            'result': h.get('status','PENDING'),
            'exit': h.get('exit'),
            'result_time': h.get('result_time'),
            'move_pct': h.get('move_pct'),
            'source': 'SR'
        })
    # BFSS markers are deliberately separate from NORMAL/SR markers and are
    # rendered only by the BFSS live chart.
    for h in list(bfss_history):
        if h.get('pair') != pair or h.get('signal') not in ('CALL','PUT'):
            continue
        marker_rows.append({
            't': int(h.get('signal_bar') or h.get('entry_epoch') or 0),
            'signal': h.get('signal'),
            'tf': h.get('tf','1M'),
            'score': h.get('score',0),
            'confidence': h.get('confidence',0),
            'status': h.get('status','PENDING'),
            'entry': h.get('entry'),
            'reason': h.get('reason',''),
            'result': h.get('status','PENDING'),
            'exit': h.get('exit'),
            'result_time': h.get('result_time'),
            'move_pct': h.get('move_pct'),
            'source': 'BFSS'
        })
    # Same candle/TF/source can be present more than once. Prefer the
    # structure marker when NORMAL and S/R share the same candle.
    dedup={}
    for m in marker_rows:
        key=(m['t'],m['tf'],m['signal'])
        if key not in dedup or m.get('structure'):
            dedup[key]=m
    marker_rows=sorted(dedup.values(), key=lambda x:x['t'])[-250:]

    # Explicit sync metadata for the UI: latest candle bucket, whether it is
    # the live forming minute, and the last five completed candles.
    latest=cs[-1] if cs else None
    completed_cs=[c for c in cs if c[0] + 60 <= now]
    # "Previous 5" means the five exact minute buckets immediately before the
    # live bucket, not merely the last five candles found in a list. This
    # prevents gaps/stale history from making the UI show the wrong candles.
    recent_completed=[]
    if latest:
        lb=int(latest[0])
        by_ts={int(c[0]):c for c in completed_cs}
        for i in range(1,6):
            c=by_ts.get(lb-i*60)
            if c is not None:
                recent_completed.append(c)
        recent_completed.reverse()
    return {'pair':pair,
            'base_timeframe':'1M',
            'candle_gaps':len(missing),
            'candle_count':len(cs),
            'live_bucket':int(latest[0]) if latest else None,
            'live_candle_complete':bool(latest and latest[0] + 60 <= now),
            'previous_5_completed':[{'t':c[0],'o':c[1],'h':c[2],'l':c[3],'c':c[4]} for c in recent_completed],
            'candles':[{'t':c[0],'o':c[1],'h':c[2],'l':c[3],'c':c[4],
                        'complete': c[0] + 60 <= now} for c in cs],
            'signal_markers':marker_rows,
            'zones':st.get('zones',[]),
            'smart_zones':smart.get('zones',[]),
            'smart_summary':smart.get('summary',{}),
            'market_state':state,
            'zone_reaction':reaction,
            'setup_confirmation':setup,
            'bfss':bfss,
            'support':st.get('support'),'resistance':st.get('resistance'),
            'structure':st.get('structure'),'signal':st.get('signal'),
            'server_time':now,
            'historical_candles':len(historical_candles.get(pair,{})),
            'last_price':last_quote.get(pair,(None,None))[1] if pair in last_quote else None}


def public_structure_history(limit=100):
    """Return a compact JSON-safe S/R history payload.
    Internal history may contain verbose diagnostic text; never expose huge
    objects through /api/scan because that can exhaust the JSON encoder.
    """
    out=[]
    for h in list(structure_history)[:limit]:
        def txt(v, n=220):
            if v is None:
                return None
            return str(v)[:n]
        out.append({
            'source':'STRUCTURE',
            'tf':txt(h.get('tf'),8),
            'pair':txt(h.get('pair'),40),
            'signal':txt(h.get('signal'),8),
            'entry':h.get('entry'),
            'signal_bar':h.get('signal_bar'),
            'target_bar':h.get('target_bar'),
            'status':txt(h.get('status'),12),
            'exit':h.get('exit'),
            'result_time':txt(h.get('result_time'),40),
            'signal_epoch':h.get('signal_epoch'),
            'entry_epoch':h.get('entry_epoch'),
            'expiry_epoch':h.get('expiry_epoch'),
            'time':txt(h.get('time'),40),
            'entry_time':txt(h.get('entry_time'),40),
            'expiry_time':txt(h.get('expiry_time'),40),
            'score':h.get('score'),
            'confidence':h.get('confidence'),
            'structure':txt(h.get('structure'),80),
            'event':txt(h.get('event'),40),
            'reason':txt(h.get('reason'),300),
            'resolution':txt(h.get('resolution'),40),
            'zone_id':txt(h.get('zone_id'),80),
            'entry_rule':txt(h.get('entry_rule'),40)
        })
    return out

def candle_integrity(pair, required_previous=5):
    """Validate live 1-minute candle continuity without fabricating bars.

    The forming candle is excluded from the historical chain.  The result reports
    the exact completed buckets immediately before the live bucket, duplicate
    timestamps, gaps and whether the last quote belongs to the expected bucket.
    """
    build_candles(pair)
    raw=list(candles.get(pair, ()))
    now=time.time()
    if not raw:
        return {'status':'NO_DATA','ok':False,'pair':pair,'completed_count':0,
                'live_bucket':None,'previous_5':[],'gaps':[],'duplicates':[],'reason':'No candles'}
    live_bucket=(int(now)//60)*60
    # Prefer the quote's timestamp as the live bucket when available.
    q=last_quote.get(pair)
    if q and q[0]:
        live_bucket=(int(norm_ts(q[0]))//60)*60
    completed={}
    duplicates=[]
    for c in raw:
        try: b=(int(norm_ts(c[0]))//60)*60
        except Exception: continue
        if b >= live_bucket:
            continue
        if b in completed:
            duplicates.append(b)
            # Keep the last representation for diagnostics; never invent a bar.
        completed[b]=c
    expected=[live_bucket-60*i for i in range(1,required_previous+1)]
    missing=[b for b in expected if b not in completed]
    previous=[{'bucket':b,'open':completed[b][1],'high':completed[b][2],
               'low':completed[b][3],'close':completed[b][4]} for b in reversed(expected) if b in completed]
    # A future/stale live quote is a warning rather than a fabricated correction.
    quote_age=None
    if q and q[0]: quote_age=max(0,now-norm_ts(q[0]))
    ok=(len(missing)==0 and not duplicates and (quote_age is None or quote_age<=8))
    status='OK' if ok else 'WARN'
    reasons=[]
    if missing: reasons.append('MISSING '+','.join(datetime.fromtimestamp(x,timezone.utc).strftime('%H:%M') for x in missing))
    if duplicates: reasons.append(f'DUPLICATE BUCKETS {len(set(duplicates))}')
    if quote_age is not None and quote_age>8: reasons.append(f'QUOTE AGE {quote_age:.1f}s')
    return {'status':status,'ok':ok,'pair':pair,'completed_count':len(completed),
            'live_bucket':live_bucket,'live_bucket_utc':datetime.fromtimestamp(live_bucket,timezone.utc).isoformat(),
            'previous_5':previous,'missing_buckets':missing,'gaps':missing,
            'duplicates':sorted(set(duplicates)),'quote_age_sec':round(quote_age,2) if quote_age is not None else None,
            'reason':'CANDLE CHAIN OK' if ok else ' · '.join(reasons) or 'Candle chain requires attention'}

def ai_assist_decision(pair, base, one, two, five, ten, hour, st, smart, mstate, reaction, integrity):
    """Optional local AI-assist layer.

    AI mode is deliberately isolated from NORMAL mode. It does not replace the
    deterministic engines; it evaluates their already-computed evidence and
    can only promote a sufficiently strong setup or downgrade it to WAIT.
    No network/API key is required.
    """
    raw=str(base.get('signal','WAIT')).upper()
    if raw not in ('CALL','PUT'):
        return {'signal':'WAIT','confidence':0,'score':0,'decision':'WAIT','reason':'AI: no directional setup', 'factors':[]}
    direction=raw
    pts=0; factors=[]
    def add(ok, good, bad):
        nonlocal pts
        if ok:
            pts += good; factors.append(good and bad or '')
    # Core evidence agreement.
    add(str(one.get('signal','WAIT')).upper()==direction, 18, '1M confirms')
    add(str(two.get('signal','WAIT')).upper()==direction, 10, '2M confirms')
    add(str(five.get('signal','WAIT')).upper()==direction, 14, '5M confirms')
    add(str(ten.get('signal','WAIT')).upper()==direction, 8, '10M confirms')
    # Higher-timeframe trend.
    h=str(hour or '').upper()
    if (direction=='CALL' and h in ('BULLISH','UP','CALL')) or (direction=='PUT' and h in ('BEARISH','DOWN','PUT')):
        pts += 12; factors.append('1H trend aligned')
    # S/R structure agreement.
    ss=str(st.get('signal','WAIT')).upper()
    if ss==direction:
        pts += 15; factors.append('S/R agrees')
    elif ss in ('CALL','PUT') and ss!=direction:
        pts -= 14; factors.append('S/R conflict')
    # Smart zone/reaction context.
    if str(reaction.get('reaction','NONE')).upper() not in ('NONE','WAIT','BUILDING'):
        pts += 6; factors.append('zone reaction')
    if str(smart.get('bias','WAIT')).upper()==direction:
        pts += 7; factors.append('smart S/R bias')
    # Market state conflict penalty.
    mt=str(mstate.get('trend','')).upper()
    if (direction=='CALL' and mt in ('BEARISH','DOWN')) or (direction=='PUT' and mt in ('BULLISH','UP')):
        pts -= 10; factors.append('market trend conflict')
    # Integrity is a hard safety condition.
    if not integrity.get('ok',False):
        return {'signal':'WAIT','confidence':0,'score':0,'decision':'WAIT','reason':'AI: candle integrity not safe', 'factors':['candle chain invalid']}
    base_conf=float(base.get('confidence',0) or 0)
    confidence=max(0,min(99,round(40 + pts*0.55 + base_conf*0.35)))
    # AI mode only emits a directional signal when evidence reaches a strong threshold.
    if confidence < 68:
        decision='WAIT'
        reason='AI FILTER: confidence below 68%'
    else:
        decision=direction
        reason='AI CONFIRMED: '+', '.join([x for x in factors if x][:5])
    return {'signal':decision,'confidence':confidence,'score':pts,'decision':decision,'reason':reason,'factors':[x for x in factors if x]}

def scan():
    rows=[]
    with lock:
        quote_snapshot=list(last_quote.items())
        settings_snapshot=settings.copy()
    for pair,(ts,price) in quote_snapshot:
        if not pair_enabled(pair):
            continue
        build_candles(pair)
        update_history(pair)
        a=analyze(pair)
        one=make_1m_signal(pair) if settings.get('signal_1m',True) else {'signal':'OFF','score':0,'confidence':0,'reason':'1M SIGNAL OFF'}
        two=make_2m_signal(pair) if settings.get('signal_2m',True) else {'signal':'OFF','score':0,'confidence':0,'reason':'2M SIGNAL OFF'}
        five=make_5m_signal(pair) if settings.get('signal_5m',True) else {'signal':'OFF','score':0,'confidence':0,'reason':'5M SIGNAL OFF'}
        ten=make_10m_signal(pair) if settings.get('signal_10m',True) else {'signal':'OFF','score':0,'confidence':0,'reason':'10M SIGNAL OFF'}
        hour=make_hour_trend(pair)
        st=structure_analysis(pair) if settings.get('structure_analysis',True) else {'structure':'OFF','signal':'WAIT','confidence':0,'support':None,'resistance':None,'reason':'Structure analysis OFF','zones':[]}
        update_structure_history(pair, st)
        filter_keys=('filter_5m','filter_macd','filter_rsi','filter_pattern','filter_volatility','strict_score','smart_confluence','filter_structure')
        filters_active=any(settings.get(k,False) for k in filter_keys)
        if settings['mode']=='full' or filters_active:
            # FULL mode and explicitly enabled filters use the same indicator
            # engine. With NORMAL + all filters OFF, the original V4 core is
            # left untouched.
            a=full_analysis(pair,a)
            if settings['mode']=='normal' and filters_active:
                a['reason']='NORMAL V4 + active filters: '+(a.get('reason') or '')
        else:
            # NORMAL mode keeps the original V4 signal core, but optional filters
            # are now functional when the user explicitly turns them ON.
            # Indicators are also exposed in the table instead of being hidden.
            cs=list(candles[pair]); prices=[c[4] for c in cs[:-1]] if len(cs)>1 else [c[4] for c in cs]
            if prices:
                e9=ema_series(prices,9,allow_short=True); e21=ema_series(prices,21,allow_short=True)
                rv=rsi_flexible(prices,14); ml=macd_line(prices,allow_short=True)
                a['rsi']=round(rv,2) if rv is not None else None
                a['macd']=round(ml,8) if ml is not None else None
                a['ema']='BULLISH' if e9 is not None and e21 is not None and e9>e21 else 'BEARISH' if e9 is not None and e21 is not None and e9<e21 else 'BUILDING'
                a['quality']='READY' if len(prices)>=26 else 'BUILDING'
                a['pattern']=candle_pattern(cs[-2] if len(cs)>1 else cs[-1]) if cs else 'NONE'
            a['confidence']=min(99,abs(a.get('score',0)))
            a['trend5m']=make_5m_signal(pair).get('signal','WAIT')
            a['reason']='Original V4 core'
            optional_on=any(settings.get(k) for k in ('ai_mode','filter_5m','filter_macd','filter_rsi','filter_pattern','filter_volatility','strict_score','smart_confluence','filter_structure'))
            if optional_on:
                a=full_analysis(pair,a)
        # Apply the global confirmation gate once. In FULL mode preserve the
        # indicator-derived 1H trend instead of overwriting it with the
        # lightweight NORMAL-mode trend value.
        a=confirmation_allowed(a)
        if settings['mode']=='full':
            hour = a.get('trend_1h') or hour
        a.update({'structure':st.get('structure'),'structure_signal':st.get('signal'),'structure_confidence':st.get('confidence',0),'support':st.get('support'),'resistance':st.get('resistance'),'structure_reason':st.get('reason','')})
        st_by_tf={}
        # S/R structure is independently switchable for 1M/2M/5M/10M.
        # Always provide every key so /api/scan cannot fail when a timeframe
        # has insufficient candles or its S/R toggle is OFF.
        for _tf in ('1M','2M','5M','10M'):
            _mins=int(_tf[:-1]); _g=resample_minutes(list(candles[pair]),_mins)
            _enabled=bool(settings.get('structure_'+_tf.lower(), True))
            if not _enabled:
                st_by_tf[_tf]={'signal':'OFF','confidence':0,'structure':'OFF','reason':f'S/R {_tf} OFF'}
            elif len(_g)>=4:
                st_by_tf[_tf]=structure_analysis(pair,_g[:-1] if len(_g)>1 else _g)
            else:
                st_by_tf[_tf]={'signal':'WAIT','confidence':0,'structure':'BUILDING','reason':f'S/R {_tf} building'}
        smart=smart_sr_analysis(pair, list(candles[pair]))
        mstate=market_state(pair, list(candles[pair]), smart)
        reaction=zone_reaction_engine(pair, list(candles[pair]), smart)
        setup=setup_confirmation_engine(pair, one, two, five, ten, st, smart, mstate, reaction, structure_by_tf=st_by_tf)
        # Optional final signal-quality gates. Default OFF preserves the V4 core.
        raw_main_signal=str(a.get('signal','WAIT')).upper()
        # MTF confluence is based on the four normal signal timeframes only.
        # S/R confluence is tracked separately so the 2+ gate stays predictable.
        confluence_dirs=[str(x.get('signal','WAIT')).upper() for x in (one,two,five,ten) if str(x.get('signal','WAIT')).upper() in ('CALL','PUT')]
        call_n=sum(1 for x in confluence_dirs if x=='CALL'); put_n=sum(1 for x in confluence_dirs if x=='PUT')
        lead_dir='CALL' if call_n>put_n else 'PUT' if put_n>call_n else 'WAIT'
        lead_n=max(call_n,put_n)
        gate_reasons=[]
        if settings.get('strong_signal_filter',False) and raw_main_signal in ('CALL','PUT'):
            main_conf=float(a.get('confidence',0) or 0)
            if main_conf < 75:
                gate_reasons.append(f'STRONG FILTER: {round(main_conf)}% < 75%')
                a['signal']='WAIT'
            else:
                gate_reasons.append(f'STRONG FILTER PASS: {round(main_conf)}%')
        if settings.get('mtf_confluence',False) and str(a.get('signal','WAIT')).upper() in ('CALL','PUT'):
            active_signal=str(a.get('signal')).upper()
            matching=sum(1 for x in confluence_dirs if x==active_signal)
            if matching < 2:
                gate_reasons.append(f'MTF CONFLUENCE BLOCK: {matching}/2')
                a['signal']='WAIT'
            else:
                gate_reasons.append(f'MTF CONFLUENCE PASS: {matching}/{len(confluence_dirs)} {active_signal}')
        a['raw_signal']=raw_main_signal
        a['mtf_confluence_count']=lead_n
        a['mtf_confluence_direction']=lead_dir
        a['signal_filter_reason']=' · '.join(gate_reasons) if gate_reasons else 'Quality gates OFF'
        if gate_reasons:
            base_reason=str(a.get('reason') or '').strip()
            a['reason']=(base_reason+' · ' if base_reason else '')+a['signal_filter_reason']
        qg=signal_quality_guard(pair, a.get('signal'), a, one, two, five, ten, st, smart, reaction, mstate)
        a['quality_guard_enabled']=bool(settings.get('signal_quality_guard',False))
        a['quality_guard_score']=qg.get('score',0)
        a['quality_guard_pass']=qg.get('pass',True)
        a['quality_guard_reason']=qg.get('reason','')
        if settings.get('signal_quality_guard',False) and str(a.get('signal','WAIT')).upper() in ('CALL','PUT') and not qg.get('pass',False):
            raw_guarded=str(a.get('signal')).upper()
            a['signal']='WAIT'
            a['reason']=str(a.get('reason') or '')+' · QUALITY GUARD BLOCK: '+qg.get('reason','')
            a['quality_guard_blocked_signal']=raw_guarded
        else:
            a['quality_guard_blocked_signal']=None
        integrity=candle_integrity(pair)
        ai=ai_assist_decision(pair,a,one,two,five,ten,hour,st,smart,mstate,reaction,integrity) if settings.get('ai_mode',False) else {'signal':str(a.get('signal','WAIT')).upper(),'confidence':a.get('confidence',0),'score':a.get('score',0),'decision':'BYPASS','reason':'AI OFF — normal engine active','factors':[]}
        if settings.get('ai_mode',False):
            a['raw_signal']=str(a.get('signal','WAIT')).upper()
            a['signal']=ai['signal']
            a['confidence']=ai['confidence']
            a['score']=ai['score']
            a['reason']=ai['reason']
        rows.append({'pair':pair,'market':market_type(pair),'price':price,**a,
            'ai_mode':bool(settings.get('ai_mode',False)),'ai_signal':ai.get('signal','WAIT'),'ai_confidence':ai.get('confidence',0),'ai_score':ai.get('score',0),'ai_decision':ai.get('decision','WAIT'),'ai_reason':ai.get('reason',''),'ai_factors':ai.get('factors',[]),
            'candle_integrity':integrity.get('status'),'candle_integrity_ok':integrity.get('ok'),
            'candle_integrity_reason':integrity.get('reason'),'candle_missing':len(integrity.get('missing_buckets',[])),
            # Per-pair Live Setup Confirmation: the UI can rank and display
            # every enabled chart independently, so the user can choose one.
            'setup_bias':setup.get('bias','WAIT'),'setup_quality':setup.get('quality','WAIT'),
            'setup_confidence':setup.get('confidence',0),'setup_call_score':setup.get('call_score',0),
            'setup_put_score':setup.get('put_score',0),'setup_mtf_confluence':setup.get('mtf_confluence_count',0),
            'setup_sr_confluence':setup.get('sr_confluence_count',0),'setup_zone_id':setup.get('active_zone_id'),
            'setup_zone_type':setup.get('active_zone_type','NONE'),'setup_zone_strength':setup.get('active_zone_strength',0),
            'setup_zone_status':setup.get('active_zone_status','NONE'),'setup_reaction':setup.get('reaction','NONE'),
            'setup_structure':setup.get('structure','NONE'),'setup_confirmations':setup.get('confirmations',[]),
            'setup_risks':setup.get('risks',[]),'setup_signal_reason':setup.get('reason','Waiting for confluence'),
            'setup_risk_reason':setup.get('risk_reason','No major conflict detected'),
            'market_state':mstate.get('state'),'market_trend':mstate.get('trend'),'market_momentum':mstate.get('momentum'),'market_volatility':mstate.get('volatility'),'market_zone_status':mstate.get('zone_status'),'market_zone_strength':mstate.get('zone_strength'),
            'signal_1m':one['signal'],'score_1m':one['score'],
            'signal_2m':two['signal'],'score_2m':two['score'],
            'signal_5m':five['signal'],'score_5m':five['score'],
            'signal_10m':ten['signal'],'score_10m':ten['score'],
            'structure_1m_signal':st_by_tf['1M'].get('signal','WAIT'),
            'structure_2m_signal':st_by_tf['2M'].get('signal','WAIT'),
            'structure_5m_signal':st_by_tf['5M'].get('signal','WAIT'),
            'structure_10m_signal':st_by_tf['10M'].get('signal','WAIT'),
            'structure_1m_confidence':st_by_tf['1M'].get('confidence',0),
            'structure_2m_confidence':st_by_tf['2M'].get('confidence',0),
            'structure_5m_confidence':st_by_tf['5M'].get('confidence',0),
            'structure_10m_confidence':st_by_tf['10M'].get('confidence',0),
            'trend_1h':hour,'updated':fmt_market_time(last_update[pair])})
    rows.sort(key=lambda x:x['score'],reverse=True)
    feed=bool(last_update) and time.time()-max(last_update.values())<8
    visible_tfs=set()
    if settings.get('signal_1m',True): visible_tfs.add('1M')
    if settings.get('signal_2m',True): visible_tfs.add('2M')
    if settings.get('signal_5m',True): visible_tfs.add('5M')
    if settings.get('signal_10m',True): visible_tfs.add('10M')
    visible_history=[h for h in signal_history if h.get('tf') in visible_tfs and pair_enabled(h.get('pair',''))]
    # Keep /api/scan lightweight. The browser only renders the newest history rows;
    # returning thousands of full history objects can exhaust RAM during JSON serialization.
    visible_history=visible_history[:120]
    global selected_chart_pair
    available=[r['pair'] for r in rows]
    if selected_chart_pair not in available:
        selected_chart_pair = available[0] if available else None
    chart_pair=selected_chart_pair
    # Build the selected chart exactly once per /api/scan response.
    chart_data = chart_payload(chart_pair) if chart_pair else None
    structure_candidates=[]
    for r in rows:
        for _tf in ('1M','2M','5M','10M'):
            if _structure_tf_enabled(_tf) and r.get('structure_'+_tf.lower()+'_signal') in ('CALL','PUT'):
                structure_candidates.append({'pair':r['pair'],'signal':r.get('structure_'+_tf.lower()+'_signal'),'confidence':r.get('structure_'+_tf.lower()+'_confidence',0),'structure':r.get('structure'),'reason':r.get('structure_reason',''),'tf':_tf})
    structure_best=max(structure_candidates,key=lambda r:int(r.get('confidence',0) or 0),default=None)
    return {'pairs':len(rows),'available_pairs':sorted(last_quote.keys(), key=str.lower),'feed':feed,'rows':rows,'structure_best':({'pair':structure_best.get('pair'),'signal':structure_best.get('signal'),'confidence':structure_best.get('confidence',0),'structure':structure_best.get('structure'),'timeframe':structure_best.get('tf'),'reason':structure_best.get('reason','')} if structure_best else {'pair':'--','signal':'WAIT','confidence':0,'structure':'WAIT','timeframe':'--','reason':'No confirmed structure signal'}),'chart':chart_data,
        'market_state': (chart_data.get('market_state') if chart_data else {'state':'WAIT','reason':'No active pair'}),
        'last_frame_age':round(time.time()-last_frame_time,1) if last_frame_time else None,'last_accepted':last_accepted,
        'sync':{'feed':feed,'last_frame_age':round(time.time()-last_frame_time,1) if last_frame_time else None,'historical_candles':sum(len(v) for v in historical_candles.values()),'candle_count':(chart_data.get('candle_count',0) if chart_data else 0),'candle_gaps':(chart_data.get('candle_gaps',0) if chart_data else 0),'http_history_frames':http_history_frames,'integrity':candle_integrity(chart_data.get('pair')) if chart_data and chart_data.get('pair') else None},
        'raw_frames':raw_frames[-20:] if isinstance(raw_frames,list) else raw_frames,'raw_pairs':dict(raw_pairs),'http_history_frames':http_history_frames,'historical_candles':sum(len(v) for v in historical_candles.values()),'historical_pairs':{k:len(v) for k,v in historical_candles.items()},'last_error':last_error,'settings':settings_snapshot,
        'validation_file':validation_file_summary(),
        'history':visible_history,'history_stats':history_stats(),'structure_history':public_structure_history(100),'structure_history_stats':structure_history_stats(),'bfss_history':list(bfss_history)[:120],'bfss_history_stats':bfss_history_stats()}

HTML='''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Quotex Live Market Scanner V7.1.7 + BFSS-STYLE LIVE CHART</title><style>
:root{--bg:#070c12;--panel:#111a24;--line:#29394a;--text:#eef5fb;--muted:#8ea2b8;--blue:#1976d2;--green:#14b86a;--red:#e84c55;--amber:#e0b43b;--purple:#6544b5}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,sans-serif}.wrap{width:100%;padding:20px 22px 36px}h1{font-size:clamp(25px,2.5vw,40px);margin:0 0 5px}.sub,.status,.small{color:var(--muted)}.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.btn,.mode,.toggle{border:1px solid #33485d;background:#172432;color:#fff;border-radius:7px;padding:9px 12px;font-weight:800;cursor:pointer}.btn.active,.mode.normal.active{background:var(--blue)}.mode.full.active{background:var(--purple)}.btn.sound{border-color:#278a5a}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.card{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:13px}.k{font-size:12px;color:var(--muted)}.v{font-size:25px;font-weight:900;margin-top:4px}.v.call{color:#3be092}.v.put{color:#ff6d73}.v.wait{color:#f0c74b}.filters{margin-top:10px;background:#0d151e;border:1px solid var(--line);border-radius:9px;padding:13px}.mode-row,.toggles{display:flex;gap:8px;flex-wrap:wrap}.toggles{margin-top:10px}.toggle{font-size:12px;padding:8px 10px}.toggle input{accent-color:#19c77b}.toggle.on{border-color:#218b5a;background:#10251b}.table-wrap{margin-top:10px;overflow:auto;border:1px solid var(--line);border-radius:8px}table{width:100%;min-width:1750px;border-collapse:separate;border-spacing:0;table-layout:fixed}th,td{padding:9px 8px;border-bottom:1px solid #23313f;font-size:12px;white-space:nowrap;text-align:center;vertical-align:middle;overflow:hidden;text-overflow:ellipsis}th{background:#151f2a;color:#9fb1c5;position:sticky;top:0;z-index:2;font-weight:900}th:first-child,td:first-child,th:nth-child(19),td:nth-child(19),th:nth-child(20),td:nth-child(20){text-align:left}.pairbox{margin-top:10px;background:#0d151e;border:1px solid var(--line);border-radius:9px;padding:12px}.pair-controls{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pair-input{background:#172432;color:#fff;border:1px solid #33485d;border-radius:7px;padding:9px 10px;min-width:180px;text-transform:uppercase}.pair-list{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}.pair-chip{border:1px solid #33485d;background:#172432;border-radius:999px;padding:7px 10px;font-size:11px;font-weight:800;cursor:pointer}.pair-chip.on{border-color:#1fa96b;background:#103021}.pair-chip.off{opacity:.55}.pair-note{margin-top:7px;color:var(--muted);font-size:11px}.call,.put,.wait{display:inline-block;padding:6px 9px;border-radius:6px;font-weight:900}.call{background:var(--green);color:#fff}.put{background:var(--red);color:#fff}.wait{background:var(--amber);color:#111}.layout{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:12px}.history-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}.history-grid .history{min-width:0}.structure-history{border-color:#4f3a82}.structure-history h2{color:#c9b6ff}.history{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:12px;min-height:250px}.history h2{font-size:17px;margin:0 0 8px}.stats{display:grid;grid-template-columns:repeat(2,1fr);gap:7px;margin-bottom:9px}.stat{background:#0d151e;border:1px solid #263747;border-radius:7px;padding:8px}.stat b{display:block;font-size:16px;margin-top:3px}.win{color:#38df92;font-weight:900}.loss{color:#ff6d73;font-weight:900}.pending{color:#f0c74b;font-weight:900}.histrow{border-top:1px solid #24313f;padding:8px 2px;font-size:12px;display:flex;justify-content:space-between;gap:8px}.toast{display:none;position:fixed;right:18px;bottom:18px;background:#182532;border:1px solid #3a526a;padding:12px 15px;border-radius:8px;z-index:99}.fullpage{min-height:100vh}.live{color:#3be092;font-weight:900}.waiting{color:#f0c74b;font-weight:900}.chartbox{margin:12px 0;background:#0d151e;border:1px solid var(--line);border-radius:9px;padding:12px}.charthead{display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap}.charttools{display:flex;gap:7px;align-items:center}.chart{height:430px;min-height:280px;overflow:hidden;border:1px solid #243444;border-radius:7px;background:#080d13;margin-top:9px;position:relative;touch-action:none}.chart canvas{width:100%;height:100%;display:block;cursor:grab;max-width:none;user-select:none;-webkit-user-select:none}.chart-hint{position:absolute;left:10px;bottom:8px;background:rgba(7,12,18,.82);border:1px solid #29394a;border-radius:5px;padding:5px 7px;font-size:10px;color:#8ea2b8;pointer-events:none}.structure-badge{font-weight:900}.srline{stroke-dasharray:7 5;stroke-width:1.5}.marktext{font-size:11px;font-weight:900}.chart-candle{shape-rendering:geometricPrecision}.chart-candle{shape-rendering:geometricPrecision}.prochart{padding:0;overflow:hidden}.prochart-top{padding:12px 14px 8px;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #223142}.chart-title{display:flex;align-items:center;gap:8px;font-size:17px}.chart-title .small{font-size:11px;margin-left:5px}.live-dot{color:#16c784;font-size:12px}.chart-live-badge{font-size:10px;font-weight:900;color:#16c784;background:#102a20;border:1px solid #1b6b4c;border-radius:999px;padding:3px 7px}.iconbtn,.toolbtn,.tfbtn,.histbtn,.mini{border:1px solid #33485d;background:#111d29;color:#eaf2f8;border-radius:6px;padding:7px 10px;font-weight:800;cursor:pointer}.iconbtn{width:34px;padding:7px}.chart-toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px 10px;background:#0b131c;border-bottom:1px solid #223142}.tf-group{display:flex;gap:4px}.tfbtn{min-width:42px}.tfbtn.active,.histbtn.active{background:#1976d2;border-color:#2989e8}.toolbtn:hover,.tfbtn:hover,.histbtn:hover,.iconbtn:hover,.mini:hover{background:#182a3a}.spacer{flex:1}.indicator-panel{display:none;padding:8px 12px;background:#101a24;border-bottom:1px solid #223142;font-size:11px;color:#b9c8d7;gap:14px}.indicator-panel.open{display:flex;flex-wrap:wrap}.indicator-panel input{accent-color:#1ac784}.chart{height:820px;min-height:720px;margin:0;border:0;border-radius:0;background:#080d13;overflow-x:auto;overflow-y:hidden;position:relative;scroll-behavior:auto;scrollbar-width:thin}.chart-hint{left:12px;bottom:12px}.chart-bottom{display:flex;gap:18px;align-items:center;padding:8px 12px;background:#0b131c;border-top:1px solid #223142;color:#8ea2b8;font-size:11px}.sr-panel{margin:10px 0;background:#0d151e;border:1px solid #263747;border-radius:8px;overflow:hidden}.sr-panel-head{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid #223142}.sr-title{font-weight:900}.sr-summary{color:#8ea2b8;font-size:11px}.sr-table{width:100%;min-width:760px;border-collapse:collapse}.sr-table th,.sr-table td{padding:7px 8px;border-bottom:1px solid #223142;font-size:11px;text-align:center}.sr-table th{color:#8ea2b8;background:#111b25}.sr-table td:first-child,.sr-table th:first-child{text-align:left}.sr-badge{display:inline-block;padding:3px 6px;border-radius:999px;font-weight:900;font-size:10px}.sr-s{background:#103326;color:#39df92;border:1px solid #1e7954}.sr-r{background:#35191d;color:#ff737a;border:1px solid #8b343c}.sr-strong{font-weight:900}.sr-muted{color:#8ea2b8}.chart-bottom b{color:#16c784}.mini{font-size:10px;padding:5px 8px}.chart canvas{cursor:grab;display:block;max-width:none;user-select:none;-webkit-user-select:none;image-rendering:auto}.chart{box-shadow:inset 0 1px 0 rgba(255,255,255,.025),inset 0 -18px 36px rgba(0,0,0,.18)}.chart-hud{position:absolute;left:12px;top:10px;z-index:3;display:flex;gap:6px;pointer-events:none}.chart-hud span{background:rgba(9,15,22,.88);border:1px solid #26394b;border-radius:5px;padding:5px 7px;font-size:10px;font-weight:800;color:#b7c8d7}.chart-hud .hud-live{color:#16c784;border-color:#1e6f52}.signal-label{font-weight:900}.signal-marker{filter:drop-shadow(0 2px 3px rgba(0,0,0,.45))}.sr-label{filter:drop-shadow(0 1px 2px rgba(0,0,0,.5))}.price-tag{font-weight:900}.chart-grid-label{font-variant-numeric:tabular-nums}@media(max-width:700px){.chart-bottom{gap:8px;flex-wrap:wrap}.chart-toolbar{overflow-x:auto;flex-wrap:nowrap}.chart{height:620px;min-height:560px}}@media(max-width:950px){.cards{grid-template-columns:repeat(2,1fr)}.layout{grid-template-columns:1fr}.history{order:0}.history-grid{grid-template-columns:1fr}}@media(max-width:600px){.wrap{padding:14px}.cards{grid-template-columns:1fr}}
 .bfss-panel{margin-top:12px;background:#0d151e;border:1px solid #6b4bb3;border-radius:9px;overflow:hidden}.bfss-head{padding:12px 14px;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid #2c2440}.bfss-title{font-size:17px;font-weight:900}.bfss-badge{font-size:10px;font-weight:900;color:#d7c8ff;background:#241b3c;border:1px solid #6246a4;border-radius:999px;padding:4px 8px}.bfss-toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px 10px;background:#0b131c;border-bottom:1px solid #2c2440}.bfss-chart{height:560px;background:#080d13;overflow:hidden;position:relative}.bfss-chart canvas{width:100%;height:100%;display:block}.bfss-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;padding:10px}.bfss-card{background:#111a24;border:1px solid #29394a;border-radius:7px;padding:8px}.bfss-card span{display:block;font-size:10px;color:#8ea2b8}.bfss-card b{display:block;font-size:16px;margin-top:3px}.bfss-note{padding:8px 12px;color:#8ea2b8;font-size:10px;border-top:1px solid #223142}@media(max-width:700px){.bfss-chart{height:460px}.bfss-grid{grid-template-columns:repeat(2,1fr)}}.sync-panel{margin:10px 0;background:#0d151e;border:1px solid #24506b;border-radius:9px;padding:11px}.sync-head{display:flex;justify-content:space-between;align-items:center;gap:8px}.sync-ok{font-size:11px;font-weight:900;padding:5px 8px;border-radius:999px;background:#123a29}.sync-grid{display:grid;grid-template-columns:repeat(6,minmax(90px,1fr));gap:7px;margin-top:8px}.sync-card{background:#111a24;border:1px solid #29394a;border-radius:7px;padding:8px}.sync-card span{display:block;font-size:10px;color:#8ea2b8}.sync-card b{display:block;font-size:16px;margin-top:3px}.sync-bad{background:#3a1719!important;color:#ff9ca0}.sync-warn{background:#3b3014!important;color:#f4d36d}.bfss-indicators{display:none;gap:12px;flex-wrap:wrap;padding:7px 10px;background:#101a24;border-bottom:1px solid #2c2440;font-size:11px}.bfss-indicators.open{display:flex}.bfss-indicators input{accent-color:#8b6be8}.bfss-chart{touch-action:none;cursor:grab;overflow:hidden}.bfss-chart.dragging{cursor:grabbing}.bfss-chat{max-height:230px;overflow:auto;border-top:1px solid #2c2440;background:#090f16;padding:8px}.bfss-msg{display:flex;gap:8px;padding:8px 6px;border-bottom:1px solid #1e2b38;font-size:11px}.bfss-msg .bubble{background:#111d29;border:1px solid #29394a;border-radius:8px;padding:7px 9px;flex:1}.bfss-msg .tag{font-weight:900}.bfss-msg.call .tag{color:#3be092}.bfss-msg.put .tag{color:#ff6d73}.bfss-msg .win{color:#3be092}.bfss-msg .loss{color:#ff6d73}.bfss-msg .pending{color:#f0c74b}.bfss-signal-box{position:absolute;left:12px;top:12px;z-index:4;pointer-events:none;background:rgba(9,15,22,.92);border:1px solid #394c60;border-radius:7px;padding:7px 9px;font-size:11px}.bfss-crosshair{position:absolute;inset:0;pointer-events:none}.bfss-card b{font-variant-numeric:tabular-nums}.bfss-backtest{margin:0 10px 10px;background:#0d151e;border:1px solid #4f3a82;border-radius:8px;padding:10px}.bfss-bt-head{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap}.bfss-bt-cards{display:grid;grid-template-columns:repeat(7,minmax(100px,1fr));gap:7px;margin-top:9px}.bfss-backtest .bfss-card{padding:7px}@media(max-width:900px){.bfss-bt-cards{grid-template-columns:repeat(3,1fr)}}@media(max-width:600px){.bfss-bt-cards{grid-template-columns:repeat(2,1fr)}}.ai-reason-panel{margin:12px 0;background:#0d151e;border:1px solid #6b4bb3;border-radius:10px;padding:12px}.ai-reason-head{display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}.ai-reason-title{font-size:18px;font-weight:900}.ai-reason-badge{font-size:11px;font-weight:900;padding:5px 9px;border-radius:999px;background:#241b3c;border:1px solid #6246a4;color:#d7c8ff}.ai-reason-grid{display:grid;grid-template-columns:repeat(4,minmax(120px,1fr));gap:8px;margin-top:10px}.ai-reason-card{background:#111a24;border:1px solid #29394a;border-radius:8px;padding:9px}.ai-reason-card span{display:block;font-size:10px;color:#8ea2b8}.ai-reason-card b{display:block;font-size:17px;margin-top:3px}.ai-reason-why{margin-top:9px;background:#101923;border:1px solid #29394a;border-radius:8px;padding:10px}.ai-reason-factors{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.ai-factor{font-size:10px;padding:5px 8px;border-radius:999px;background:#182431;border:1px solid #33485c}.ai-factor.good{border-color:#287653}.ai-factor.bad{border-color:#8a3c43}.ai-factor.wait{border-color:#7a6330}@media(max-width:800px){.ai-reason-grid{grid-template-columns:repeat(2,1fr)}}</style></head><body><div class="wrap" id="app"><h1>Quotex Live Market Scanner V7.1.7 + BFSS-STYLE LIVE CHART</h1><div class="sub">Original V4 core preserved + FULL analysis + S/R 1M / 2M / 5M / 10M signals</div><div class="toolbar"><button class="btn active" id="normalBtn" onclick="setMode('normal')">⚡ NORMAL — ORIGINAL V4</button><button class="btn" id="fullBtn" onclick="setMode('full')">🔬 FULL ANALYSIS</button><button class="btn" onclick="toggleAll(true)">✓ ALL FILTERS ON</button><button class="btn" onclick="toggleAll(false)">ALL FILTERS OFF</button><button class="btn" onclick="resetV4()">↺ V4 DEFAULT</button><button class="btn" onclick="fullScreen()">⛶ FULL SCREEN</button><button class="btn sound" id="soundBtn" onclick="enableSound()">🔊 ENABLE SOUND</button></div><div class="cards"><div class="card"><div class="k">Pairs</div><div class="v" id="pairs">0</div></div><div class="card"><div class="k">Best pair</div><div class="v" id="best">--</div></div><div class="card"><div class="k">Best signal</div><div class="v wait" id="sig">--</div></div><div class="card"><div class="k">Feed</div><div class="v" id="feed">WAITING</div></div></div><div class="cards" style="margin-top:10px"><div class="card"><div class="k">Structure Best Pair</div><div class="v" id="structureBestPair">--</div></div><div class="card"><div class="k">Structure Signal</div><div class="v wait" id="structureSignal">WAIT</div></div><div class="card"><div class="k">Structure Type</div><div class="v" id="structureType" style="font-size:18px">--</div></div><div class="card"><div class="k">Structure Confidence</div><div class="v" id="structureConfidence">0%</div></div></div><div class="filters"><b>Analysis Mode</b><div class="mode-row" style="margin-top:9px"><button class="mode normal active" id="modeNormal" onclick="setMode('normal')">⚡ NORMAL — original V4</button><button class="mode full" id="modeFull" onclick="setMode('full')">🔬 FULL ANALYSIS — optional filters</button></div><div class="small" style="margin-top:9px">NORMAL uses the original V4 core when filters are OFF; enabled filters are applied in NORMAL too. 1M / 2M / 5M / 10M signals and histories are independent ON/OFF controls.</div><div class="toggles"><label class="toggle ai-toggle" id="aiToggle" style="border-color:#6b4bb3;background:#241b3c"><input id="ai_mode" type="checkbox" onchange="toggleAiMode(this)"> 🤖 AI MODE: <b id="aiModeState">OFF</b></label><label class="toggle"><input id="signal_1m" type="checkbox" checked onchange="saveSettings()"> 1M SIGNAL</label><label class="toggle"><input id="signal_2m" type="checkbox" checked onchange="saveSettings()"> 2M SIGNAL</label><label class="toggle"><input id="signal_5m" type="checkbox" checked onchange="saveSettings()"> 5M SIGNAL</label><label class="toggle"><input id="signal_10m" type="checkbox" checked onchange="saveSettings()"> 10M SIGNAL</label><label class="toggle structure-toggle"><input id="structure_1m" type="checkbox" checked onchange="saveSettings()"> 🏗️ S/R 1M</label><label class="toggle structure-toggle"><input id="structure_2m" type="checkbox" checked onchange="saveSettings()"> 🏗️ S/R 2M</label><label class="toggle structure-toggle"><input id="structure_5m" type="checkbox" checked onchange="saveSettings()"> 🏗️ S/R 5M</label><label class="toggle structure-toggle"><input id="structure_10m" type="checkbox" checked onchange="saveSettings()"> 🏗️ S/R 10M</label><label class="toggle"><input id="confirmation_70" type="checkbox" onchange="saveSettings()"> 🎯 70%+ CONFIRMATION</label><label class="toggle"><input id="filter_5m" type="checkbox" onchange="saveSettings()"> 5M CONFIRMATION</label><label class="toggle"><input id="filter_macd" type="checkbox" onchange="saveSettings()"> MACD FILTER</label><label class="toggle"><input id="filter_rsi" type="checkbox" onchange="saveSettings()"> RSI FILTER</label><label class="toggle"><input id="filter_pattern" type="checkbox" onchange="saveSettings()"> CANDLE PATTERN</label><label class="toggle"><input id="filter_volatility" type="checkbox" onchange="saveSettings()"> VOLATILITY FILTER</label><label class="toggle"><input id="strict_score" type="checkbox" onchange="saveSettings()"> STRICT SCORE</label><label class="toggle"><input id="smart_confluence" type="checkbox" onchange="saveSettings()"> 1H TREND + 5M CONFIRM</label><label class="toggle"><input id="structure_analysis" type="checkbox" checked onchange="saveSettings()"> STRUCTURE ENGINE</label><label class="toggle"><input id="filter_structure" type="checkbox" onchange="saveSettings()"> STRUCTURE FILTER</label><label class="toggle"><input id="strong_signal_filter" type="checkbox" onchange="saveSettings()"> 🔥 STRONG 75%+ FILTER</label><label class="toggle"><input id="mtf_confluence" type="checkbox" onchange="saveSettings()"> 🧩 MTF CONFLUENCE 2+</label><label class="toggle"><input id="signal_quality_guard" type="checkbox" onchange="saveSettings()"> 🛡️ SIGNAL QUALITY GUARD</label><label class="toggle"><input id="alerts" type="checkbox" checked onchange="saveSettings()"> SIGNAL SOUND</label></div><div class="pairbox"><div class="pair-controls"><b>Pair Manager</b><span id="pairMode" class="small">ALL PAIRS</span><input id="pairInput" class="pair-input" placeholder="EURJPY or EURJPY_otc" onkeydown="if(event.key==='Enter')addPair()"><button class="btn" onclick="addPair()">＋ ADD PAIR</button><button class="btn" onclick="selectAllPairs(true)">ALL ON</button><button class="btn" onclick="selectAllPairs(false)">ALL OFF</button></div><div class="pair-list" id="pairList"></div><div class="pair-note">ALL PAIRS = every received pair. Use ALL OFF, then click pairs to build your own watchlist. Click a pair to enable/disable it.</div></div><div class="status" id="status">Waiting for authorized browser quote frames...</div><div class="small" id="diag">Original V4 mode | Filters: 0/6</div><section id="aiReasonPanel" class="ai-reason-panel"><div class="ai-reason-head"><div><div class="ai-reason-title">🤖 AI REASON PANEL</div><div class="small" id="aiPanelPair">Waiting for scan…</div></div><span class="ai-reason-badge" id="aiPanelMode">AI OFF</span></div><div class="ai-reason-grid"><div class="ai-reason-card"><span>AI SIGNAL</span><b id="aiPanelSignal">WAIT</b></div><div class="ai-reason-card"><span>AI CONFIDENCE</span><b id="aiPanelConfidence">0%</b></div><div class="ai-reason-card"><span>DECISION</span><b id="aiPanelDecision">BYPASS</b></div><div class="ai-reason-card"><span>RAW SIGNAL</span><b id="aiPanelRaw">WAIT</b></div></div><div class="ai-reason-why"><b id="aiPanelWhyTitle">AI OFF — NORMAL ENGINE ACTIVE</b><div class="small" id="aiPanelWhy" style="margin-top:5px">AI does not modify the normal signal while AI MODE is OFF.</div><div class="ai-reason-factors" id="aiPanelFactors"></div></div></section><section class="chartbox prochart"><div class="prochart-top"><div class="chart-title"><span class="live-dot">●</span><b>LIVE CHART</b><span class="chart-live-badge">LIVE</span><div class="small" id="chartMeta">Authorized browser quote feed</div></div><div class="charttools"><label class="small">PAIR <select id="chartPair" class="pair-input" style="min-width:150px" onchange="selectChartPair(this.value)"></select></label><button class="btn" onclick="manualRefresh()" id="chartRefreshBtn">↻ REFRESH</button><button class="iconbtn" onclick="fullScreen()" title="Fullscreen">⛶</button><button class="iconbtn" onclick="chartScreenshot()" title="Chart screenshot">▣</button></div></div><div class="chart-toolbar"><div class="tf-group"><button class="tfbtn active" data-tf="1" onclick="setChartTF(1,this)">1M</button><button class="tfbtn" data-tf="2" onclick="setChartTF(2,this)">2M</button><button class="tfbtn" data-tf="5" onclick="setChartTF(5,this)">5M</button><button class="tfbtn" data-tf="10" onclick="setChartTF(10,this)">10M</button><button class="tfbtn" data-tf="15" onclick="setChartTF(15,this)">15M</button><button class="tfbtn" data-tf="30" onclick="setChartTF(30,this)">30M</button><button class="tfbtn" data-tf="60" onclick="setChartTF(60,this)">1H</button><button class="tfbtn" data-tf="240" onclick="setChartTF(240,this)">4H</button></div><button class="toolbtn" id="indicatorBtn" onclick="toggleIndicators()">⌁ INDICATORS</button><button class="toolbtn active" id="srChartBtn1M" onclick="toggleChartSr('1M')">S/R 1M: ON</button><button class="toolbtn active" id="srChartBtn2M" onclick="toggleChartSr('2M')">S/R 2M: ON</button><button class="toolbtn active" id="srChartBtn5M" onclick="toggleChartSr('5M')">S/R 5M: ON</button><button class="toolbtn active" id="srChartBtn10M" onclick="toggleChartSr('10M')">S/R 10M: ON</button><button class="toolbtn" onclick="toggleAllChartSr(true)">S/R ALL ON</button><button class="toolbtn" onclick="toggleAllChartSr(false)">S/R ALL OFF</button><button class="toolbtn" onclick="chartFollowLive()">▶ LIVE</button><div class="spacer"></div><button class="histbtn" data-n="200" onclick="setChartHistory(200,this)">200</button><button class="histbtn" data-n="300" onclick="setChartHistory(300,this)">300</button><button class="histbtn" data-n="500" onclick="setChartHistory(500,this)">500</button><button class="histbtn" data-n="1000" onclick="setChartHistory(1000,this)">1000</button><button class="histbtn active" data-n="0" onclick="setChartHistory(0,this)">ALL</button><button class="toolbtn" onclick="chartZoomX(-1)" title="Zoom candles out">H−</button><button class="toolbtn" onclick="chartZoomX(1)" title="Zoom candles in">H＋</button><button class="toolbtn" onclick="chartZoomY(-1)" title="Zoom price scale out">V−</button><button class="toolbtn" onclick="chartZoomY(1)" title="Zoom price scale in">V＋</button><button class="toolbtn" onclick="chartZoomReset()">FIT</button></div><div id="indicatorPanel" class="indicator-panel"><label><input type="checkbox" id="indEma" onchange="renderChart(window.lastScan?.chart||null)"> EMA 20</label><label><input type="checkbox" id="indEma50" onchange="renderChart(window.lastScan?.chart||null)"> EMA 50</label><label><input type="checkbox" id="indRsi" onchange="renderChart(window.lastScan?.chart||null)"> RSI 14</label><label><input type="checkbox" id="indMacd" onchange="renderChart(window.lastScan?.chart||null)"> MACD</label></div><div id="chart" class="chart"></div><div class="chart-bottom"><span>Chart S/R signals: <b>1M / 2M / 5M / 10M</b></span><span>Auto-refresh: <b>1.0s</b></span><span id="chartLast">Last: --</span><span id="chartCount">Candles: --</span><span class="spacer"></span><button class="mini" onclick="toggleMarkLevel()" id="markLevelBtn">＋ MARK LEVEL</button><button class="mini" onclick="clearManualLevels()">✕ CLEAR</button></div></section><section class="market-state-panel" style="margin-top:10px;border:1px solid #26384a;border-radius:10px;background:#0b131c;padding:12px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><span style="font-size:18px;font-weight:800">🧭 LIVE MARKET STATE</span><span class="small" id="marketStateMeta" style="margin-left:10px">Waiting…</span></div><button class="mini" onclick="toggleMarketAlerts()" id="marketAlertBtn">🔔 ALERTS: ON</button></div><div id="marketStateGrid" style="display:grid;grid-template-columns:repeat(7,minmax(105px,1fr));gap:8px;margin-top:10px"><div class="stat"><span>STATE</span><b id="msState">WAIT</b></div><div class="stat"><span>TREND</span><b id="msTrend">WAIT</b></div><div class="stat"><span>MOMENTUM</span><b id="msMomentum">WAIT</b></div><div class="stat"><span>VOLATILITY</span><b id="msVol">WAIT</b></div><div class="stat"><span>SUPPORT</span><b id="msSupport">--</b></div><div class="stat"><span>RESISTANCE</span><b id="msResistance">--</b></div><div class="stat"><span>S/R</span><b id="msZone">NONE</b></div></div><div class="small" id="msReason" style="margin-top:8px">Waiting for live market state…</div></section><section class="reaction-panel" style="margin-top:10px;border:1px solid #3b5368;border-radius:10px;background:#0b131c;padding:12px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><span style="font-size:18px;font-weight:800">⚡ LIVE ZONE REACTION & STRUCTURE</span><span class="small" id="reactionMeta" style="margin-left:10px">Waiting…</span></div><button class="mini" onclick="toggleReactionPanel()" id="reactionToggleBtn">REACTION: ON</button></div><div id="reactionGrid" style="display:grid;grid-template-columns:repeat(5,minmax(120px,1fr));gap:8px;margin-top:10px"><div class="stat"><span>NEAREST ZONE</span><b id="rxZone">--</b></div><div class="stat"><span>STRENGTH</span><b id="rxStrength">0</b></div><div class="stat"><span>DISTANCE</span><b id="rxDistance">--</b></div><div class="stat"><span>REACTION</span><b id="rxReaction">NONE</b></div><div class="stat"><span>STRUCTURE</span><b id="rxStructure">NONE</b></div></div><div class="small" id="rxDetail" style="margin-top:8px">Confirmed-candle analysis only · no synthetic candles</div></section><section class="setup-all-panel" style="margin-top:10px;border:1px solid #3b5f7d;border-radius:10px;background:#09131d;padding:12px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><span style="font-size:18px;font-weight:800">🎯 LIVE SETUP CONFIRMATION — ALL CHARTS</span><span class="small" style="margin-left:10px">Every enabled chart is analyzed independently. Select one to open it.</span></div><div style="display:flex;gap:6px;align-items:center"><span class="small" id="allSetupMeta">0 charts analyzed</span><button class="mini" onclick="toggleAllSetupPanel()" id="allSetupToggleBtn">ALL SETUPS: ON</button></div></div><div id="allSetupGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:9px;margin-top:10px"></div></section><section class="setup-panel" style="margin-top:10px;border:1px solid #29465f;border-radius:10px;background:#0b131c;padding:12px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div><span style="font-size:18px;font-weight:800">🎯 LIVE SETUP CONFIRMATION</span><span class="small" id="setupMeta" style="margin-left:10px">Analysis only · waiting…</span></div><button class="mini" onclick="toggleSetupPanel()" id="setupToggleBtn">SETUP: ON</button></div><div id="setupGrid" style="display:grid;grid-template-columns:repeat(10,minmax(105px,1fr));gap:8px;margin-top:10px"><div class="stat"><span>BIAS</span><b id="setupBias">WAIT</b></div><div class="stat"><span>QUALITY</span><b id="setupQuality">WAIT</b></div><div class="stat"><span>CONFIDENCE</span><b id="setupConfidence">0%</b></div><div class="stat"><span>CALL SCORE</span><b id="setupCallScore">0</b></div><div class="stat"><span>PUT SCORE</span><b id="setupPutScore">0</b></div><div class="stat"><span>MTF CONF.</span><b id="setupMtf">0/0</b></div><div class="stat"><span>S/R CONF.</span><b id="setupSrMtf">0/4</b></div><div class="stat"><span>ACTIVE ZONE</span><b id="setupZone">NONE</b></div><div class="stat"><span>REACTION</span><b id="setupReaction">NONE</b></div><div class="stat"><span>STRUCTURE</span><b id="setupStructure">NONE</b></div></div><div id="setupTfGrid" style="display:grid;grid-template-columns:repeat(4,minmax(90px,1fr));gap:8px;margin-top:8px"><div class="stat"><span>1M</span><b id="setup1m">--</b></div><div class="stat"><span>2M</span><b id="setup2m">--</b></div><div class="stat"><span>5M</span><b id="setup5m">--</b></div><div class="stat"><span>10M</span><b id="setup10m">--</b></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px"><div class="stat" style="text-align:left"><span>✓ CONFIRMATIONS</span><div id="setupConfirmations" class="small" style="margin-top:6px">Waiting…</div></div><div class="stat" style="text-align:left"><span>⚠ RISK / CONFLICT</span><div id="setupRisks" class="small" style="margin-top:6px">Waiting…</div></div></div><div class="small" id="setupReason" style="margin-top:8px">Waiting for live scanner data…</div></section><section class="sr-panel"><div class="sr-panel-head"><div><span class="sr-title">🧠 SMART MTF S/R ZONES</span><span class="sr-summary" id="srSummary">Waiting for zone data…</span></div><div><button class="mini" onclick="toggleSmartSr()" id="smartSrBtn">S/R: ON</button><button class="mini" onclick="toggleSmartSrMore()" id="smartSrMoreBtn">SHOW MORE</button></div></div><div style="overflow:auto"><table class="sr-table"><thead><tr><th>RANK / ID / TYPE</th><th>SIDE</th><th>STRENGTH</th><th>QUALITY</th><th>TOUCH</th><th>REJECT</th><th>TF CONFLUENCE</th><th>DIST.</th><th>STATUS</th></tr></thead><tbody id="srBody"><tr><td colspan="9" class="sr-muted">Waiting for live S/R data…</td></tr></tbody></table></div><div class="small" style="padding:8px 10px;border-top:1px solid #1b2a38">ID = zone identity · TYPE = Fresh / Tested / MTF / Supply-Demand / Rejection / Retest · Strength = zone power · Hover a row for the evidence.</div></section><section id="syncPanel" class="sync-panel"><div class="sync-head"><b>📡 MARKET DATA SYNC MONITOR</b><span id="syncStatus" class="sync-ok">WAITING</span></div><div class="sync-grid"><div class="sync-card"><span>FEED</span><b id="syncFeed">--</b></div><div class="sync-card"><span>HISTORY OHLC</span><b id="syncHist">0</b></div><div class="sync-card"><span>CANDLES</span><b id="syncCandles">0</b></div><div class="sync-card"><span>GAPS</span><b id="syncGaps">0</b></div><div class="sync-card"><span>LAST FRAME</span><b id="syncAge">--</b></div><div class="sync-card"><span>HTTP HISTORY</span><b id="syncHttp">0</b></div><div class="sync-card"><span>CANDLE CHAIN</span><b id="syncIntegrity">--</b></div></div><div class="small" id="syncNote">Authoritative Quotex OHLC history + live quote feed. Analysis only.</div></section><section class="bfss-panel"><div class="bfss-head"><div><div class="bfss-title">◈ BFSS-STYLE LIVE CHART <span class="bfss-badge">LIVE ANALYSIS</span></div><div class="small">Trend + momentum + candle/price action + S/R reaction + confirmation</div></div><div class="small"><select id="bfssPairSelect" class="pair-input" style="min-width:150px" onchange="selectChartPair(this.value)"></select></div></div><div class="bfss-toolbar"><div class="tf-group"><button class="tfbtn bfss-tf active" data-btf="1" onclick="setBFSSChartTF(1)">1M</button><button class="tfbtn bfss-tf" data-btf="2" onclick="setBFSSChartTF(2)">2M</button><button class="tfbtn bfss-tf" data-btf="5" onclick="setBFSSChartTF(5)">5M</button><button class="tfbtn bfss-tf" data-btf="10" onclick="setBFSSChartTF(10)">10M</button></div><div class="tf-group"><button class="histbtn bfss-hist active" data-bhist="100" onclick="setBFSSHistory(100)">100</button><button class="histbtn bfss-hist" data-bhist="200" onclick="setBFSSHistory(200)">200</button><button class="histbtn bfss-hist" data-bhist="300" onclick="setBFSSHistory(300)">300</button><button class="histbtn bfss-hist" data-bhist="500" onclick="setBFSSHistory(500)">500</button></div><button class="toolbtn active" id="bfssLiveBtn" onclick="bfssFollowLive()">▶ LIVE</button><button class="toolbtn" onclick="bfssZoom(1)">＋</button><button class="toolbtn" onclick="bfssZoom(-1)">−</button><button class="toolbtn" onclick="bfssPriceZoom(1)">PRICE＋</button><button class="toolbtn" onclick="bfssPriceZoom(-1)">PRICE−</button><button class="toolbtn" onclick="bfssFit()">FIT</button><button class="toolbtn" onclick="bfssToggleIndicators()">INDICATORS</button><button class="toolbtn" onclick="toggleBFSSChart()" id="bfssToggleBtn">✕ REMOVE BFSS</button><span class="spacer"></span><span id="bfssStatus" class="small">WAITING</span></div><div id="bfssIndicatorBar" class="bfss-indicators"><label><input id="bfssShowSignal" type="checkbox" checked onchange="renderBFSSChart(window.lastScan?.chart||null)"> CALL/PUT</label><label><input id="bfssShowSR" type="checkbox" checked onchange="renderBFSSChart(window.lastScan?.chart||null)"> S/R</label><label><input id="bfssShowGrid" type="checkbox" checked onchange="renderBFSSChart(window.lastScan?.chart||null)"> GRID</label></div><div id="bfssChart" class="bfss-chart"></div><div class="bfss-grid"><div class="bfss-card"><span>SIGNAL</span><b id="bfssSignal">WAIT</b></div><div class="bfss-card"><span>CONFIDENCE</span><b id="bfssConfidence">0%</b></div><div class="bfss-card"><span>QUALITY</span><b id="bfssQuality">WAIT</b></div><div class="bfss-card"><span>TREND</span><b id="bfssTrend">--</b></div><div class="bfss-card"><span>MOMENTUM</span><b id="bfssMomentum">--</b></div><div class="bfss-card"><span>WIN RATE</span><b id="bfssWinRate">0%</b></div><div class="bfss-card"><span>PRICE MOVE</span><b id="bfssMovePct">0%</b></div><div class="bfss-card"><span>WIN / LOSS</span><b id="bfssWL">0 / 0</b></div></div><div class="bfss-note" id="bfssReason">BFSS-style public-material-inspired analysis. This is not proprietary BFSS source/code and does not execute trades.</div><div class="bfss-chat" id="bfssChat"></div><section class="bfss-backtest" id="bfssBacktestPanel"><div class="bfss-bt-head"><div><b>🧪 BFSS-STYLE ACCURACY & BACKTEST</b><div class="small">Separate from NORMAL and S/R results. Replays captured candles only.</div></div><div><button class="btn" onclick="loadBFSSBacktest()">🧪 RUN BFSS BACKTEST</button><button class="btn" onclick="loadBFSSBacktest()">↻ REFRESH</button></div></div><div class="bfss-bt-cards"><div class="bfss-card"><span>TRADES</span><b id="bfssBtTrades">0</b></div><div class="bfss-card"><span>WIN</span><b class="win" id="bfssBtWins">0</b></div><div class="bfss-card"><span>LOSS</span><b class="loss" id="bfssBtLosses">0</b></div><div class="bfss-card"><span>ACCURACY</span><b id="bfssBtAccuracy">0%</b></div><div class="bfss-card"><span>CALL</span><b id="bfssBtCall">0 / 0%</b></div><div class="bfss-card"><span>PUT</span><b id="bfssBtPut">0 / 0%</b></div><div class="bfss-card"><span>AVG MOVE</span><b id="bfssBtMove">0%</b></div></div><div class="small" id="bfssBtSource">Waiting for backtest…</div></section></section><div class="table-wrap"><table><thead><tr><th>PAIR</th><th>MARKET</th><th>PRICE</th><th>SIGNAL</th><th>AI</th><th>1M SIGNAL</th><th>2M SIGNAL</th><th>5M SIGNAL</th><th>10M SIGNAL</th><th>1H TREND</th><th>CONF.</th><th>SCORE</th><th>VOLATILITY</th><th>RSI</th><th>MACD</th><th>EMA</th><th>5M</th><th>PATTERN</th><th>STRUCTURE</th><th>S/R</th><th>S/R 1M</th><th>S/R 2M</th><th>S/R 5M</th><th>S/R 10M</th><th>CANDLES</th><th>QUALITY</th><th>REASON</th><th>UPDATED</th></tr></thead><tbody id="body"></tbody></table></div><div class="history-grid"><section class="history"><h2 style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><span>📊 NORMAL SIGNAL HISTORY</span><span style="display:flex;gap:5px;flex-wrap:wrap;align-items:center"><label class="toggle history-toggle"><input id="history_1m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 1M</label><label class="toggle history-toggle"><input id="history_2m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 2M</label><label class="toggle history-toggle"><input id="history_5m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 5M</label><label class="toggle history-toggle"><input id="history_10m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 10M</label><button class="btn" style="padding:6px 9px;font-size:11px" onclick="exportHistory('normal')">⇩ CSV</button><button class="btn" style="padding:6px 9px;font-size:11px" onclick="resetNormalHistory()">↺ RESET</button></span></h2><div class="small">Normal 1M / 2M / 5M / 10M results. Each result resolves at the completed target candle close.</div><div class="stats"><div class="stat">1M WIN<b class="win" id="wins1">0</b></div><div class="stat">1M LOSS<b class="loss" id="losses1">0</b></div><div class="stat">1M RATE<b id="wr1">0%</b></div><div class="stat">1M PENDING<b class="pending" id="pending1">0</b></div><div class="stat">2M WIN<b class="win" id="wins2">0</b></div><div class="stat">2M LOSS<b class="loss" id="losses2">0</b></div><div class="stat">2M RATE<b id="wr2">0%</b></div><div class="stat">2M PENDING<b class="pending" id="pending2">0</b></div><div class="stat">5M WIN<b class="win" id="wins5">0</b></div><div class="stat">5M LOSS<b class="loss" id="losses5">0</b></div><div class="stat">5M RATE<b id="wr5">0%</b></div><div class="stat">5M PENDING<b class="pending" id="pending5">0</b></div><div class="stat">10M WIN<b class="win" id="wins10">0</b></div><div class="stat">10M LOSS<b class="loss" id="losses10">0</b></div><div class="stat">10M RATE<b id="wr10">0%</b></div><div class="stat">10M PENDING<b class="pending" id="pending10">0</b></div></div><div id="historyList"></div></section><section class="history structure-history"><h2 style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><span>🏗️ STRUCTURE / S&amp;R SIGNAL HISTORY</span><span style="display:flex;gap:5px;flex-wrap:wrap;align-items:center"><label class="toggle structure-history-toggle"><input id="structure_history_1m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 1M</label><label class="toggle structure-history-toggle"><input id="structure_history_2m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 2M</label><label class="toggle structure-history-toggle"><input id="structure_history_5m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 5M</label><label class="toggle structure-history-toggle"><input id="structure_history_10m" type="checkbox" checked onchange="saveSettings();renderHistory(window.lastScan||{})"> 10M</label><button class="btn" style="padding:6px 9px;font-size:11px" onclick="exportHistory('structure')">⇩ CSV</button><button class="btn" style="padding:6px 9px;font-size:11px" onclick="resetStructureHistory()">↺ RESET</button></span></h2><div class="small">Separate automatic Support / Resistance structure signals: breakout, retest and reversal. Results resolve at the target candle close.</div><div class="stats"><div class="stat">1M WIN<b class="win" id="swins1">0</b></div><div class="stat">1M LOSS<b class="loss" id="slosses1">0</b></div><div class="stat">1M RATE<b id="srate1">0%</b></div><div class="stat">1M PENDING<b class="pending" id="spending1">0</b></div><div class="stat">2M WIN<b class="win" id="swins2">0</b></div><div class="stat">2M LOSS<b class="loss" id="slosses2">0</b></div><div class="stat">2M RATE<b id="srate2">0%</b></div><div class="stat">2M PENDING<b class="pending" id="spending2">0</b></div><div class="stat">5M WIN<b class="win" id="swins5">0</b></div><div class="stat">5M LOSS<b class="loss" id="slosses5">0</b></div><div class="stat">5M RATE<b id="srate5">0%</b></div><div class="stat">5M PENDING<b class="pending" id="spending5">0</b></div><div class="stat">10M WIN<b class="win" id="swins10">0</b></div><div class="stat">10M LOSS<b class="loss" id="slosses10">0</b></div><div class="stat">10M RATE<b id="srate10">0%</b></div><div class="stat">10M PENDING<b class="pending" id="spending10">0</b></div></div><div id="structureHistoryList"></div></section></div></div><section id="accuracyPanel" style="margin:12px 0;background:#0d151e;border:1px solid var(--line);border-radius:9px;padding:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div><b style="font-size:18px">📊 ACCURACY & BACKTEST</b><div class="small">Live results from the normal scanner history — reporting only, does not change signal logic.</div></div><div><button class="btn" onclick="loadAccuracy()">↻ REFRESH</button><button class="btn" onclick="resetAccuracy()">↺ RESET NORMAL HISTORY</button></div></div><div id="accuracyCards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:10px"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px"><div><b>TIMEFRAME</b><div id="accuracyTf" style="margin-top:6px"></div></div><div><b>CONFIRMATION</b><div id="accuracyConf" style="margin-top:6px"></div></div></div></section><section id="validationLivePanel" style="margin:12px 0;background:#0d151e;border:1px solid #2d6f9b;border-radius:9px;padding:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div><b style="font-size:18px">🧪 PERSISTENT LIVE VALIDATION</b><div class="small">Reads the saved completed-signals CSV and runs the deterministic backtest report. Reporting only.</div></div><div><button class="btn" onclick="loadValidation()">↻ REFRESH</button><button class="btn" onclick="runBacktest()">🧪 RUN BACKTEST</button></div></div><div id="validationCards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:10px"></div><div id="validationTf" style="margin-top:10px"></div><div class="small" id="validationSource" style="margin-top:8px">Waiting…</div></section><section id="structureAccuracyPanel" style="margin:12px 0;background:#0d151e;border:1px solid #4f3a82;border-radius:9px;padding:14px"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><div><b style="font-size:18px;color:#c9b6ff">🏗️ S/R STRUCTURE ACCURACY & BACKTEST</b><div class="small">Only Support / Resistance structure signals: breakout, retest and reversal. Completely separate from NORMAL.</div></div><div><button class="btn" onclick="loadStructureAccuracy()">↻ REFRESH S/R</button><button class="btn" onclick="resetStructureAccuracy()">↺ RESET S/R HISTORY</button></div></div><div id="structureAccuracyCards" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:10px"></div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:10px"><div><b>TIMEFRAME</b><div id="structureAccuracyTf" style="margin-top:6px"></div></div><div><b>CONFIRMATION</b><div id="structureAccuracyConf" style="margin-top:6px"></div></div><div><b>STRUCTURE EVENT</b><div id="structureAccuracyEvent" style="margin-top:6px"></div></div></div></section></div><div class="toast" id="toast"></div><script>
const ids=['ai_mode','filter_5m','filter_macd','filter_rsi','filter_pattern','filter_volatility','strict_score','smart_confluence','alerts','signal_1m','signal_2m','signal_5m','signal_10m','structure_analysis','filter_structure','structure_1m','structure_2m','structure_5m','structure_10m','history_1m','history_2m','history_5m','history_10m','structure_history_1m','structure_history_2m','structure_history_5m','structure_history_10m','confirmation_70','strong_signal_filter','mtf_confluence','signal_quality_guard'];let currentMode='normal',audioCtx=null,soundReady=false,lastSignals={};let selectedPairs=[],pairFilterEnabled=false;let refreshing=false, marketAlertsEnabled=true, lastMarketState='';
function cls(s){return s==='CALL'?'call':s==='PUT'?'put':'wait'}
function toggleAiMode(el){const on=!!el.checked;el.parentElement?.classList.toggle('on',on);const st=document.getElementById('aiModeState');if(st)st.textContent=on?'ON':'OFF';saveSettings();showToast(on?'AI MODE ON — AI filter active':'AI MODE OFF — normal signal engine');}
function applySettings(s){if(!s)return;currentMode=s.mode||'normal';selectedPairs=Array.isArray(s.enabled_pairs)?s.enabled_pairs.slice():[];pairFilterEnabled=!!s.pair_filter_enabled;ids.forEach(id=>{if(id in s&&document.getElementById(id))document.getElementById(id).checked=!!s[id]});document.querySelectorAll('.toggle').forEach(x=>{let i=x.querySelector('input');if(i)x.classList.toggle('on',i.checked)});const aiState=document.getElementById('aiModeState');if(aiState)aiState.textContent=document.getElementById('ai_mode')?.checked?'ON':'OFF';document.getElementById('normalBtn').classList.toggle('active',currentMode==='normal');document.getElementById('fullBtn').classList.toggle('active',currentMode==='full');document.getElementById('modeNormal').classList.toggle('active',currentMode==='normal');document.getElementById('modeFull').classList.toggle('active',currentMode==='full');document.getElementById('diag').textContent=(currentMode==='normal'?'Original V4 mode — core unchanged':'FULL ANALYSIS — optional filters')+' | AI MODE: '+(document.getElementById('ai_mode')?.checked?'ON — AI filter active':'OFF — normal signal engine')+' | 70% gate: '+(document.getElementById('confirmation_70')?.checked?'ON':'OFF')+' | Quality gates: '+['strong_signal_filter','mtf_confluence','signal_quality_guard'].filter(id=>document.getElementById(id)?.checked).length+'/3';renderPairs(window.lastScan||{});updateSignalLabels()}
function updateSignalLabels(){let a=document.getElementById('signal_1m'),m=document.getElementById('signal_2m'),b=document.getElementById('signal_5m');if(a)a.parentElement.title=a.checked?'1-minute signal ON':'1-minute signal OFF';if(m)m.parentElement.title=m.checked?'2-minute signal ON':'2-minute signal OFF';if(b)b.parentElement.title=b.checked?'5-minute signal ON':'5-minute signal OFF'}
async function postSettings(s){try{let r=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(s)});let d=await r.json();applySettings(d.settings)}catch(e){showToast('Settings error')}}
async function saveSettings(){let s={mode:currentMode,enabled_pairs:selectedPairs,pair_filter_enabled:pairFilterEnabled};ids.forEach(id=>s[id]=document.getElementById(id).checked);await postSettings(s)}
function setMode(m){currentMode=m;postSettings({mode:m});showToast(m==='normal'?'Original V4 mode':'Full analysis mode')}
function toggleAll(v){['filter_5m','filter_macd','filter_rsi','filter_pattern','filter_volatility','strict_score','smart_confluence','structure_analysis','filter_structure'].forEach(id=>document.getElementById(id).checked=v);saveSettings();showToast(v?'All optional filters ON':'All optional filters OFF')}
function resetV4(){ids.slice(0,6).forEach(id=>document.getElementById(id).checked=false);document.getElementById('ai_mode').checked=false;document.getElementById('smart_confluence').checked=false;document.getElementById('alerts').checked=true;document.getElementById('signal_1m').checked=true;document.getElementById('signal_2m').checked=true;document.getElementById('signal_5m').checked=true;document.getElementById('signal_10m').checked=true;document.getElementById('structure_1m').checked=true;document.getElementById('structure_2m').checked=true;document.getElementById('structure_5m').checked=true;document.getElementById('structure_10m').checked=true;['history_1m','history_2m','history_5m','history_10m','structure_history_1m','structure_history_2m','structure_history_5m','structure_history_10m'].forEach(id=>document.getElementById(id).checked=true);document.getElementById('confirmation_70').checked=false;document.getElementById('strong_signal_filter').checked=false;document.getElementById('mtf_confluence').checked=false;document.getElementById('signal_quality_guard').checked=false;document.getElementById('structure_analysis').checked=true;document.getElementById('filter_structure').checked=false;currentMode='normal';saveSettings();showToast('V4 default restored')}
function addPair(){let el=document.getElementById('pairInput');let p=(el.value||'').trim().toUpperCase();if(!/^[A-Z]{6}(?:_OTC)?$/.test(p)){showToast('Invalid pair. Example: EURJPY or EURJPY_OTC');return}pairFilterEnabled=true;if(!selectedPairs.includes(p))selectedPairs.push(p);el.value='';saveSettings();showToast(p+' added')}
function removePair(p){selectedPairs=selectedPairs.filter(x=>x!==p);pairFilterEnabled=true;saveSettings();showToast(p+' removed')}
function togglePair(p){if(!pairFilterEnabled){let all=(window.lastScan?.available_pairs||[]).slice();selectedPairs=all.filter(x=>x!==p);pairFilterEnabled=true;if(selectedPairs.length===0){showToast('Only '+p+' remains selected');}else showToast(p+' disabled')}else if(selectedPairs.includes(p)){selectedPairs=selectedPairs.filter(x=>x!==p)}else selectedPairs.push(p);saveSettings()}
function selectAllPairs(on){if(on){pairFilterEnabled=false;selectedPairs=[];showToast('All received pairs enabled')}else{pairFilterEnabled=true;selectedPairs=[];showToast('All pairs disabled — add/select pairs to enable')}saveSettings()}
function renderPairs(d){let box=document.getElementById('pairList');if(!box)return;let avail=(d.available_pairs||[]).slice();let list=[...new Set([...avail,...selectedPairs])].sort((a,b)=>a.localeCompare(b));box.innerHTML=list.map(p=>{let on=!pairFilterEnabled||selectedPairs.includes(p);return `<button class="pair-chip ${on?'on':'off'}" onclick="togglePair('${p}')">${on?'✓ ':'○ '}${p}</button>`}).join('')||'<span class="small">Waiting for pairs from Quotex…</span>';document.getElementById('pairMode').textContent=pairFilterEnabled?(selectedPairs.length+' selected'):'ALL PAIRS'}
async function enableSound(){try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();await audioCtx.resume();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=740;g.gain.value=.04;o.connect(g);g.connect(audioCtx.destination);o.start();setTimeout(()=>o.stop(),130);soundReady=true;document.getElementById('soundBtn').textContent='🔊 SOUND ON';showToast('Signal sound enabled')}catch(e){showToast('Browser blocked audio')}}
function beep(type){if(!soundReady||!document.getElementById('alerts').checked)return;try{let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=type==='CALL'?880:520;g.gain.setValueAtTime(.001,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.06,audioCtx.currentTime+.02);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.28);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+.3)}catch(e){}}
function showToast(t){let x=document.getElementById('toast');x.textContent=t;x.style.display='block';clearTimeout(window.tt);window.tt=setTimeout(()=>x.style.display='none',1500)}
function fullScreen(){if(!document.fullscreenElement){document.documentElement.requestFullscreen?.().catch(()=>{})}else document.exitFullscreen?.()}
function renderHistory(d){
 let s=d.history_stats||{}, a=s['1M']||{}, a2=s['2M']||{}, b=s['5M']||{}, c10=s['10M']||{};
 const set=(id,v)=>{let e=document.getElementById(id);if(e)e.textContent=v};
 set('wins1',a.wins||0);set('losses1',a.losses||0);set('wr1',(a.win_rate||0)+'%');set('pending1',a.pending||0);
 set('wins2',a2.wins||0);set('losses2',a2.losses||0);set('wr2',(a2.win_rate||0)+'%');set('pending2',a2.pending||0);
 set('wins5',b.wins||0);set('losses5',b.losses||0);set('wr5',(b.win_rate||0)+'%');set('pending5',b.pending||0);
 set('wins10',c10.wins||0);set('losses10',c10.losses||0);set('wr10',(c10.win_rate||0)+'%');set('pending10',c10.pending||0);
 const normal=(d.history||[]).filter(h=>(h.source||'NORMAL')!=='STRUCTURE' && d.settings?.['history_'+String(h.tf||'1M').toLowerCase()]!==false);
 document.getElementById('historyList').innerHTML=normal.slice(0,60).map(h=>{let c=h.status==='WIN'?'win':h.status==='LOSS'?'loss':'pending';let pl=h.status==='WIN'?'PROFIT':h.status==='LOSS'?'LOSS':h.status;let mins=h.tf==='2M'?'2 MIN':h.tf==='5M'?'5 MIN':h.tf==='10M'?'10 MIN':'1 MIN';return `<div class="histrow"><span><b>${mins}</b> · <b>${h.pair}</b> · <span class="${h.signal==='CALL'?'win':'loss'}">${h.signal}</span><br><span class="small">Signal ${h.time} · Entry ${h.entry} · Entry time ${h.entry_time||h.time}<br>Expiry ${h.expiry_time||'--'}</span></span><span style="text-align:right" class="${c}">${pl}<br><span class="small">${h.exit!=null?'Exit '+h.exit+' · Δ '+(h.move??'--')+' · Result '+(h.result_time||''):'PENDING'}</span></span></div>`}).join('')||'<div class="small">No normal timeframe signals yet.</div>';
 const ss=d.structure_history_stats||{};
 for(const tf of ['1M','2M','5M','10M']){const v=ss[tf]||{};set('swins'+tf[0],v.wins||0);set('slosses'+tf[0],v.losses||0);set('srate'+tf[0],(v.win_rate||0)+'%');set('spending'+tf[0],v.pending||0)}
 const sh=(d.structure_history||[]).filter(h=>d.settings?.['structure_history_'+String(h.tf||'1M').toLowerCase()]!==false);
 document.getElementById('structureHistoryList').innerHTML=sh.slice(0,90).map(h=>{let c=h.status==='WIN'?'win':h.status==='LOSS'?'loss':'pending';let pl=h.status==='WIN'?'PROFIT':h.status==='LOSS'?'LOSS':h.status;return `<div class="histrow"><span><b>S/R ${h.tf||'1M'}</b> · <b>${h.pair}</b> · <span class="${h.signal==='CALL'?'win':'loss'}">${h.signal}</span><br><span class="small">${h.structure||'--'} · ${h.event||'--'} · ${h.confidence||0}%<br>Signal ${h.time} · Entry ${h.entry} · Expiry ${h.expiry_time||'--'}</span></span><span style="text-align:right" class="${c}">${pl}<br><span class="small">${h.exit!=null?'Exit '+h.exit+' · Δ '+(h.move??'--')+' · Result '+(h.result_time||''):'PENDING'}</span></span></div>`}).join('')||'<div class="small">No structure/S&amp;R signals yet.</div>';
}
async function resetNormalHistory(){
 if(!confirm('Reset NORMAL signal history only? S/R history will stay unchanged.')) return;
 try{await fetch('/api/history/normal-reset',{method:'POST'});showToast('Normal history reset');await refresh();await loadAccuracy()}catch(e){showToast('Normal reset failed')}
}
async function resetStructureHistory(){
 if(!confirm('Reset S/R structure history only? Normal history will stay unchanged.')) return;
 try{await fetch('/api/history/structure-reset',{method:'POST'});showToast('S/R history reset');await refresh();await loadStructureAccuracy()}catch(e){showToast('S/R reset failed')}
}
function accuracyTable(o){let h='<div style="overflow:auto"><table style="width:100%;min-width:420px"><thead><tr><th>GROUP</th><th>SIGNALS</th><th>WIN</th><th>LOSS</th><th>RATE</th></tr></thead><tbody>';for(const[k,v]of Object.entries(o||{})){h+=`<tr><td>${k}</td><td>${v.signals}</td><td class="win">${v.wins}</td><td class="loss">${v.losses}</td><td>${v.win_rate}%</td></tr>`}return h+'</tbody></table></div>'}
function updateSyncPanel(d){const x=d?.sync||{};const integ=x.integrity||{};const feed=!!x.feed;const age=x.last_frame_age;const hist=Number(x.historical_candles||0);const gaps=Number(x.candle_gaps||0);const el=id=>document.getElementById(id);if(el('syncFeed'))el('syncFeed').textContent=feed?'LIVE':'WAITING';if(el('syncHist'))el('syncHist').textContent=hist;if(el('syncCandles'))el('syncCandles').textContent=Number(x.candle_count||0);if(el('syncGaps'))el('syncGaps').textContent=gaps;if(el('syncAge'))el('syncAge').textContent=age==null?'--':age+'s';if(el('syncHttp'))el('syncHttp').textContent=Number(x.http_history_frames||0);if(el('syncIntegrity')){el('syncIntegrity').textContent=integ.status||'--';el('syncIntegrity').className=(integ.status==='OK')?'sync-ok':(integ.status==='WARN'?'sync-warn':'sync-card');}const st=el('syncStatus');if(st){st.textContent=!feed?'WAITING':hist<=0?'HISTORY WAIT':'SYNC OK';st.className=(!feed||hist<=0)?'sync-warn':'sync-ok';}const note=el('syncNote');if(note)note.textContent=hist>0?'Authoritative OHLC history active · live forming candle follows quote feed.': 'Waiting for authoritative OHLC history capture…';}
async function exportHistory(scope){try{const r=await fetch('/api/history/export?scope='+encodeURIComponent(scope),{cache:'no-store'});if(!r.ok)throw new Error('Export failed');const blob=await r.blob();const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='quotex_'+scope+'_signal_history.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);showToast(scope.toUpperCase()+' CSV exported')}catch(e){showToast('CSV export failed: '+e.message)}}
function validationTable(o){let h='<div style="overflow:auto"><table style="width:100%;min-width:420px"><thead><tr><th>TIMEFRAME</th><th>TRADES</th><th>WIN</th><th>LOSS</th><th>DRAW</th><th>RATE</th></tr></thead><tbody>';for(const[k,v]of Object.entries(o||{})){h+=`<tr><td>${k}</td><td>${v.trades??0}</td><td class="win">${v.wins??0}</td><td class="loss">${v.losses??0}</td><td>${v.draws??0}</td><td>${v.win_rate??0}%</td></tr>`}return h+'</tbody></table></div>'}
async function loadValidation(){try{const r=await fetch('/api/validation/status',{cache:'no-store'});const d=await r.json();const cards=`<div class="card"><div class="k">PERSISTENT TRADES</div><div class="v">${d.rows??0}</div></div><div class="card"><div class="k">WIN RATE</div><div class="v">${d.win_rate??0}%</div></div><div class="card"><div class="k">WIN / LOSS</div><div class="v">${d.wins??0} / ${d.losses??0}</div></div><div class="card"><div class="k">DRAW</div><div class="v">${d.draws??0}</div></div>`;document.getElementById('validationCards').innerHTML=cards;document.getElementById('validationTf').innerHTML=validationTable(d.timeframe);document.getElementById('validationSource').textContent=d.available?'Source: '+(d.path||'completed_signals.csv'):'Persistent validator unavailable';}catch(e){console.warn('Validation status failed',e)}}
async function runBacktest(){try{const r=await fetch('/api/validation/report',{cache:'no-store'});const d=await r.json();if(!d.available){showToast('Backtest unavailable');return}const t=d.total||{};document.getElementById('validationCards').innerHTML=`<div class="card"><div class="k">BACKTEST TRADES</div><div class="v">${t.trades??0}</div></div><div class="card"><div class="k">ACCURACY</div><div class="v">${t.accuracy??0}%</div></div><div class="card"><div class="k">WIN / LOSS</div><div class="v">${t.wins??0} / ${t.losses??0}</div></div><div class="card"><div class="k">SAMPLE</div><div class="v">${t.sample_sufficient?'SUFFICIENT':'BUILDING'}</div></div>`;document.getElementById('validationTf').innerHTML=validationTable(d.by_timeframe);document.getElementById('validationSource').textContent='Deterministic backtest: '+(d.source||'completed_signals.csv');showToast('Backtest report updated')}catch(e){showToast('Backtest failed: '+e.message)}}

async function loadAccuracy(){try{const r=await fetch('/api/performance',{cache:'no-store'});const d=await r.json();let cards=`<div class="card"><div class="k">TOTAL</div><div class="v">${d.total||0}</div></div>`;for(const [k,v] of Object.entries(d.timeframe||{}))cards+=`<div class="card"><div class="k">${k}</div><div class="v">${v.win_rate}%</div><div class="small">${v.wins}W / ${v.losses}L</div></div>`;document.getElementById('accuracyCards').innerHTML=cards;document.getElementById('accuracyTf').innerHTML=accuracyTable(d.timeframe);document.getElementById('accuracyConf').innerHTML=accuracyTable(d.confirmation)}catch(e){console.warn('Accuracy load failed',e)}}
async function resetAccuracy(){if(!confirm('Reset NORMAL signal history and accuracy? S/R history will stay unchanged.'))return;await fetch('/api/performance/reset',{method:'POST'});await loadAccuracy();showToast('Normal history reset')}
async function loadStructureAccuracy(){try{const r=await fetch('/api/structure/performance',{cache:'no-store'});const d=await r.json();let cards=`<div class="card"><div class="k">TOTAL</div><div class="v">${d.total||0}</div><div class="small">${d.completed||0} completed · ${d.pending||0} pending</div></div><div class="card"><div class="k">WIN RATE</div><div class="v">${Number(d.win_rate??0)}%</div><div class="small">${Number(d.wins??0)}W / ${Number(d.losses??0)}L · ${Number(d.draws??0)}D · ${Number(d.pending??0)} pending</div></div>`;for(const tf of ['1M','2M','5M','10M']){const v=d.timeframe?.[tf]||{};cards+=`<div class="card"><div class="k">S/R ${tf}</div><div class="v">${Number(v.win_rate??0)}%</div><div class="small">${Number(v.wins??0)}W / ${Number(v.losses??0)}L · ${Number(v.draws??0)}D · ${Number(v.pending??0)} pending</div><div class="small">${Number(v.completed??0)} completed</div></div>`}document.getElementById('structureAccuracyCards').innerHTML=cards;document.getElementById('structureAccuracyTf').innerHTML=accuracyTable(d.timeframe);document.getElementById('structureAccuracyConf').innerHTML=accuracyTable(d.confirmation);document.getElementById('structureAccuracyEvent').innerHTML=accuracyTable(d.event)}catch(e){console.warn('S/R accuracy load failed',e)}}
async function resetStructureAccuracy(){if(!confirm('Reset S/R structure history and accuracy? Normal history will stay unchanged.'))return;await fetch('/api/history/structure-reset',{method:'POST'});await loadStructureAccuracy();await refresh();showToast('S/R history reset')}
loadAccuracy();loadStructureAccuracy();loadValidation();setInterval(loadAccuracy,5000);setInterval(loadStructureAccuracy,5000);setInterval(loadValidation,5000);

let chartHeight=820, chartZoomLevel=1, chartPriceZoom=1, chartPanY=0, selectedChartPair='';
let chartSrToggles={ '1M':true, '2M':true, '5M':true, '10M':true };
function toggleChartSr(tf){tf=String(tf||'').toUpperCase();if(!(tf in chartSrToggles))return;chartSrToggles[tf]=!chartSrToggles[tf];syncChartSrButtons();drawChart(window.lastScan?.chart||null);}
function toggleAllChartSr(on){for(const tf of Object.keys(chartSrToggles))chartSrToggles[tf]=!!on;syncChartSrButtons();drawChart(window.lastScan?.chart||null);}
function syncChartSrButtons(){for(const tf of Object.keys(chartSrToggles)){const b=document.getElementById('srChartBtn'+tf);if(b){b.classList.toggle('active',chartSrToggles[tf]);b.textContent='S/R '+tf+': '+(chartSrToggles[tf]?'ON':'OFF');}}}
let chartTF=1, chartHistory=300, indicatorsOpen=false, chartCrosshair=null;
let chartRenderKey='';
let smartSrVisible=true, smartSrMore=false;
const tfLabel=m=>m<60?`${m}M`:m===60?'1H':m===240?'4H':`${m}M`;
let chartDragging=false, dragStartX=0, dragStartScroll=0, markLevelMode=false;
let lastDragRender=0;
const manualLevels={};
const chartState={canvas:null,ctx:null,data:null,arr:[],raw:[],lo:0,hi:1,baseLo:0,baseHi:1,pad:null,W:0,H:0,candleStep:9,viewportW:0};
function setChartTF(tf,btn){
  chartTF=Math.max(1,Number(tf)||1); chartPanY=0;
  document.querySelectorAll('.tfbtn').forEach(x=>x.classList.toggle('active',String(x.dataset.tf)===String(chartTF)));
  const c=window.lastScan?.chart||null;
  if(c){renderChart(c,true);}
}
function setChartHistory(n,btn){
  chartHistory=Math.max(0,Number(n)||0);
  document.querySelectorAll('.histbtn').forEach(x=>x.classList.toggle('active',String(x.dataset.n)===String(chartHistory)));
  const c=window.lastScan?.chart||null;
  if(c){renderChart(c,true);}
}
function toggleIndicators(){indicatorsOpen=!indicatorsOpen;document.getElementById('indicatorPanel')?.classList.toggle('open',indicatorsOpen);renderChart(window.lastScan?.chart||null);}
function syncChartToolbar(){syncChartSrButtons();document.querySelectorAll('.tfbtn').forEach(x=>x.classList.toggle('active',String(x.dataset.tf)===String(chartTF)));document.querySelectorAll('.histbtn').forEach(x=>x.classList.toggle('active',String(x.dataset.n)===String(chartHistory)));}
function chartScreenshot(){try{const c=chartState.canvas;if(!c)return;const a=document.createElement('a');a.download=(selectedChartPair||'chart')+'_live.png';a.href=c.toDataURL('image/png');a.click()}catch(e){showToast('Screenshot blocked by browser')}}
function ema(vals,n){if(!vals.length)return [];const k=2/(n+1),out=[];let e=vals[0];for(let i=0;i<vals.length;i++){e=i===0?vals[0]:vals[i]*k+e*(1-k);out.push(e)}return out}
function rsi(vals,n=14){const out=Array(vals.length).fill(null);if(vals.length<=n)return out;let gain=0,loss=0;for(let i=1;i<=n;i++){const d=vals[i]-vals[i-1];if(d>=0)gain+=d;else loss-=d}let ag=gain/n,al=loss/n;out[n]=al===0?100:100-100/(1+ag/al);for(let i=n+1;i<vals.length;i++){const d=vals[i]-vals[i-1];ag=(ag*(n-1)+Math.max(d,0))/n;al=(al*(n-1)+Math.max(-d,0))/n;out[i]=al===0?100:100-100/(1+ag/al)}return out}
function resampleCandles(raw,minutes){if(minutes<=1)return raw.slice();const ms=minutes*60;const out=[];let cur=null;for(const q of raw){const bucket=Math.floor(q.t/ms)*ms;if(!cur||cur.t!==bucket){if(cur)out.push(cur);cur={t:bucket,o:q.o,h:q.h,l:q.l,c:q.c,complete:q.complete!==false}}else{cur.h=Math.max(cur.h,q.h);cur.l=Math.min(cur.l,q.l);cur.c=q.c;cur.complete=cur.complete&&q.complete!==false}}if(cur){const now=Math.floor(Date.now()/1000);cur.complete=(cur.t+ms)<=now && cur.complete;out.push(cur)}return out}
function resizeChart(v){chartHeight=Math.max(560,Math.min(1200,Number(v)||820));const el=document.querySelector('.chart');if(el)el.style.height=chartHeight+'px';renderChart(window.lastScan?.chart||null);}
let chartResizeRAF=0; window.addEventListener('resize',()=>{cancelAnimationFrame(chartResizeRAF);chartResizeRAF=requestAnimationFrame(()=>{const box=document.getElementById('chart');if(box){box.style.height=Math.max(560,Math.min(1200,chartHeight||820))+'px';}if(window.lastScan?.chart){drawChart(window.lastScan.chart);renderBFSSChart(window.lastScan.chart);}});});
function chartZoomX(dir){
  const old=chartZoomLevel;
  chartZoomLevel=Math.max(.35,Math.min(5,+(old+dir*.25).toFixed(2)));
  if(chartZoomLevel===old)return;
  const box=document.getElementById('chart');
  const atRight=box&&Math.abs(box.scrollLeft-(box.scrollWidth-box.clientWidth))<12;
  renderChart(window.lastScan?.chart||null);
  if(atRight)requestAnimationFrame(()=>box.scrollLeft=Math.max(0,box.scrollWidth-box.clientWidth));
}
function chartZoomY(dir){
  const old=chartPriceZoom;
  chartPriceZoom=Math.max(.35,Math.min(6,+(old+dir*.25).toFixed(2)));
  if(chartPriceZoom===old)return;
  drawChart(window.lastScan?.chart||null);
}
function chartZoom(dir){ chartZoomX(dir); }
function chartZoomReset(){chartZoomLevel=1;chartPriceZoom=1;chartPanY=0;const box=document.getElementById('chart');const atRight=box&&Math.abs(box.scrollLeft-(box.scrollWidth-box.clientWidth))<8;renderChart(window.lastScan?.chart||null);if(box&&atRight)requestAnimationFrame(()=>box.scrollLeft=Math.max(0,box.scrollWidth-box.clientWidth));}
function chartFollowLive(){chartPanY=0;const box=document.getElementById('chart');renderChart(window.lastScan?.chart||null,true);if(box)requestAnimationFrame(()=>box.scrollLeft=Math.max(0,box.scrollWidth-box.clientWidth));}
function renderChartPairOptions(d){
  const sel=document.getElementById('chartPair'); if(!sel)return;
  const list=(d.available_pairs||[]).filter(p=>!d.settings?.pair_filter_enabled||(d.settings.enabled_pairs||[]).includes(p)).sort();
  if(!selectedChartPair||!list.includes(selectedChartPair)) selectedChartPair=d.chart?.pair||list[0]||'';
  const current=selectedChartPair;
  sel.innerHTML=list.map(p=>`<option value="${esc(p)}">${esc(p)}</option>`).join('');
  if(current && list.includes(current)) sel.value=current;
}
async function selectChartPair(pair){
  pair=String(pair||'').trim(); if(!pair)return;
  selectedChartPair=pair;
  const sel=document.getElementById('chartPair'); if(sel)sel.value=pair;
  try{
    const r=await fetch('/api/chart/select?ts='+Date.now(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pair}),cache:'no-store'});
    const d=await r.json();
    if(d.ok){
      window.lastScan=window.lastScan||{}; window.lastScan.chart=d.chart;
      chartPanY=0; chartCrosshair=null; renderChart(d.chart,true);
      showToast('Live chart: '+pair);
    }else{
      showToast(d.error||'Chart pair unavailable');
      await refresh();
    }
  }catch(e){showToast('Chart change failed: '+e.message);}
}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function getManualLevels(pair){return manualLevels[pair]||(manualLevels[pair]=[])}
function toggleMarkLevel(){markLevelMode=!markLevelMode;const b=document.getElementById('markLevelBtn');if(b){b.classList.toggle('active',markLevelMode);b.textContent=markLevelMode?'✓ CLICK CHART TO MARK':'＋ MARK LEVEL';}if(chartState.canvas)chartState.canvas.style.cursor=markLevelMode?'crosshair':'grab';}
function clearManualLevels(){if(!selectedChartPair)return;manualLevels[selectedChartPair]=[];renderChart(window.lastScan?.chart||null);showToast('Manual levels cleared')}
function priceFromY(y){const s=chartState;if(!s.pad)return null;return s.hi-(y-s.pad.t)/(s.H-s.pad.t-s.pad.b)*(s.hi-s.lo)}
function canvasPoint(ev){const c=chartState.canvas,r=c.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1);return{x:(ev.clientX-r.left)*dpr,y:(ev.clientY-r.top)*dpr}}
function onChartPointerDown(ev){const s=chartState;if(!s.canvas)return;const pt=canvasPoint(ev);if(markLevelMode){const price=priceFromY(pt.y);if(price!=null){getManualLevels(selectedChartPair).push({price,time:Date.now()});markLevelMode=false;toggleMarkLevel();renderChart(window.lastScan?.chart||null);showToast('Level marked')}return}if(ev.button!==0)return;const box=document.getElementById('chart');chartDragging=true;dragStartX=ev.clientX;dragStartY=ev.clientY;dragStartPanY=chartPanY;dragStartScroll=box?.scrollLeft||0;s.canvas.setPointerCapture?.(ev.pointerId);s.canvas.style.cursor='grabbing';}
function onChartPointerMove(ev){const s=chartState;if(!s.canvas)return;chartCrosshair=canvasPoint(ev);const now=performance.now();if(now-lastDragRender<32)return;lastDragRender=now;if(chartDragging){const box=document.getElementById('chart');if(box)box.scrollLeft=dragStartScroll-(ev.clientX-dragStartX);const inner=Math.max(1,(chartState.H-chartState.pad.t-chartState.pad.b));const baseSpan=Math.max(1e-12,chartState.baseHi-chartState.baseLo);chartPanY=dragStartPanY+((ev.clientY-dragStartY)/inner)*baseSpan;}drawChart(s.data||window.lastScan?.chart||null);}
function onChartPointerUp(ev){chartDragging=false;if(chartState.canvas){chartState.canvas.releasePointerCapture?.(ev.pointerId);chartState.canvas.style.cursor=markLevelMode?'crosshair':'grab';}}
function onChartWheel(ev){ev.preventDefault();const dir=ev.deltaY<0?1:-1;if(ev.shiftKey||ev.ctrlKey||ev.metaKey)chartZoomX(dir);else chartZoomY(dir);}
function onChartDblClick(ev){ev.preventDefault();chartZoomReset()}
function onChartKey(ev){if(ev.key==='+'||ev.key==='=')chartZoom(1);else if(ev.key==='-'||ev.key==='_')chartZoom(-1);else if(ev.key==='0')chartZoomReset();else if(ev.key.toLowerCase()==='l')chartFollowLive()}
function drawChart(c,forceFollow=false){
  const box=document.getElementById('chart');if(!box)return;
  let canvas=box.querySelector('canvas');
  if(!canvas){box.innerHTML='<canvas tabindex="0"></canvas><div class="chart-hud"><span class="hud-live">● LIVE</span><span id="hudTf">1M</span><span id="hudSignal">SIGNAL: WAIT</span></div><div class="chart-hint">Wheel = price zoom · Shift/Ctrl+Wheel = candle zoom · Drag = pan · Move = crosshair · Double-click = FIT · L = LIVE</div>';canvas=box.querySelector('canvas');canvas.addEventListener('pointerdown',onChartPointerDown);canvas.addEventListener('pointermove',onChartPointerMove);canvas.addEventListener('pointerleave',()=>{chartCrosshair=null;drawChart(chartState.data||c)});canvas.addEventListener('pointerup',onChartPointerUp);canvas.addEventListener('pointercancel',onChartPointerUp);canvas.addEventListener('dblclick',onChartDblClick);canvas.addEventListener('wheel',onChartWheel,{passive:false});canvas.addEventListener('keydown',onChartKey);}
  if(!c||!c.candles?.length){canvas.width=800;canvas.height=400;canvas.style.width='800px';canvas.style.height='400px';const ctx=canvas.getContext('2d');ctx.fillStyle='#080d13';ctx.fillRect(0,0,800,400);ctx.fillStyle='#8ea2b8';ctx.font='14px Arial';ctx.fillText('Waiting for candle feed…',18,30);return}
  const dpr=Math.min(1.5,Math.max(1,window.devicePixelRatio||1)),viewportCss=Math.max(320,box.clientWidth),Hcss=Math.max(300,box.clientHeight),base=(c.candles||[]).slice().sort((a,b)=>a.t-b.t);let raw=resampleCandles(base,chartTF);const renderLimit=chartHistory>0?chartHistory:600;if(raw.length>renderLimit)raw=raw.slice(-renderLimit);if(!raw.length)return;
  const atRight=Math.abs(box.scrollLeft-(box.scrollWidth-box.clientWidth))<10||forceFollow;const step=Math.max(7*dpr,11*dpr*chartZoomLevel);const pad={l:68*dpr,r:76*dpr,t:18*dpr,b:40*dpr};const totalW=Math.max(viewportCss*dpr,pad.l+pad.r+raw.length*step);const H=Math.max(300*dpr,Hcss*dpr);canvas.width=Math.ceil(totalW);canvas.height=Math.ceil(H);canvas.style.width=(totalW/dpr)+'px';canvas.style.height=(H/dpr)+'px';
  const ctx=canvas.getContext('2d');ctx.clearRect(0,0,totalW,H);let arr=raw;let baseLo=Math.min(...arr.map(x=>x.l)),baseHi=Math.max(...arr.map(x=>x.h));if(!isFinite(baseLo)||!isFinite(baseHi)){baseLo=0;baseHi=1}let baseSpan=baseHi-baseLo;if(baseSpan<=0){const mid=baseLo||1;baseSpan=Math.max(Math.abs(mid)*.0001,1e-8);baseLo=mid-baseSpan/2;baseHi=mid+baseSpan/2}let span=baseSpan/Math.max(.35,chartPriceZoom);let center=(baseLo+baseHi)/2-chartPanY;let lo=center-span/2,hi=center+span/2;const innerH=H-pad.t-pad.b,y=v=>pad.t+(hi-v)/span*innerH;
  ctx.fillStyle='#080d13';ctx.fillRect(0,0,totalW,H);
  for(let i=0;i<=6;i++){const gy=pad.t+innerH*i/6;ctx.strokeStyle='#172431';ctx.lineWidth=1*dpr;ctx.beginPath();ctx.moveTo(pad.l,gy);ctx.lineTo(totalW-pad.r,gy);ctx.stroke();const pv=hi-span*i/6;ctx.fillStyle='#71859a';ctx.font=`${10*dpr}px Arial`;ctx.fillText(pv.toFixed(6),totalW-pad.r+8*dpr,gy+4*dpr)}
  const labelEvery=Math.max(1,Math.ceil(arr.length/18));arr.forEach((q,i)=>{if(i%labelEvery!==0)return;const X=pad.l+step*(i+.5);ctx.strokeStyle='#101b25';ctx.beginPath();ctx.moveTo(X,pad.t);ctx.lineTo(X,H-pad.b);ctx.stroke();const dt=new Date(q.t*1000);ctx.fillStyle='#60758a';ctx.font=`${10*dpr}px Arial`;ctx.save();ctx.translate(X,H-14*dpr);ctx.rotate(-0.25);ctx.fillText(dt.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),-20*dpr,0);ctx.restore()});
  if(smartSrVisible){const zones=(smartSrMore?(c.smart_zones||[]):(c.smart_zones||[]).slice(0,10));for(const z of zones){if(z.high<lo||z.low>hi)continue;const y1=y(z.high),y2=y(z.low),top=Math.min(y1,y2),bh=Math.max(2*dpr,Math.abs(y2-y1));const strong=(z.strength||0)>=75;const sup=z.type==='S';ctx.fillStyle=sup?(strong?'rgba(22,199,132,.18)':'rgba(22,199,132,.10)'):(strong?'rgba(240,91,99,.18)':'rgba(240,91,99,.10)');ctx.fillRect(pad.l,top,totalW-pad.l-pad.r,bh);ctx.strokeStyle=sup?(strong?'#16c784':'#258e68'):(strong?'#f05b63':'#a74c55');ctx.lineWidth=(strong?1.6:1.0)*dpr;ctx.strokeRect(pad.l,top,totalW-pad.l-pad.r,bh);const yy=y(z.level);ctx.setLineDash([4*dpr,4*dpr]);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(totalW-pad.r,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle=sup?'#39df92':'#ff737a';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText(`${z.zone_id||z.type} · ${z.zone_kind||''} · ${z.strength||0}`,totalW-pad.r+7*dpr,Math.max(pad.t+11*dpr,Math.min(H-pad.b-4*dpr,yy+4*dpr)));}}
  for(const m of getManualLevels(c.pair)){if(m.price<lo||m.price>hi)continue;const yy=y(m.price);ctx.strokeStyle='#e0b43b';ctx.setLineDash([3*dpr,4*dpr]);ctx.lineWidth=1.5*dpr;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(totalW-pad.r,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#e0b43b';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText(`MARK ${m.price.toFixed(6)}`,totalW-pad.r+7*dpr,yy+4*dpr)}
  const bodyW=Math.max(2*dpr,Math.min(step*.62,20*dpr));arr.forEach((q,i)=>{const X=pad.l+step*(i+.5),yo=y(q.o),yc=y(q.c),yh=y(q.h),yl=y(q.l),up=q.c>=q.o;ctx.strokeStyle=up?'#16c784':'#f05b63';ctx.lineWidth=Math.max(1,Math.min(2.2,dpr));ctx.beginPath();ctx.moveTo(X,yh);ctx.lineTo(X,yl);ctx.stroke();ctx.fillStyle=up?'#16c784':'#f05b63';const top=Math.min(yo,yc),bh=Math.max(2*dpr,Math.abs(yc-yo));ctx.fillRect(X-bodyW/2,top,bodyW,bh)});
  // ── ENTRY SIGNAL MARKERS ────────────────────────────────────────────────
  // Signals are placed on the target candle START, so the arrow is visible
  // immediately when that candle opens. The previous candle is never used for
  // a future-looking marker.
  const markers=(c.signal_markers||[]).filter(m=>m && m.t!=null && (m.source!=='SR' || chartSrToggles[String(m.tf||'1M').toUpperCase()]));
  const visibleTf=chartTF;
  const markerMap=new Map();
  for(const m of markers){
    const bucket=Math.floor(Number(m.t)/(visibleTf*60))*(visibleTf*60);
    const key=bucket+'|'+visibleTf;
    if(!markerMap.has(key)) markerMap.set(key,m);
  }
  for(const m of markerMap.values()){
    const idx=arr.findIndex(q=>q.t===Math.floor(Number(m.t)/(visibleTf*60))*(visibleTf*60));
    if(idx<0) continue;
    const q=arr[idx], X=pad.l+step*(idx+.5), isCall=m.signal==='CALL';
    const anchorY=isCall?y(q.l):y(q.h);
    const gap=Math.max(12*dpr,Math.min(24*dpr,step*.9));
    const tipY=isCall?anchorY+gap:anchorY-gap;
    ctx.save();
    ctx.shadowColor='rgba(0,0,0,.55)';ctx.shadowBlur=5*dpr;ctx.fillStyle=isCall?'#16c784':'#f05b63';
    ctx.beginPath();
    if(isCall){ctx.moveTo(X,tipY-9*dpr);ctx.lineTo(X-7*dpr,tipY+3*dpr);ctx.lineTo(X+7*dpr,tipY+3*dpr);}
    else{ctx.moveTo(X,tipY+9*dpr);ctx.lineTo(X-7*dpr,tipY-3*dpr);ctx.lineTo(X+7*dpr,tipY-3*dpr);}
    ctx.closePath();ctx.fill();ctx.shadowBlur=0;
    const sourceLabel=m.source==='SR'?'S/R ':'';
    const label=sourceLabel+(m.tf||'1M')+' '+(isCall?'BUY':'SELL');
    const score=(m.confidence!=null?Math.round(m.confidence):0)+'%';
    const rawStatus=String(m.status||m.result||'PENDING').toUpperCase();
    const result=rawStatus==='WIN'?'PROFIT':rawStatus==='LOSS'?'LOSS':rawStatus==='DRAW'?'DRAW':'PENDING';
    const resultClass=result==='PROFIT'?'win':result==='LOSS'?'loss':result==='DRAW'?'draw':'pending';
    const resultText=result;
    const labelW=Math.max(74*dpr,ctx.measureText(label).width+22*dpr,ctx.measureText(resultText).width+22*dpr);
    const labelH=42*dpr;
    let lx=X-labelW/2, ly=isCall?tipY+7*dpr:tipY-labelH-7*dpr;
    lx=Math.max(pad.l+2*dpr,Math.min(totalW-pad.r-labelW,lx));
    ctx.fillStyle=isCall?'rgba(14,63,45,.97)':'rgba(79,28,34,.97)';ctx.strokeStyle=isCall?'#1b9d6a':'#bd4d58';ctx.lineWidth=1*dpr;
    ctx.beginPath();ctx.roundRect(lx,ly,labelW,labelH,5*dpr);ctx.fill();ctx.stroke();
    ctx.fillStyle='#f4fbff';ctx.font=`900 ${10*dpr}px Arial`;ctx.textAlign='center';ctx.fillText(label,lx+labelW/2,ly+10*dpr);
    ctx.fillStyle='#c5d2dc';ctx.font=`800 ${8*dpr}px Arial`;ctx.fillText(score,lx+labelW/2,ly+20*dpr);
    ctx.fillStyle=resultClass==='win'?'#39df92':resultClass==='loss'?'#ff737a':resultClass==='draw'?'#e0b43b':'#f0c74b';
    ctx.font=`900 ${9*dpr}px Arial`;ctx.fillText(resultText,lx+labelW/2,ly+33*dpr);
    ctx.textAlign='left';
    ctx.restore();
  }
  const closes=arr.map(x=>x.c);const drawLine=(vals,stroke,width=1.4)=>{ctx.strokeStyle=stroke;ctx.lineWidth=width*dpr;ctx.beginPath();let started=false;vals.forEach((v,i)=>{if(v==null)return;const X=pad.l+step*(i+.5),Y=y(v);if(!started){ctx.moveTo(X,Y);started=true}else ctx.lineTo(X,Y)});if(started)ctx.stroke()};if(document.getElementById('indEma')?.checked)drawLine(ema(closes,20),'#e0b43b',1.5);if(document.getElementById('indEma50')?.checked)drawLine(ema(closes,50),'#8f7aea',1.5);
  const lp=c.last_price??arr[arr.length-1].c;if(lp>=lo&&lp<=hi){const yy=y(lp);ctx.strokeStyle='#2da9ff';ctx.setLineDash([2*dpr,3*dpr]);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(totalW-pad.r,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#eaf2f8';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText(String(lp),totalW-pad.r+8*dpr,yy+4*dpr)}
  const wantRSI=document.getElementById('indRsi')?.checked,wantMACD=document.getElementById('indMacd')?.checked;if(wantRSI||wantMACD){const paneH=Math.min(110*dpr,innerH*.22),py=H-pad.b-paneH;ctx.fillStyle='#0b131c';ctx.fillRect(pad.l,py,totalW-pad.l-pad.r,paneH);if(wantRSI){const rv=rsi(closes,14),ry=v=>py+paneH-(v/100)*paneH;drawLine(rv.map(v=>v==null?null:py+(v/100)*0),'#000',0);ctx.strokeStyle='#7b8cff';ctx.lineWidth=1.4*dpr;ctx.beginPath();let st=false;rv.forEach((v,i)=>{if(v==null)return;const X=pad.l+step*(i+.5),Y=ry(v);if(!st){ctx.moveTo(X,Y);st=true}else ctx.lineTo(X,Y)});if(st)ctx.stroke();ctx.fillStyle='#9ba9ff';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText('RSI 14',pad.l+5*dpr,py+13*dpr)}if(wantMACD){const a=ema(closes,12),b=ema(closes,26),mv=a.map((v,i)=>v-b[i]),ma=Math.max(...mv.map(v=>Math.abs(v)),1e-12),my=v=>py+paneH/2-(v/ma)*(paneH*.42);ctx.strokeStyle='#5cc8ff';ctx.lineWidth=1.2*dpr;ctx.beginPath();mv.forEach((v,i)=>{const X=pad.l+step*(i+.5),Y=my(v);if(i===0)ctx.moveTo(X,Y);else ctx.lineTo(X,Y)});ctx.stroke();ctx.fillStyle='#6fd5ff';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText('MACD',pad.l+52*dpr,py+13*dpr)}}
  if(chartCrosshair){const xx=chartCrosshair.x,yy=chartCrosshair.y;if(xx>=pad.l&&xx<=totalW-pad.r&&yy>=pad.t&&yy<=H-pad.b){ctx.strokeStyle='#415366';ctx.setLineDash([3*dpr,4*dpr]);ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,H-pad.b);ctx.moveTo(pad.l,yy);ctx.lineTo(totalW-pad.r,yy);ctx.stroke();ctx.setLineDash([]);const pv=priceFromY(yy);if(pv!=null){ctx.fillStyle='#1b2a38';ctx.fillRect(totalW-pad.r+2*dpr,yy-9*dpr,72*dpr,18*dpr);ctx.fillStyle='#eaf2f8';ctx.font=`${10*dpr}px Arial`;ctx.fillText(pv.toFixed(6),totalW-pad.r+7*dpr,yy+4*dpr)}}}
  // Premium current-candle countdown / live state.
  const last=arr[arr.length-1],up=last.c>=last.o;
  const candleSeconds=Math.max(1,chartTF*60);
  const remain=Math.max(0,Math.ceil((last.t+candleSeconds)-Date.now()/1000));
  const mm=String(Math.floor(remain/60)).padStart(2,'0'), ss=String(remain%60).padStart(2,'0');
  const hudTf=document.getElementById('hudTf'),hudSignal=document.getElementById('hudSignal');
  if(hudTf)hudTf.textContent=tfLabel(chartTF)+' · '+raw.length+' candles';
  if(hudSignal){const lm=[...markerMap.values()].reverse().find(m=>m.t<=last.t);hudSignal.textContent=lm?((lm.signal==='CALL'?'BUY':'SELL')+' '+(lm.confidence??0)+'%'):('SIGNAL: WAIT');hudSignal.style.color=lm?.signal==='CALL'?'#39df92':lm?.signal==='PUT'?'#ff737a':'';}
  ctx.fillStyle='#dbe7f0';ctx.font=`bold ${12*dpr}px Arial`;ctx.fillText(`${c.pair} · ${tfLabel(chartTF)}`,pad.l,14*dpr);
  ctx.fillStyle='#8ea2b8';ctx.font=`bold ${10*dpr}px Arial`;ctx.fillText(`CANDLE CLOSES ${mm}:${ss}`,pad.l+150*dpr,14*dpr);ctx.fillStyle=up?'#16c784':'#f05b63';ctx.font=`${10*dpr}px Arial`;ctx.fillText(`O ${last.o}  H ${last.h}  L ${last.l}  C ${last.c}`,pad.l+360*dpr,14*dpr);
  chartState.canvas=canvas;chartState.ctx=ctx;chartState.data=c;chartState.arr=arr;chartState.raw=raw;chartState.lo=lo;chartState.hi=hi;chartState.baseLo=baseLo;chartState.baseHi=baseHi;chartState.pad=pad;chartState.W=totalW;chartState.H=H;chartState.candleStep=step;chartState.viewportW=viewportCss*dpr;
  document.getElementById('chartMeta').textContent=`${c.pair} · ${tfLabel(chartTF)} · ${chartHistory?chartHistory+' candles':'ALL available'} · Loaded ${raw.length} · Hist ${c.historical_candles||0} · ${atRight?'LIVE FOLLOW':'MANUAL VIEW'}`;
  document.getElementById('chartLast').textContent=`Last: ${lp}`;document.getElementById('chartCount').textContent=`Showing ${raw.length} / ${chartHistory||'ALL'} candles · ${tfLabel(chartTF)}`;
  if(atRight)requestAnimationFrame(()=>{box.scrollLeft=Math.max(0,box.scrollWidth-box.clientWidth)});
}
function renderSrPanel(c){
  const body=document.getElementById('srBody');
  const summary=document.getElementById('srSummary');
  if(!body) return;
  const zones=Array.isArray(c?.smart_zones)?c.smart_zones:[];
  const sm=c?.smart_summary||{};
  if(summary){
    if(!c){summary.textContent='Waiting for zone data…';}
    else if(!zones.length){summary.textContent='No confirmed MTF zones yet';}
    else {const top=zones.slice().sort((a,b)=>(b.rank_score||0)-(a.rank_score||0))[0];const cf=sm.conflict?.message?` · ⚠ ${sm.conflict.message}`:'';summary.textContent=`${sm.supports||0} support · ${sm.resistances||0} resistance · top ${top?(top.zone_id||'ZONE')+' '+(top.rating||''):'--'}${cf}`;}
  }
  if(!zones.length){
    body.innerHTML='<tr><td colspan="9" class="sr-muted">Waiting for confirmed live S/R data…</td></tr>';
    return;
  }
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  body.innerHTML=zones.slice(0, smartSrMore?20:10).map(z=>{
    const typ=z.type==='S'?'SUPPORT':'RESISTANCE';
    const tf=Array.isArray(z.timeframes)?z.timeframes.join(' / '):'--';
    const dist=z.distance_pct==null?'--':`${Number(z.distance_pct).toFixed(2)}%`;
    const status=String(z.status||'TESTED');
    const statusCls=status.toLowerCase().replace(/[^a-z]/g,'');
    const rating=String(z.rating||'WEAK');
    const zoneKind=String(z.zone_kind||typ);
    const ratingCls=rating.toLowerCase().replace(/[^a-z]/g,'');
    return `<tr title="${esc((z.reason||'')+' · '+(z.quality||'')+' quality · '+(z.distance_class||''))}"><td><b>#${esc(z.rank||'--')} · ${esc(z.zone_id||'--')}</b><br><span class="small">${esc(zoneKind)}</span><br><span class="small">${esc(Number(z.low).toFixed(6))} — ${esc(Number(z.high).toFixed(6))}</span></td><td><span class="${z.type==='S'?'live':'waiting'}">${typ}</span></td><td><b>${esc(z.strength||0)}/100</b><br><span class="sr-rating ${ratingCls}">${esc(rating)}</span></td><td><b>${esc(z.quality_score||0)}</b> <span class="small">${esc(z.quality||'')}</span></td><td>${esc(z.touches||0)}</td><td>${esc(z.rejections||0)}</td><td>${esc(tf)}</td><td>${esc(dist)}<br><span class="small">${esc(z.distance_class||'')}</span></td><td><span class="sr-status ${statusCls}">${esc(status)}</span></td></tr>`;
  }).join('');
  const conflict=sm.conflict;
  if(summary && conflict?.message) summary.title=`${conflict.message} · clearance ${conflict.clearance_pct}% · ${conflict.support_id} vs ${conflict.resistance_id}`;
}

let reactionPanelEnabled=true;
function toggleReactionPanel(){reactionPanelEnabled=!reactionPanelEnabled;const g=document.getElementById('reactionGrid');if(g)g.style.display=reactionPanelEnabled?'grid':'none';const b=document.getElementById('reactionToggleBtn');if(b)b.textContent='REACTION: '+(reactionPanelEnabled?'ON':'OFF')}
function renderZoneReaction(c){const d=c?.zone_reaction||{};const meta=document.getElementById('reactionMeta');if(meta)meta.textContent=c?.pair?`${c.pair} · confirmed candles only`:'Waiting…';const z=document.getElementById('rxZone');if(z)z.textContent=d.nearest_zone_id?(d.nearest_zone_id+' · '+(d.nearest_zone_kind||'')):'--';const st=document.getElementById('rxStrength');if(st)st.textContent=String(d.nearest_zone_strength||0)+'/100';const di=document.getElementById('rxDistance');if(di)di.textContent=d.nearest_zone_distance==null?'--':Number(d.nearest_zone_distance).toFixed(2)+'%';const re=document.getElementById('rxReaction');if(re)re.textContent=d.active_reaction?.type||'NONE';const se=document.getElementById('rxStructure');if(se)se.textContent=d.structure_event||'NONE';const detail=document.getElementById('rxDetail');if(detail){let x=d.structure_detail||'';if(d.active_reaction)x+=(x?' · ':'')+d.active_reaction.zone_id+' '+d.active_reaction.type;detail.textContent=(x||'Waiting for confirmed reaction')+' · No synthetic candles / no gap filling';}}
function renderSetupFromChart(d,pair){
  if(!d)return;
  const fake={pair:pair,setup_bias:d.bias,setup_quality:d.quality,setup_confidence:d.confidence,setup_call_score:d.call_score,setup_put_score:d.put_score,setup_zone_id:d.active_zone_id,setup_zone_type:d.active_zone_type,setup_zone_strength:d.active_zone_strength,setup_zone_status:d.active_zone_status,setup_reaction:d.reaction,setup_structure:d.structure,setup_confirmations:d.confirmations,setup_risks:d.risks,setup_mtf_confluence:d.mtf_confluence_count,setup_sr_confluence:d.sr_confluence_count,setup_signal_reason:d.reason};
  renderSetupAnalyzer([fake],pair);
}
function renderChart(c,forceFollow=false){renderSrPanel(c);renderZoneReaction(c);if(c?.setup_confirmation)renderSetupFromChart(c.setup_confirmation,c.pair);const box=document.getElementById('chart');if(!box||!c||!c.candles?.length){if(box)box.innerHTML='<div class="small" style="padding:18px">Waiting for candle feed…</div>';return}drawChart(c,forceFollow)}

async function manualRefresh(){const b=document.getElementById('chartRefreshBtn');if(b){b.disabled=true;b.textContent='↻ REFRESHING...';}try{await refresh();showToast('Chart/feed refreshed')}finally{if(b){b.disabled=false;b.textContent='↻ REFRESH';}}}
function marketCls(v){v=String(v||'').toUpperCase();return v==='BULLISH'||v==='HIGH'?'call':v==='BEARISH'?'put':'wait'}
function renderMarketState(m,pair){
  if(!m)return;
  const set=(id,v,cl)=>{const e=document.getElementById(id);if(!e)return;e.textContent=(v==null||v==='')?'--':v;e.className=cl?'v '+marketCls(v):'v'};
  set('msState',m.state);set('msTrend',m.trend);set('msMomentum',m.momentum);set('msVol',m.volatility);set('msSupport',m.support!=null?m.support:'--');set('msResistance',m.resistance!=null?m.resistance:'--');
  const zone=(m.zone_type&&m.zone_type!=='NONE')?`${m.zone_type} · ${m.zone_strength||0} · ${m.zone_status||'NONE'}`:'NONE';set('msZone',zone);
  const meta=document.getElementById('marketStateMeta');if(meta)meta.textContent=(pair||'--')+' · '+(m.rsi!=null?'RSI '+m.rsi:'RSI --');
  const reason=document.getElementById('msReason');if(reason)reason.textContent=m.reason||'Live market state';
  const signature=[m.state,m.trend,m.momentum,m.zone_status,m.zone_strength,pair].join('|');
  if(marketAlertsEnabled&&lastMarketState&&signature!==lastMarketState){
    const strong=(m.zone_strength||0)>=80;
    if(strong || m.state!==lastMarketState.split('|')[0]) showToast('🔔 '+pair+' · '+m.state+(strong?' · Strong '+m.zone_type+' '+m.zone_strength:'') );
  }
  lastMarketState=signature;
}
function toggleMarketAlerts(){marketAlertsEnabled=!marketAlertsEnabled;const b=document.getElementById('marketAlertBtn');if(b){b.textContent=marketAlertsEnabled?'🔔 ALERTS: ON':'🔕 ALERTS: OFF';}}
let setupPanelEnabled=true;
function toggleSetupPanel(){setupPanelEnabled=!setupPanelEnabled;const b=document.getElementById('setupToggleBtn');const g=document.getElementById('setupGrid');const r=document.getElementById('setupReason');if(b)b.textContent=setupPanelEnabled?'SETUP: ON':'SETUP: OFF';if(g)g.style.display=setupPanelEnabled?'grid':'none';if(r)r.style.display=setupPanelEnabled?'block':'none';}
let allSetupPanelEnabled=true;
function toggleAllSetupPanel(){allSetupPanelEnabled=!allSetupPanelEnabled;const g=document.getElementById('allSetupGrid');const b=document.getElementById('allSetupToggleBtn');if(g)g.style.display=allSetupPanelEnabled?'grid':'none';if(b)b.textContent=allSetupPanelEnabled?'ALL SETUPS: ON':'ALL SETUPS: OFF';}
function selectSetupPair(pair){selectChartPair(pair);const sel=document.getElementById('chartPair');if(sel)sel.value=pair;showToast('Selected '+pair+' for LIVE CHART');}
function setupSignalClass(v){v=String(v||'').toUpperCase();return v.includes('CALL')?'call':v.includes('PUT')?'put':'wait'}
function renderAllSetupAnalyzer(rows,selectedPair){
  const box=document.getElementById('allSetupGrid'), meta=document.getElementById('allSetupMeta');
  if(!box)return;
  const arr=(Array.isArray(rows)?rows:[]).slice().sort((a,b)=>(Number(b.setup_confidence)||0)-(Number(a.setup_confidence)||0));
  if(meta)meta.textContent=arr.length+' chart'+(arr.length===1?'':'s')+' analyzed · sorted by setup confidence';
  if(!arr.length){box.innerHTML='<div class="small">Waiting for live chart data…</div>';return;}
  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  box.innerHTML=arr.map((r,i)=>{
    const bias=String(r.setup_bias||'WAIT'), q=String(r.setup_quality||'WAIT');
    const conf=Math.round(Number(r.setup_confidence)||0), mtf=Number(r.setup_mtf_confluence)||0, sr=Number(r.setup_sr_confluence)||0;
    const active=r.pair===selectedPair?'border:1px solid #61dafb;box-shadow:0 0 0 1px #61dafb22 inset;':'';
    const top=i===0&&conf>=75?'⭐ BEST · ':'';
    const reasons=Array.isArray(r.setup_confirmations)?r.setup_confirmations.slice(0,4).map(esc).join(' · '):'';
    const risks=Array.isArray(r.setup_risks)?r.setup_risks.slice(0,2).map(esc).join(' · '):'';
    return `<div class="stat" style="text-align:left;cursor:pointer;${active}" onclick="selectSetupPair('${esc(r.pair)}')" title="Click to analyze this chart"><div style="display:flex;justify-content:space-between;gap:6px;align-items:center"><b style="font-size:15px">${top}${esc(r.pair)}</b><span class="small">${esc(r.market||'')}</span></div><div style="display:grid;grid-template-columns:1.2fr .8fr .8fr .8fr;gap:6px;margin-top:8px"><div><span>BIAS</span><b class="${setupSignalClass(bias)}">${esc(bias)}</b></div><div><span>QUALITY</span><b>${esc(q)}</b></div><div><span>CONF.</span><b>${conf}%</b></div><div><span>MTF/SR</span><b>${mtf}/4 · ${sr}/4</b></div></div><div class="small" style="margin-top:7px">${reasons||'Waiting for strong confirmations'}</div>${risks?`<div class="small" style="margin-top:4px;opacity:.8">⚠ ${risks}</div>`:''}<div class="small" style="margin-top:7px">Zone: ${esc(r.setup_zone_type||'NONE')} ${Number(r.setup_zone_strength)||0} · Reaction: ${esc(r.setup_reaction||'NONE')} · Structure: ${esc(r.setup_structure||'NONE')}</div></div>`;
  }).join('');
}
function renderSetupAnalyzer(rows,pair){
  const r=(rows||[]).find(x=>x.pair===pair)||rows?.[0];
  if(!r)return;
  const bias=String(r.setup_bias||'WAIT');
  const set=(id,v,cl)=>{const e=document.getElementById(id);if(e){e.textContent=(v==null||v==='')?'--':v;if(cl)e.className='v '+(cl==='CALL'?'call':cl==='PUT'?'put':cl==='GOOD'?'call':'wait')}};
  set('setupBias',bias,bias.startsWith('CALL')?'CALL':bias.startsWith('PUT')?'PUT':'WAIT');
  set('setupQuality',r.setup_quality||'WAIT',r.setup_quality==='A+'||r.setup_quality==='A'?'GOOD':'WAIT');
  set('setupConfidence',String(r.setup_confidence??0)+'%');
  set('setupCallScore',r.setup_call_score??0); set('setupPutScore',r.setup_put_score??0);
  set('setupMtf',`${r.setup_mtf_confluence??0}/4`); set('setupSrMtf',`${r.setup_sr_confluence??0}/4`);
  set('setupZone',r.setup_zone_id?`${r.setup_zone_id} · ${r.setup_zone_type||''} · ${r.setup_zone_strength||0}`:'NONE');
  set('setupReaction',r.setup_reaction||'NONE'); set('setupStructure',r.setup_structure||'NONE');
  set('setup1m',r.signal_1m||'WAIT',r.signal_1m);set('setup2m',r.signal_2m||'WAIT',r.signal_2m);set('setup5m',r.signal_5m||'WAIT',r.signal_5m);set('setup10m',r.signal_10m||'WAIT',r.signal_10m);
  const list=(id,arr,empty)=>{const e=document.getElementById(id);if(e)e.innerHTML=(Array.isArray(arr)&&arr.length)?arr.map(x=>'• '+String(x).replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]))).join('<br>'):empty};
  list('setupConfirmations',r.setup_confirmations,'No strong confirmations yet');
  list('setupRisks',r.setup_risks,'No major conflict detected');
  const meta=document.getElementById('setupMeta');if(meta)meta.textContent=(r.pair||pair||'--')+' · Explainable analysis · confirmed data only';
  const reason=document.getElementById('setupReason');if(reason)reason.textContent=(r.setup_bias||'WAIT')+' · '+(r.setup_quality||'WAIT')+' quality · '+(r.setup_confidence??0)+'% confidence · MTF '+(r.setup_mtf_confluence??0)+'/4 · S/R '+(r.setup_sr_confluence??0)+'/4 · '+(r.setup_zone_status||'NONE')+' zone status · '+(r.setup_signal_reason||'Analysis only; no order/trade execution');
}

let lastBFSSSignalKey='',bfssZoomLevel=1,bfssPriceZoomLevel=1,bfssPanLive=true,bfssTF=1,bfssHistory=100,bfssPanX=0,bfssPanY=0,bfssDrag=false,bfssDragX=0,bfssDragY=0,bfssStartX=0,bfssStartY=0,bfssVisible=true;
function bfssFollowLive(){bfssPanLive=true;bfssPanX=0;document.getElementById('bfssLiveBtn')?.classList.add('active');renderBFSSChart(window.lastScan?.chart||null)}
function bfssZoom(dir){bfssZoomLevel=Math.max(.55,Math.min(4,bfssZoomLevel+(dir>0?.1:-.1)));bfssPanLive=false;renderBFSSChart(window.lastScan?.chart||null)}
function bfssPriceZoom(dir){bfssPriceZoomLevel=Math.max(.5,Math.min(4,bfssPriceZoomLevel+(dir>0?.1:-.1)));renderBFSSChart(window.lastScan?.chart||null)}
function bfssFit(){bfssZoomLevel=1;bfssPriceZoomLevel=1;bfssPanX=0;bfssPanY=0;bfssPanLive=true;renderBFSSChart(window.lastScan?.chart||null)}
function setBFSSChartTF(tf){bfssTF=Number(tf)||1;document.querySelectorAll('.bfss-tf').forEach(b=>b.classList.toggle('active',Number(b.dataset.btf)===bfssTF));bfssPanLive=true;renderBFSSChart(window.lastScan?.chart||null)}
function setBFSSHistory(n){bfssHistory=Number(n)||100;document.querySelectorAll('.bfss-hist').forEach(b=>b.classList.toggle('active',Number(b.dataset.bhist)===bfssHistory));renderBFSSChart(window.lastScan?.chart||null)}
function bfssToggleIndicators(){document.getElementById('bfssIndicatorBar')?.classList.toggle('open')}
function toggleBFSSChart(){bfssVisible=!bfssVisible;const p=document.getElementById('bfssChart')?.closest('.bfss-panel');if(p)p.style.display=bfssVisible?'block':'none';const b=document.getElementById('bfssToggleBtn');if(b)b.textContent=bfssVisible?'✕ REMOVE BFSS':'＋ ADD BFSS'}
function bfssResample(raw,mins){if(mins===1)return raw.slice();const out=[],step=mins*60;let cur=null;for(const c of raw){const k=Math.floor(c.t/step)*step;if(!cur||cur.t!==k){if(cur)out.push(cur);cur={t:k,o:c.o,h:c.h,l:c.l,c:c.c,complete:c.complete}}else{cur.h=Math.max(cur.h,c.h);cur.l=Math.min(cur.l,c.l);cur.c=c.c;cur.complete=c.complete}}if(cur)out.push(cur);return out}
function bfssPointerDown(e){const box=e.currentTarget;bfssDrag=true;box.classList.add('dragging');bfssDragX=e.clientX;bfssDragY=e.clientY;bfssStartX=bfssPanX;bfssStartY=bfssPanY;bfssPanLive=false}
function bfssPointerMove(e){if(!bfssDrag)return;const dx=e.clientX-bfssDragX,dy=e.clientY-bfssDragY;const sens=.35;bfssPanX=bfssStartX-dx*sens;bfssPanY=bfssStartY+dy*sens;renderBFSSChart(window.lastScan?.chart||null)}
function bfssPointerUp(e){bfssDrag=false;e.currentTarget.classList.remove('dragging')}
function bfssWheel(e){e.preventDefault();if(e.shiftKey||e.ctrlKey)bfssZoom(e.deltaY<0?1:-1);else bfssPriceZoom(e.deltaY<0?1:-1)}
function bfssClickSignal(c,x,y){const b=c.bfss||{};if(!b.signal||b.signal==='WAIT')return;showToast('BFSS '+b.signal+' · '+(b.confidence||0)+'% · '+(b.quality||'WAIT'))}
function renderBFSSChart(c){
 const box=document.getElementById('bfssChart');if(!box)return;
 if(!c||!c.candles?.length){box.innerHTML='<div class="small" style="padding:18px">Waiting for live candle feed…</div>';return}
 let canvas=box.querySelector('canvas');if(!canvas){box.innerHTML='<canvas tabindex="0"></canvas><div class="bfss-signal-box" id="bfssHud"></div>';canvas=box.querySelector('canvas');canvas.addEventListener('pointerdown',bfssPointerDown);canvas.addEventListener('pointermove',bfssPointerMove);canvas.addEventListener('pointerup',bfssPointerUp);canvas.addEventListener('pointercancel',bfssPointerUp);canvas.addEventListener('wheel',bfssWheel,{passive:false});canvas.addEventListener('dblclick',bfssFit)}
 const rect=box.getBoundingClientRect(),dpr=window.devicePixelRatio||1,W=Math.max(320,rect.width),H=Math.max(380,rect.height);canvas.width=Math.floor(W*dpr);canvas.height=Math.floor(H*dpr);canvas.style.width=W+'px';canvas.style.height=H+'px';const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,W,H);ctx.fillStyle='#080d13';ctx.fillRect(0,0,W,H);
 const raw=c.candles.slice(-Math.max(1000,bfssHistory*bfssTF));const data=bfssResample(raw,bfssTF).slice(-bfssHistory);if(!data.length)return;
 let lo=Math.min(...data.map(x=>x.l)),hi=Math.max(...data.map(x=>x.h));let span=Math.max(hi-lo,1e-12);let center=(hi+lo)/2-bfssPanY;span/=bfssPriceZoomLevel;lo=center-span/2;hi=center+span/2;
 const left=62,right=82,top=28,bottom=38,avail=W-left-right;const step=Math.max(5,(avail/Math.max(data.length,1))*bfssZoomLevel);const total=data.length*step;let start=bfssPanLive?Math.max(0,total-avail):Math.max(0,Math.min(Math.max(0,total-avail),bfssPanX));const y=p=>top+(hi-p)/span*(H-top-bottom),x=i=>left+i*step-start+step/2;
 if(document.getElementById('bfssShowGrid')?.checked!==false){ctx.strokeStyle='#182534';ctx.lineWidth=1;ctx.font='10px Arial';for(let k=0;k<6;k++){const yy=top+k*(H-top-bottom)/5;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(W-right,yy);ctx.stroke();ctx.fillStyle='#71859a';ctx.fillText(Number(hi-k*span/5).toFixed(5),W-right+5,yy+3)}}
 data.forEach((cc,i)=>{const xx=x(i);if(xx<left-12||xx>W-right+12)return;const up=cc.c>=cc.o;ctx.strokeStyle=up?'#16c784':'#ef5350';ctx.fillStyle=up?'#16c784':'#ef5350';ctx.beginPath();ctx.moveTo(xx,y(cc.h));ctx.lineTo(xx,y(cc.l));ctx.stroke();const bw=Math.max(2,Math.min(16,step*.68)),yy=y(Math.max(cc.o,cc.c)),hh=Math.max(1,Math.abs(y(cc.o)-y(cc.c)));ctx.fillRect(xx-bw/2,yy,bw,hh);if(i===data.length-1){ctx.strokeStyle='#f4d35e';ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(xx,top);ctx.lineTo(xx,H-bottom);ctx.stroke();ctx.setLineDash([])}});
 // BFSS historical/current CALL/PUT markers with their result.
 if(document.getElementById('bfssShowSignal')?.checked!==false){
   const mh=(c.signal_markers||[]).filter(m=>m.source==='BFSS');
   for(const m of mh){
     const idx=data.findIndex(z=>z.t===m.t); if(idx<0) continue; const xx=x(idx); const yy=m.signal==='CALL'?y(data[idx].l):y(data[idx].h); if(xx<left-24||xx>W-right+24) continue;
     ctx.fillStyle=m.signal==='CALL'?'#16c784':'#ef5350'; ctx.beginPath(); if(m.signal==='CALL'){ctx.moveTo(xx,yy+15);ctx.lineTo(xx-8,yy+3);ctx.lineTo(xx+8,yy+3)}else{ctx.moveTo(xx,yy-15);ctx.lineTo(xx-8,yy-3);ctx.lineTo(xx+8,yy-3)} ctx.closePath();ctx.fill();ctx.font='bold 10px Arial';ctx.fillText(m.signal,xx+9,yy+4);
     ctx.fillStyle=m.status==='WIN'?'#3be092':m.status==='LOSS'?'#ff6d73':'#f0c74b';ctx.font='bold 9px Arial';ctx.fillText(m.status||'PENDING',xx+9,yy+(m.signal==='CALL'?16:-8));
     if(m.move_pct!=null){const mv=(Number(m.move_pct)>0?'+':'')+Number(m.move_pct).toFixed(2)+'%';ctx.font='9px Arial';ctx.fillText(mv,xx+9,yy+(m.signal==='CALL'?28:-20));}
   }
 }
 // Fallback marker for the live BFSS signal if history has not created it yet.
 const b=c.bfss||{};const sig=b.signal||'WAIT';if(document.getElementById('bfssShowSignal')?.checked!==false&&sig!=='WAIT'){const i=data.length-1,curT=data[i]?.t;const hasCurrent=(c.signal_markers||[]).some(m=>m.source==='BFSS'&&m.t===curT&&m.signal===sig);if(!hasCurrent){const xx=x(i),yy=sig==='CALL'?y(data[i].l):y(data[i].h);ctx.fillStyle=sig==='CALL'?'#16c784':'#ef5350';ctx.beginPath();if(sig==='CALL'){ctx.moveTo(xx,yy+15);ctx.lineTo(xx-9,yy+2);ctx.lineTo(xx+9,yy+2)}else{ctx.moveTo(xx,yy-15);ctx.lineTo(xx-9,yy-2);ctx.lineTo(xx+9,yy-2)}ctx.closePath();ctx.fill();ctx.font='bold 11px Arial';ctx.fillText(sig,xx+11,yy+4)}}
 if(document.getElementById('bfssShowSR')?.checked!==false){const s=c.support,r=c.resistance;ctx.setLineDash([7,5]);ctx.lineWidth=1.2;if(s!=null&&s>=lo&&s<=hi){ctx.strokeStyle='#16c784';ctx.beginPath();ctx.moveTo(left,y(s));ctx.lineTo(W-right,y(s));ctx.stroke();ctx.fillStyle='#16c784';ctx.fillText('SUPPORT',left+4,y(s)-4)}if(r!=null&&r>=lo&&r<=hi){ctx.strokeStyle='#ef5350';ctx.beginPath();ctx.moveTo(left,y(r));ctx.lineTo(W-right,y(r));ctx.stroke();ctx.fillStyle='#ef5350';ctx.fillText('RESISTANCE',left+4,y(r)-4)}ctx.setLineDash([])}
 const hud=document.getElementById('bfssHud');if(hud)hud.innerHTML='<b style="color:'+(sig==='CALL'?'#16c784':sig==='PUT'?'#ef5350':'#f0c74b')+'">BFSS '+sig+'</b> · '+(b.confidence||0)+'% · '+(b.quality||'WAIT')+' · '+bfssTF+'M';
 const st=document.getElementById('bfssStatus');if(st)st.textContent=b.current_candle_complete?'LIVE · CURRENT CANDLE COMPLETE':'LIVE · CURRENT CANDLE FORMING';
 const bsel=document.getElementById('bfssPairSelect');if(bsel){const av=(window.lastScan?.available_pairs||[]);bsel.innerHTML=[...new Set([...(av||[]),c.pair||''])].filter(Boolean).map(p=>`<option value="${p}" ${p===c.pair?'selected':''}>${p}</option>`).join('')}document.getElementById('bfssSignal').textContent=sig;document.getElementById('bfssSignal').style.color=sig==='CALL'?'#3be092':sig==='PUT'?'#ff6d73':'#f0c74b';document.getElementById('bfssConfidence').textContent=(b.confidence??0)+'%';document.getElementById('bfssQuality').textContent=b.quality||'WAIT';document.getElementById('bfssTrend').textContent=c.market_state?.trend||'--';document.getElementById('bfssMomentum').textContent=c.market_state?.momentum||'--';document.getElementById('bfssReason').textContent=(b.reason||'Waiting')+' · '+(b.disclaimer||'');
 const bs=window.lastScan?.bfss_history_stats||{};document.getElementById('bfssWinRate').textContent=(bs.win_rate??0)+'%';document.getElementById('bfssMovePct').textContent=(bs.avg_move_pct??0)+'%';document.getElementById('bfssWL').textContent=(bs.wins||0)+' / '+(bs.losses||0);renderBFSSChat(window.lastScan||{});
}
function renderBFSSChat(d){const box=document.getElementById('bfssChat');if(!box)return;const rows=(d.bfss_history||[]).slice(0,40);box.innerHTML=rows.map(h=>{const cl=h.signal==='CALL'?'call':'put',r=h.status==='WIN'?'win':h.status==='LOSS'?'loss':'pending';const pct=h.move_pct!=null?(h.move_pct>0?'+':'')+h.move_pct+'%':'';return `<div class="bfss-msg ${cl}"><div class="bubble"><span class="tag">${h.signal}</span> · <b>${h.pair}</b> · ${h.confidence||0}%<br><span class="small">Entry ${h.entry} · Expiry ${h.expiry_time||'--'} · ${h.quality||'WAIT'}</span><br><b class="${r}">${h.status||'PENDING'}</b>${pct?' · <span class="'+r+'">'+pct+'</span>':''}</div></div>`}).join('')||'<div class="small">No BFSS-style signals yet.</div>'}
async function loadBFSSBacktest(){try{const pair=window.lastScan?.chart?.pair||'';const r=await fetch('/api/bfss/backtest'+(pair?'?pair='+encodeURIComponent(pair):''),{cache:'no-store'});const d=await r.json();if(!d.available){showToast('BFSS backtest unavailable');return}const t=d.total||{};document.getElementById('bfssBtTrades').textContent=t.trades||0;document.getElementById('bfssBtWins').textContent=t.wins||0;document.getElementById('bfssBtLosses').textContent=t.losses||0;document.getElementById('bfssBtAccuracy').textContent=(t.accuracy||0)+'%';const ca=d.call||{},pu=d.put||{};document.getElementById('bfssBtCall').textContent=(ca.wins||0)+' / '+(ca.accuracy||0)+'%';document.getElementById('bfssBtPut').textContent=(pu.wins||0)+' / '+(pu.accuracy||0)+'%';document.getElementById('bfssBtMove').textContent=(t.avg_move_pct||0)+'%';document.getElementById('bfssBtSource').textContent=(d.source||'')+' · '+(d.disclaimer||'');showToast('BFSS backtest updated')}catch(e){showToast('BFSS backtest failed: '+e.message)}}
function renderAIReasonPanel(d){const panel=document.getElementById('aiReasonPanel');if(!panel)return;const rows=Array.isArray(d?.rows)?d.rows:[];const pair=d?.chart?.pair||rows[0]?.pair||'--';const r=rows.find(x=>x.pair===pair)||rows[0]||{};const on=!!r.ai_mode;const mode=document.getElementById('aiPanelMode'),sig=document.getElementById('aiPanelSignal'),conf=document.getElementById('aiPanelConfidence'),dec=document.getElementById('aiPanelDecision'),raw=document.getElementById('aiPanelRaw'),whyTitle=document.getElementById('aiPanelWhyTitle'),why=document.getElementById('aiPanelWhy'),factors=document.getElementById('aiPanelFactors'),pairEl=document.getElementById('aiPanelPair');pairEl.textContent=pair+' · '+(d?.chart?.timeframe||chartTF||'1M');mode.textContent=on?'AI ON':'AI OFF';mode.style.background=on?'#123a29':'#241b3c';mode.style.borderColor=on?'#287653':'#6246a4';sig.textContent=on?(r.ai_signal||'WAIT'):'WAIT';sig.className=(on&&typeof cls==='function')?cls(r.ai_signal):'';conf.textContent=on?((r.ai_confidence??0)+'%'):'0%';dec.textContent=on?(r.ai_decision||'WAIT'):'BYPASS';raw.textContent=on?(r.raw_signal||r.signal||'WAIT'):(r.signal||'WAIT');if(on){whyTitle.textContent=(r.ai_signal||'WAIT')==='CALL'?'WHY BUY / CALL?':(r.ai_signal||'WAIT')==='PUT'?'WHY SELL / PUT?':'WHY WAIT?';why.textContent=r.ai_reason||'AI analysis active; no additional reason returned.';}else{whyTitle.textContent='AI OFF — NORMAL ENGINE ACTIVE';why.textContent='AI does not modify the normal signal while AI MODE is OFF.';}factors.innerHTML=on?(Array.isArray(r.ai_factors)?r.ai_factors:[]).map(x=>{const t=String(x);let c=/conflict|invalid|gap|stale|risk|below/i.test(t)?'bad':/agree|support|resistance|trend|retest|reaction|integrity|momentum/i.test(t)?'good':'wait';return '<span class="ai-factor '+c+'">'+esc(t)+'</span>'}).join(''):'<span class="ai-factor wait">AI BYPASSED</span>';}
async function refresh(){if(refreshing)return;refreshing=true;try{let ctl=new AbortController();let timer=setTimeout(()=>ctl.abort(),2500);let r=await fetch('/api/scan',{cache:'no-store',signal:ctl.signal});clearTimeout(timer);let d=await r.json();window.lastScan=d;applySettings(d.settings);updateSyncPanel(d);renderChartPairOptions(d);syncChartToolbar();const chartKey=d.chart?`${d.chart.pair}|${d.chart.candle_count}|${d.chart.server_time?Math.floor(d.chart.server_time):0}|${chartTF}|${chartHistory}|${chartZoomLevel}|${chartPriceZoom}|${chartPanY}`:'';if(chartKey!==chartRenderKey){chartRenderKey=chartKey;renderChart(d.chart);}renderBFSSChart(d.chart);const fb=d.chart?.bfss||{};const fkey=d.chart?.pair+'|'+(fb.signal||'WAIT')+'|'+(d.chart?.live_bucket||'');if((fb.signal==='CALL'||fb.signal==='PUT')&&fkey!==lastBFSSSignalKey){lastBFSSSignalKey=fkey;showToast('BFSS '+fb.signal+' · '+(fb.confidence||0)+'% · '+(fb.quality||'WAIT'));beep(fb.signal)}else if(fkey!==lastBFSSSignalKey){lastBFSSSignalKey=fkey}renderMarketState(d.market_state,d.chart?.pair);renderAIReasonPanel(d);renderAllSetupAnalyzer(d.rows,d.chart?.pair);renderSetupAnalyzer(d.rows,d.chart?.pair);document.getElementById('pairs').textContent=d.pairs;let feed=document.getElementById('feed');feed.innerHTML=d.feed?'<span class="live">● LIVE</span>':'<span class="waiting">● WAITING</span>';let b=d.rows.find(x=>x.signal==='CALL'||x.signal==='PUT')||d.rows[0];document.getElementById('best').textContent=b?.pair||'--';let bs=document.getElementById('sig');bs.textContent=b?.signal||'--';bs.className='v '+cls(b?.signal);let sb=d.structure_best||{};document.getElementById('structureBestPair').textContent=sb.pair||'--';let ss=document.getElementById('structureSignal');ss.textContent=sb.signal||'WAIT';ss.className='v '+cls(sb.signal);document.getElementById('structureType').textContent=(sb.timeframe?sb.timeframe+' · ':'')+(sb.structure||'--');document.getElementById('structureConfidence').textContent=(sb.confidence??0)+'%';document.getElementById('status').textContent=d.feed?'Live feed connected. Original V4 analysis updating automatically.':'Waiting for authorized browser quote frames...';for(const x of d.rows){let prev=lastSignals[x.pair];if((x.signal==='CALL'||x.signal==='PUT')&&x.signal!==prev)beep(x.signal);lastSignals[x.pair]=x.signal}document.getElementById('body').innerHTML=d.rows.map(x=>`<tr><td title="${x.pair}">${x.pair}</td><td>${x.market}</td><td>${x.price}</td><td><span class="${cls(x.signal)}">${x.signal}</span></td><td>${x.ai_mode?'<span class="'+cls(x.ai_signal)+'">'+x.ai_signal+'</span><br><span class="small">'+(x.ai_confidence??0)+'%</span>':'<span class="small">OFF</span>'}</td><td><span class="${cls(x.signal_1m)}">${x.signal_1m}</span><br><span class="small">${x.score_1m}</span></td><td><span class="${cls(x.signal_2m)}">${x.signal_2m}</span><br><span class="small">${x.score_2m}</span></td><td><span class="${cls(x.signal_5m)}">${x.signal_5m}</span><br><span class="small">${x.score_5m}</span></td><td><span class="${cls(x.signal_10m)}">${x.signal_10m}</span><br><span class="small">${x.score_10m}</span></td><td>${x.trend_1h??'--'}</td><td>${x.confidence??'--'}%</td><td>${x.score}</td><td>${x.volatility}</td><td>${x.rsi??'--'}</td><td>${x.macd??'--'}</td><td>${x.ema??'--'}</td><td>${x.trend5m??'--'}</td><td>${x.pattern??'--'}</td><td><b>${x.structure??'--'}</b><br><span class="small">${x.structure_signal??'WAIT'} ${x.structure_confidence??0}%</span></td><td><span class="small">S: ${x.support??'--'}<br>R: ${x.resistance??'--'}</span></td><td><span class="${cls(x.structure_1m_signal)}">${x.structure_1m_signal||'WAIT'}</span><br><span class="small">${x.structure_1m_confidence||0}%</span></td><td><span class="${cls(x.structure_2m_signal)}">${x.structure_2m_signal||'WAIT'}</span><br><span class="small">${x.structure_2m_confidence||0}%</span></td><td><span class="${cls(x.structure_5m_signal)}">${x.structure_5m_signal||'WAIT'}</span><br><span class="small">${x.structure_5m_confidence||0}%</span></td><td><span class="${cls(x.structure_10m_signal)}">${x.structure_10m_signal||'WAIT'}</span><br><span class="small">${x.structure_10m_confidence||0}%</span></td><td>${x.candles}</td><td>${x.quality??'--'}</td><td title="${x.reason||''}">${x.reason||''}</td><td>${x.updated}</td></tr>`).join('');renderPairs(d);renderHistory(d)}catch(e){if(e.name!=='AbortError')document.getElementById('status').textContent='Server error: '+e.message}finally{refreshing=false}}setInterval(refresh,1000);refresh();setTimeout(loadBFSSBacktest,1200);
</script></body></html>'''

def history_csv_bytes(scope='normal'):
    import csv, io
    if scope=='structure':
        rows=list(structure_history)
    elif scope=='all':
        rows=list(signal_history)+list(structure_history)
    else:
        rows=list(signal_history)
    fields=['source','signal_id','time','pair','tf','signal','entry','exit','status','confidence','score','signal_bar','target_bar','expiry_time','result_time','move','structure','event','zone_id','reason','resolution']
    buf=io.StringIO(newline='')
    w=csv.DictWriter(buf,fieldnames=fields,extrasaction='ignore'); w.writeheader()
    for h in rows:
        r=dict(h); r['source']=r.get('source','NORMAL')
        w.writerow({k:r.get(k,'') for k in fields})
    return buf.getvalue().encode('utf-8-sig')


def backtest_validation_report():
    """Run the deterministic report engine against persistent completed signals."""
    try:
        if validator is None: return {'available':False,'reason':'Validator unavailable'}
        from pathlib import Path
        from importlib.util import spec_from_file_location, module_from_spec
        mod_path=os.path.join(_validation_dir,'backtest_engine.py')
        spec=spec_from_file_location('qx_backtest_engine',mod_path)
        mod=module_from_spec(spec); spec.loader.exec_module(mod)
        report=mod.run(str(validator.completed_path))
        return {'available':True,'source':str(validator.completed_path),'total':report.get('total',{}),
                'by_timeframe':report.get('by_timeframe',{}),'by_pair':report.get('by_pair',{}),
                'by_signal':report.get('by_signal',{}),'by_confirmation_band':report.get('by_confirmation_band',{})}
    except Exception as e:
        log.exception('Backtest report failed')
        return {'available':False,'reason':str(e)}


class H(BaseHTTPRequestHandler):
    def send_json(self,obj):
        def clean(v):
            if isinstance(v,float) and not math.isfinite(v): return None
            if isinstance(v,dict): return {k:clean(x) for k,x in v.items()}
            if isinstance(v,(list,tuple)): return [clean(x) for x in v]
            return v
        b=json.dumps(clean(obj), allow_nan=False).encode('utf-8')
        self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.end_headers(); self.wfile.write(b)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.send_header('Access-Control-Allow-Methods','POST,GET,OPTIONS'); self.end_headers()
    def do_GET(self):
        if self.path=='/api/performance': self.send_json(performance_summary()); return
        if self.path=='/api/structure/performance': self.send_json(structure_performance_summary()); return
        if self.path.startswith('/api/candle/integrity'):
            q=parse_qs(urlparse(self.path).query).get('pair',[''])[0].strip()
            if q: self.send_json(candle_integrity(q)); return
            self.send_json({'pairs':{p:candle_integrity(p) for p in list(last_quote.keys())}}); return
        if self.path=='/api/validation/status': self.send_json(validation_file_summary()); return
        if self.path=='/api/validation/report': self.send_json(backtest_validation_report()); return
        if self.path.startswith('/api/bfss/backtest'):
            from urllib.parse import urlparse, parse_qs
            q=parse_qs(urlparse(self.path).query).get('pair',[''])[0].strip() or None
            self.send_json(bfss_backtest_report(q)); return
        if self.path.startswith('/api/history/export'):
            from urllib.parse import urlparse, parse_qs
            scope=parse_qs(urlparse(self.path).query).get('scope',['normal'])[0]
            if scope not in ('normal','structure','all'): scope='normal'
            b=history_csv_bytes(scope); self.send_response(200); self.send_header('Content-Type','text/csv; charset=utf-8'); self.send_header('Content-Disposition',f'attachment; filename=quotex_{scope}_signal_history.csv'); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b); return
        if self.path=='/api/scan': self.send_json(scan()); return
        if self.path=='/api/status':
            self.send_json({'ok':True,'feed':bool(last_update) and time.time()-max(last_update.values())<8,'last_frame_age':round(time.time()-last_frame_time,1) if last_frame_time else None,'last_accepted':last_accepted,'raw_frames':raw_frames[-20:] if isinstance(raw_frames,list) else raw_frames,'raw_pairs':dict(raw_pairs),'http_history_frames':http_history_frames,'historical_candles':sum(len(v) for v in historical_candles.values()),'historical_pairs':{k:len(v) for k,v in historical_candles.items()},'last_error':last_error,'settings_file':SETTINGS_FILE})
            return
        if self.path.startswith('/api/chart'):
            from urllib.parse import urlparse, parse_qs
            q=parse_qs(urlparse(self.path).query).get('pair',[''])[0]
            if q and q in candles: self.send_json(chart_payload(q)); return
            self.send_json({'error':'pair not found'}); return
        if self.path=='/':
            b=HTML.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(b); return
        self.send_response(404); self.end_headers()
    def do_POST(self):
        global selected_chart_pair
        # Parse the route without its query string. The chart selector adds a
        # cache-busting ?ts=... parameter, so comparing self.path directly
        # would otherwise fall through and return an empty 404 response.
        from urllib.parse import urlparse
        route=urlparse(self.path).path
        if route=='/api/chart/select':
            try:
                n=int(self.headers.get('Content-Length','0')); obj=json.loads(self.rfile.read(n))
                pair=str(obj.get('pair','')).strip()
                with lock:
                    if pair in last_quote and pair_enabled(pair):
                        selected_chart_pair=pair
                        self.send_json({'ok':True,'pair':pair,'chart':chart_payload(pair)})
                    else:
                        self.send_json({'ok':False,'error':'Pair is not enabled or not receiving quotes'})
            except Exception as e:
                log.exception('Chart selection failed')
                self.send_json({'ok':False,'error':str(e)})
            return
        if route=='/api/settings':
            try:
                n=int(self.headers.get('Content-Length','0')); obj=json.loads(self.rfile.read(n))
                with lock:
                    if obj.get('mode') in ('normal','full'): settings['mode']=obj['mode']
                    for k in ('ai_mode','filter_5m','filter_macd','filter_rsi','filter_pattern','filter_volatility','strict_score','smart_confluence','alerts','signal_1m','signal_2m','signal_5m','signal_10m','structure_1m','structure_2m','structure_5m','structure_10m','history_1m','history_2m','history_5m','history_10m','structure_history_1m','structure_history_2m','structure_history_5m','structure_history_10m','confirmation_70','strong_signal_filter','mtf_confluence','signal_quality_guard','structure_analysis','filter_structure'):
                        if k in obj: settings[k]=bool(obj[k])
                    if 'enabled_pairs' in obj and isinstance(obj['enabled_pairs'], list):
                        clean=[]
                        for x in obj['enabled_pairs']:
                            q=str(x).strip()
                            if valid_pair(q) and q not in clean: clean.append(q)
                        settings['enabled_pairs']=clean
                    if 'pair_filter_enabled' in obj: settings['pair_filter_enabled']=bool(obj['pair_filter_enabled'])
                saved=_save_settings()
                self.send_json({'ok':True,'saved':saved,'settings':settings.copy()})
            except Exception as e:
                log.exception('Settings update failed')
                self.send_json({'ok':False,'error':str(e)})
            return
        if route=='/api/performance/reset':
            # Accuracy/backtest reset affects only the normal scanner history.
            with lock:
                signal_history.clear()
            self.send_json({'ok':True})
            return
        if route=='/api/history/normal-reset':
            with lock:
                signal_history.clear()
            self.send_json({'ok':True,'scope':'normal'})
            return
        if route=='/api/history/structure-reset':
            with lock:
                structure_history.clear()
            self.send_json({'ok':True,'scope':'structure'})
            return
        if route=='/api/history/reset':
            # Legacy endpoint: reset both together; dashboard uses separate endpoints.
            with lock:
                signal_history.clear()
                structure_history.clear()
                last_structure_bar.clear()
                last_candle_seen.clear()
                last_bar_seen_5m.clear()
                last_structure_bar_2m.clear()
                last_structure_bar_5m.clear()
                last_structure_bar_10m.clear()
                last_completed_1m.clear()
                last_completed_2m.clear()
                last_completed_5m.clear()
                last_completed_10m.clear()
            self.send_json({'ok':True,'scope':'all'})
            return
        if self.path!='/api/frame': self.send_response(404); self.end_headers(); return
        global last_frame_time, last_accepted, last_error, raw_frames, http_history_frames
        try:
            n=int(self.headers.get('Content-Length','0'))
            obj=json.loads(self.rfile.read(n))
            data=obj.get('data')
            meta=obj.get('meta') or {}
            if isinstance(meta,dict) and meta.get('kind')=='http_history':
                http_history_frames += 1
            last_frame_time=time.time()
            raw_frames += 1
            if data == '__QX_EXTENSION_HEARTBEAT__':
                self.send_json({'ok':True,'accepted':0,'heartbeat':True})
                return
            parsed=parse_payload(data)
            candle_parsed=parse_candle_payload(data)
            accepted=0
            historical_accepted=0
            with lock:
                for pair,ts,price in parsed:
                    pair=str(pair).strip()
                    if not valid_quote(pair, ts, price):
                        continue
                    ticks[pair].append((ts,price))
                    candle_dirty[pair]=True
                    last_quote[pair]=(ts,price)
                    last_update[pair]=time.time()
                    accepted+=1
                    raw_pairs[pair] += 1
                # R8.2: discard all previous OHLC/history payloads.
                # Only live quote ticks are allowed to build candles.
                historical_accepted=0
                last_accepted=accepted
                last_error=''
            self.send_json({'ok':True,'accepted':accepted,'historical_candles':historical_accepted})
        except Exception as e:
            last_error=str(e)
            log.exception('Frame processing failed')
            self.send_json({'ok':False,'error':str(e)})
    def log_message(self,*args): pass

if __name__=='__main__':
    print(f'Quotex Live Market Scanner V7.1.7 LIVE CHART PERFORMANCE FIX: http://{HOST}:{PORT}')
    ThreadingHTTPServer((HOST,PORT),H).serve_forever()
