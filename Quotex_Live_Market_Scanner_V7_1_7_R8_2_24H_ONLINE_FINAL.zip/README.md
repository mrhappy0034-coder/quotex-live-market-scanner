# Quotex Live Market Scanner V7.1.7 BFSS-Style Live Sync

V7.1.2 is an analysis-only scanner with next-candle signal markers, automatic S/R structure analysis, and a real validation pipeline.

## Fixed in V7.1.2
- Internal version is now consistently V7.1.2.
- Every normal and S/R signal gets a unique `signal_id`.
- Signal creation is logged to `validation/live_signals.csv`.
- Completed target-candle results are logged to `validation/completed_signals.csv`.
- WIN/LOSS/DRAW is calculated only from entry price versus the completed target candle close.
- PENDING signals are excluded from accuracy.
- Backtest reports now group by timeframe, pair, direction, pattern, S/R condition, event, and confidence band.
- Reports flag samples below 30 decided trades as statistically insufficient instead of implying that a tiny sample is reliable.
- 1M/2M/5M/10M normal signals remain independently toggleable.
- S/R 1M/2M/5M/10M remain independently toggleable.
- Historical backfill remains walk-forward: a target candle is evaluated only from candles available before that target.

## Validation
1. Start the server with `server\run_server.bat`.
2. Connect the authorized browser quote feed.
3. Let completed target candles accumulate.
4. Run `validation\run_validation.bat`.
5. Review `validation\v71_report.json`.

The previous `signals_template.csv` is only a sample/template and is not a valid accuracy dataset.

## Important
This project is analysis-only. It does not place trades or automate account actions. Signal quality depends on the supplied quote/candle feed.

## V7.1.2 chart update
- Increased live chart height on desktop and mobile.
- Increased candle horizontal spacing for a wider, easier-to-pan chart.
- Added requestAnimationFrame-based smooth pan/hover rendering.
- Added responsive ResizeObserver redraw.
- Signal/S/R logic is unchanged.


## V7.1.6 history sync fix
- Captures Quotex initial historical OHLC responses delivered through WebSocket, fetch, or XHR.
- Supports common Quotex history row order `[timestamp, open, close, high, low]`.
- Nested `data/candles/history` response wrappers are decoded recursively.
- Authoritative completed OHLC history overrides sparse tick reconstruction for matching minute buckets.
- The currently forming candle continues to follow the live quote feed.
- Signal and S/R calculation logic is unchanged.

After installing the updated extension, reload the Quotex trading page so the history capture hook is active from page start.


## V7.1.6 selected upgrades
- **Signal Quality Guard ON/OFF**: optional live quality/risk gate; OFF preserves the existing core signal behavior.
- **Smart S/R**: stronger zone lifecycle/status evidence (fresh/tested/retest/broken/weak), MTF confluence, rejection/touch quality and conflict awareness.
- **Market Data Sync Monitor**: live feed age, authoritative history count, candle count/gaps and HTTP-history capture count.
- **Signal History CSV**: export NORMAL, STRUCTURE, or ALL signal history directly from the UI.
- **Persistent Live Validation + Backtest**: saved completed-signals CSV summary plus deterministic backtest report by timeframe.
- Analysis-only; no trade execution or account control.

## V7.1.7 BFSS-style live chart upgrade
- Added a separate BFSS-STYLE LIVE CHART panel using the same authorized live candle feed.
- Current/forming candle is rendered live and previous completed candles remain visible.
- Added BFSS-style public-material-inspired analysis overlay: trend, momentum, candle/price action, S/R reaction and confirmation.
- Added BFSS signal, confidence, quality, trend and momentum dashboard.
- Explicitly does NOT claim proprietary BFSS source/code or private BFSS feed access.
- Analysis-only; no trade execution or account control.


## V7.1.7 LIVE SYNC HARDENING
- Expanded asset-symbol validation so non-6-letter Quotex symbols such as commodity/crypto-style names are not rejected solely by length.
- Completed OHLC history remains authoritative for closed minutes.
- The latest live quote always updates the exact current minute bucket, preventing a frozen/stale forming candle when history contains a snapshot for that minute.
- Added explicit `live_bucket`, `live_candle_complete`, and `previous_5_completed` chart metadata for UI validation.
- Extension manifest version/name aligned with V7.1.7.


## V7.1.7-R6 hard sync fix
- Closed candles are authoritative OHLC-only.
- Current/forming candle is live-tick-only.
- Previous-five validation uses exact minute buckets immediately before the live bucket.
- Stale/future history cannot replace the current live candle.

## V7.1.7-R7 additions
The scanner now includes a Candle Integrity checker. It validates the five exact completed 1-minute buckets immediately preceding the live bucket, detects gaps/duplicates and quote staleness, and exposes the result in the Sync panel and `/api/candle/integrity?pair=...`. It never synthesizes missing market data.
