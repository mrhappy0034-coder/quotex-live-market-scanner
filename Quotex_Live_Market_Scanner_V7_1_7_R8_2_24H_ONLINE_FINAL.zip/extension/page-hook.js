(()=> {
  if (window.__QX_SCANNER_HOOK_V3__) return;
  window.__QX_SCANNER_HOOK_V3__ = true;

  const NativeWS = window.WebSocket;
  // A single native MessageEvent can pass through both the direct wrapper
  // listener and the patched addEventListener/onmessage paths. Forward each
  // event object only once to prevent duplicate ticks/candles.
  const forwardedEvents = new WeakSet();
  function forwardEvent(ev) {
    if (ev && (typeof ev === 'object' || typeof ev === 'function')) {
      if (forwardedEvents.has(ev)) return;
      forwardedEvents.add(ev);
    }
    try { forward(ev && ev.data); } catch (_) {}
  }

  function post(payload, meta) {
    try {
      window.postMessage({
        source: 'QX_LIVE_SCANNER',
        payload,
        meta: meta || {}
      }, '*');
    } catch (_) {}
  }

  function toHex(buffer) {
    const u = new Uint8Array(buffer);
    let s = '';
    const chunk = 8192;
    for (let i=0; i<u.length; i+=chunk) {
      const end=Math.min(i+chunk,u.length);
      for(let j=i;j<end;j++) s += u[j].toString(16).padStart(2,'0');
    }
    return s;
  }

  function forward(data) {
    if (typeof data === 'string') {
      post(data, {kind:'text'});
      return;
    }
    if (data instanceof ArrayBuffer) {
      post(toHex(data), {kind:'arraybuffer'});
      return;
    }
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      const r = new FileReader();
      r.onload = () => post(toHex(r.result), {kind:'blob'});
      r.readAsArrayBuffer(data);
    }
  }

  function WrappedWebSocket(url, protocols) {
    const ws = protocols === undefined ? new NativeWS(url) : new NativeWS(url, protocols);
    try {
      ws.addEventListener('message', forwardEvent);
    } catch (_) {}
    try {
      ws.addEventListener('open', () => post('__QX_WS_OPEN__', {kind:'status', url:String(url)}));
      ws.addEventListener('close', () => post('__QX_WS_CLOSE__', {kind:'status', url:String(url)}));
    } catch (_) {}
    return ws;
  }

  // Preserve native WebSocket API properties expected by Socket.IO/Engine.IO.
  for (const k of ['CONNECTING','OPEN','CLOSING','CLOSED']) {
    try { Object.defineProperty(WrappedWebSocket, k, {value: NativeWS[k]}); } catch (_) {}
  }
  WrappedWebSocket.prototype = NativeWS.prototype;
  try { Object.defineProperty(WrappedWebSocket, 'name', {value:'WebSocket'}); } catch (_) {}
  try { Object.defineProperty(WrappedWebSocket, 'length', {value:2}); } catch (_) {}

  window.WebSocket = WrappedWebSocket;

  // Capture message handlers assigned with ws.onmessage = fn.
  const onmsgDesc = Object.getOwnPropertyDescriptor(NativeWS.prototype, 'onmessage');
  if (onmsgDesc && onmsgDesc.set && !NativeWS.prototype.__qx_onmessage_patch__) {
    Object.defineProperty(NativeWS.prototype, '__qx_onmessage_patch__', {value:true});
    Object.defineProperty(NativeWS.prototype, 'onmessage', {
      configurable: onmsgDesc.configurable,
      enumerable: onmsgDesc.enumerable,
      get: onmsgDesc.get,
      set(fn) {
        if (typeof fn === 'function') {
          return onmsgDesc.set.call(this, function(ev) {
            try { forwardEvent(ev); } catch (_) {}
            return fn.call(this, ev);
          });
        }
        return onmsgDesc.set.call(this, fn);
      }
    });
  }

  // Also observe listeners attached through addEventListener, including sockets
  // created with a previously saved native constructor.
  const nativeAdd = NativeWS.prototype.addEventListener;
  if (!NativeWS.prototype.__qx_listener_patch__) {
    Object.defineProperty(NativeWS.prototype, '__qx_listener_patch__', {value:true});
    NativeWS.prototype.addEventListener = function(type, listener, options) {
      if (type === 'message' && typeof listener === 'function') {
        const wrapped = function(ev) {
          try { forwardEvent(ev); } catch (_) {}
          return listener.call(this, ev);
        };
        return nativeAdd.call(this, type, wrapped, options);
      }
      return nativeAdd.call(this, type, listener, options);
    };
  }

  // Capture initial historical candle responses delivered through fetch/XHR.
  // Live ticks still come through WebSocket. This prevents recent history from
  // being reconstructed from sparse ticks when the browser already has the
  // authoritative OHLC history.
  const MAX_HTTP_CAPTURE = 2 * 1024 * 1024;
  function looksLikeCandlePayload(text, url='') {
    const u=String(url||'').toLowerCase();
    if (/(history|candle|chart|quote|series|ohlc)/.test(u)) return true;
    const t=String(text||'');
    return /"(?:candles|candle|history|data)"\s*[:\[]/i.test(t) &&
           /(?:open|high|low|close|timestamp|time)/i.test(t);
  }
  function forwardHttpText(text, url, transport) {
    try {
      if (typeof text !== 'string' || !text || text.length > MAX_HTTP_CAPTURE) return;
      if (!looksLikeCandlePayload(text,url)) return;
      post(text, {kind:'http_history', transport, url:String(url||'').slice(0,500)});
    } catch (_) {}
  }
  try {
    const nativeFetch=window.fetch;
    if (typeof nativeFetch==='function' && !window.__QX_FETCH_PATCH__) {
      window.__QX_FETCH_PATCH__=true;
      window.fetch=function(...args) {
        const req=args[0];
        const url=typeof req==='string'?req:(req&&req.url)||'';
        return nativeFetch.apply(this,args).then(resp=>{
          try { resp.clone().text().then(t=>forwardHttpText(t,url,'fetch')).catch(()=>{}); } catch (_) {}
          return resp;
        });
      };
    }
  } catch (_) {}
  try {
    const XHR=window.XMLHttpRequest;
    if (XHR && !XHR.prototype.__QX_HTTP_PATCH__) {
      Object.defineProperty(XHR.prototype,'__QX_HTTP_PATCH__',{value:true});
      const nativeOpen=XHR.prototype.open;
      const nativeSend=XHR.prototype.send;
      XHR.prototype.open=function(method,url,...rest){
        try { this.__qx_url=String(url||''); } catch (_) {}
        return nativeOpen.call(this,method,url,...rest);
      };
      XHR.prototype.send=function(body){
        try { this.addEventListener('load',()=>{
          try { forwardHttpText(this.responseText,this.__qx_url||'','xhr'); } catch (_) {}
        }); } catch (_) {}
        return nativeSend.call(this,body);
      };
    }
  } catch (_) {}

  post('__QX_HOOK_READY__', {kind:'status', history_capture:true});
})();