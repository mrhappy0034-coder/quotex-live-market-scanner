@echo off
cd /d "%~dp0.."
if not exist validation\completed_signals.csv (
  echo No completed_signals.csv yet. Start server and connect the authorized browser feed first.
  pause
  exit /b 0
)
python validation\backtest_engine.py validation\completed_signals.csv --out validation\v71_report.json
if errorlevel 1 (
  echo Validation report failed.
) else (
  echo Report written to validation\v71_report.json
)
pause
