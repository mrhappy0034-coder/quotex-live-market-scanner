"""V7.1.1 deterministic backtest/report engine.

The engine accepts completed signal CSV rows, excludes pending/unknown rows,
and reports accuracy by timeframe, pair, direction, event/pattern, S/R
condition, confidence band and minimum sample size.
"""
import csv, json, argparse
from pathlib import Path
from collections import defaultdict

def num(x, default=0.0):
    try: return float(x)
    except (TypeError,ValueError): return default

def result(signal, entry, expiry):
    s=str(signal or '').upper()
    e,x=num(entry),num(expiry)
    if s in ('CALL','BUY'): return 'WIN' if x>e else 'DRAW' if x==e else 'LOSS'
    if s in ('PUT','SELL'): return 'WIN' if x<e else 'DRAW' if x==e else 'LOSS'
    return 'UNKNOWN'

def load_csv(path):
    rows=[]
    with open(path,newline='',encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            if not r.get('pair') or not r.get('signal'): continue
            r['entry']=num(r.get('entry'))
            r['expiry_price']=num(r.get('expiry_price'))
            if not r.get('result') or str(r.get('result')).upper() in ('PENDING','UNKNOWN',''):
                r['result']=result(r['signal'],r['entry'],r['expiry_price'])
            r['result']=str(r['result']).upper()
            if r['result'] not in ('WIN','LOSS','DRAW'): continue
            r['confirmation']=num(r.get('confirmation'))
            rows.append(r)
    return rows

def stats(rows):
    w=sum(r['result']=='WIN' for r in rows); l=sum(r['result']=='LOSS' for r in rows); d=sum(r['result']=='DRAW' for r in rows)
    decided=w+l
    return {'trades':len(rows),'wins':w,'losses':l,'draws':d,'accuracy':round(w/decided*100,2) if decided else 0.0,'sample_sufficient':decided>=30}

def grouped(rows, field):
    g=defaultdict(list)
    for r in rows: g[str(r.get(field) or 'UNKNOWN')].append(r)
    return {k:stats(v) for k,v in sorted(g.items())}

def band(c):
    return '90-100%' if c>=90 else '80-89%' if c>=80 else '70-79%' if c>=70 else '<70%'

def run(path,out=None):
    rows=load_csv(path)
    bands=defaultdict(list)
    for r in rows: bands[band(r['confirmation'])].append(r)
    report={'version':'V7.1.1','source':str(path),'total':stats(rows),
            'by_timeframe':grouped(rows,'timeframe'),'by_pair':grouped(rows,'pair'),
            'by_signal':grouped(rows,'signal'),'by_pattern':grouped(rows,'pattern'),
            'by_sr_condition':grouped(rows,'sr_condition'),'by_event':grouped(rows,'event'),
            'by_confirmation_band':{k:stats(v) for k,v in sorted(bands.items())},
            'trades':rows}
    if out: Path(out).parent.mkdir(parents=True,exist_ok=True); Path(out).write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('csv'); p.add_argument('--out',default='validation/v71_report.json')
    a=p.parse_args(); print(json.dumps(run(a.csv,a.out)['total'],indent=2))
