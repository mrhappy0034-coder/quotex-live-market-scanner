"""V7.1.1 validation logger for scanner signals.

Writes an immutable signal event row when a signal is created and a completed
row when its target candle closes. The completed CSV is the authoritative
input for backtesting/accuracy; pending signals are never counted as wins.
"""
from pathlib import Path
import csv, time, threading

SIGNAL_FIELDS=["signal_id","timestamp","pair","signal","timeframe","entry","confirmation","score","trend","pattern","sr_condition","ema","rsi","macd","structure","event","reason","expiry_time"]
RESULT_FIELDS=SIGNAL_FIELDS+["expiry_price","result","result_time","resolution","move"]

class LiveValidator:
    def __init__(self, root=None):
        base=Path(root) if root else Path(__file__).resolve().parent
        self.path=base/"live_signals.csv"
        self.completed_path=base/"completed_signals.csv"
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.Lock()
        self._ensure(self.path,SIGNAL_FIELDS)
        self._ensure(self.completed_path,RESULT_FIELDS)

    def _ensure(self,path,fields):
        if not path.exists() or path.stat().st_size==0:
            with path.open("w",newline="",encoding="utf-8") as f:
                csv.DictWriter(f,fieldnames=fields).writeheader()

    def record(self,**kwargs):
        row={k:kwargs.get(k,"") for k in SIGNAL_FIELDS}
        with self.lock, self.path.open("a",newline="",encoding="utf-8") as f:
            csv.DictWriter(f,fieldnames=SIGNAL_FIELDS).writerow(row)
        return row.get("signal_id")

    def complete(self,**kwargs):
        row={k:kwargs.get(k,"") for k in RESULT_FIELDS}
        with self.lock, self.completed_path.open("a",newline="",encoding="utf-8") as f:
            csv.DictWriter(f,fieldnames=RESULT_FIELDS).writerow(row)
        return row.get("signal_id")

    def heartbeat(self):
        return {"ok":True,"time":time.time(),"file":str(self.path),"completed_file":str(self.completed_path)}
