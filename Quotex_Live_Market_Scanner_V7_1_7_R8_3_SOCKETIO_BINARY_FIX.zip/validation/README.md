# V7.1 Backtest + Live Validation
Run:
`python validation/backtest_engine.py validation/signals_template.csv --out validation/v71_report.json`

Accuracy = WIN / (WIN + LOSS); DRAW is excluded.
CALL wins when expiry > entry. PUT wins when expiry < entry.
The existing V4/V7 signal engine and feed are preserved. This module evaluates completed signals only.
Collect 100–300 completed signals before optimizing thresholds.
