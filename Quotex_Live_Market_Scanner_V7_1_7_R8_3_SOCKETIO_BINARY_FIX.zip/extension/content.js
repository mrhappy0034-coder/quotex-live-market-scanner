(() => {
  const source = 'QX_LIVE_SCANNER';
  const bridge = 'QX_LIVE_SCANNER_BRIDGE';
  let sent = 0;
  let failed = 0;

  function send(data, meta) {
    try {
      chrome.runtime.sendMessage({source: bridge, data, meta: meta || {}}, result => {
        if (chrome.runtime.lastError || !result || !result.ok) failed++;
        else sent++;
      });
    } catch (_) {
      failed++;
    }
  }

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.source !== source) return;
    if (e.data.meta && e.data.meta.kind === 'status') return;
    send(e.data.payload, e.data.meta || {});
  }, false);

  // Send an immediate heartbeat so the dashboard can show LIVE after reload,
  // then keep a small periodic heartbeat for diagnostics.
  send('__QX_EXTENSION_HEARTBEAT__', {kind:'heartbeat', sent, failed});
  setInterval(() => {
    send('__QX_EXTENSION_HEARTBEAT__', {kind:'heartbeat', sent, failed});
  }, 5000);
})();
