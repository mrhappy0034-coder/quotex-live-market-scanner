// MV3 service worker: forward captured live quote frames to the configured scanner server.
const DEFAULT_ENDPOINT = 'http://127.0.0.1:8765/api/frame';

async function getEndpoint() {
  try {
    const v = await chrome.storage.local.get(['endpoint']);
    const e = String(v.endpoint || DEFAULT_ENDPOINT).trim();
    return e.replace(/\/$/, '') + (e.endsWith('/api/frame') ? '' : '/api/frame');
  } catch (_) { return DEFAULT_ENDPOINT; }
}

async function forward(data, meta) {
  try {
    const endpoint = await getEndpoint();
    const r = await fetch(endpoint, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({data, meta: meta || {}}),
      cache: 'no-store'
    });
    return {ok: r.ok, status: r.status, endpoint};
  } catch (e) {
    return {ok: false, error: String(e)};
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.source !== 'QX_LIVE_SCANNER_BRIDGE') return;
  forward(msg.data, msg.meta).then(sendResponse);
  return true;
});
