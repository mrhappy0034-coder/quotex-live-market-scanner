const $=id=>document.getElementById(id);
chrome.storage.local.get(['endpoint']).then(v=>{ $('url').value=v.endpoint||'http://127.0.0.1:8765'; });
$('save').onclick=async()=>{let u=$('url').value.trim().replace(/\/$/,'');if(!/^https?:\/\//i.test(u)) return $('msg').textContent='Use http:// or https://';await chrome.storage.local.set({endpoint:u});$('msg').textContent='Saved.';};
$('test').onclick=async()=>{let u=$('url').value.trim().replace(/\/$/,'');try{let r=await fetch(u+'/api/status',{cache:'no-store'});$('msg').textContent=r.ok?'Server reachable.':'Server returned HTTP '+r.status;}catch(e){$('msg').textContent='Cannot reach server: '+e.message;}};
