# V7.1.7 R8.2 — 24H Online Running

This package is prepared to run the scanner server on an always-on cloud host.

## Important architecture

- The Python scanner server can run 24/7 in the cloud.
- The dashboard can be opened from any phone/PC at any time using the cloud URL.
- **Live Quotex data still requires an authorized Quotex browser session with the extension running.** The cloud server cannot create or access a user's Quotex session by itself.
- R8.2 remains LIVE-ONLY: no old OHLC history is used to create candles.

## Deploy

The included `Dockerfile` and `render.yaml` are ready for a Docker web service. Use an always-on/paid plan; sleep-to-zero hosting is not suitable for continuous live scanning.

After deployment, copy the HTTPS service URL.

## Connect the extension

1. Open Chrome/Chromium.
2. Load the `extension` folder as an unpacked extension.
3. Open the extension's **Options** page.
4. Enter the cloud URL, e.g. `https://YOUR-SERVICE-DOMAIN`.
5. Save and use **Test**.
6. Open the authorized Quotex page and keep that browser session running.
7. Open the same cloud URL on any device to view the dashboard.

## 24H reality check

The cloud server stays online 24/7, but the Quotex live-feed bridge is browser-session based. If the computer/browser running the authorized Quotex page is shut down, live ticks stop arriving. The dashboard remains online and will show the feed as waiting/stale until the bridge reconnects.
